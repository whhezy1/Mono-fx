/* ===========================================================================
   MONO FX service worker
   - CACHE version: bump this string on every deploy — the page detects the
     waiting worker and shows the "Update Available — Tap to Reload" toast.
   - App shell & static UI (single-file build, icons, fonts): CACHE-FIRST
   - Exchange-rate / crypto / metals APIs: NETWORK-FIRST, cache fallback
========================================================================= */

const CACHE = "monofx-v3";
const API_CACHE = "monofx-api-v1";

/* Precached on install — everything the UI needs to launch offline. */
const APP_SHELL = [
  "./",
  "./manifest.json",
  "./icon.svg",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-maskable-512.png",
  "./apple-touch-icon.png",
];

/* Rate providers cached network-first so stale data still works offline. */
const API_HOSTS = [
  "open.er-api.com",
  "api.frankfurter.dev",
  "api.frankfurter.app",
  "api.coingecko.com",
  "api.gold-api.com",
];

const FONT_HOSTS = ["fonts.googleapis.com", "fonts.gstatic.com"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k !== CACHE && k !== API_CACHE)
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

/* The page posts SKIP_WAITING when the user taps the update toast. */
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  /* ---- exchange-rate & price APIs: network-first, cache fallback ---- */
  if (API_HOSTS.includes(url.hostname)) {
    event.respondWith(
      fetch(req)
        .then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(API_CACHE).then((c) => c.put(req, copy));
          }
          return response;
        })
        .catch(() => caches.match(req))
    );
    return;
  }

  /* ---- web fonts: cache-first, populated on first load ---- */
  if (FONT_HOSTS.includes(url.hostname)) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ||
          fetch(req).then((response) => {
            const copy = response.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
            return response;
          })
      )
    );
    return;
  }

  if (url.origin !== self.location.origin) return;

  /* ---- navigations: network-first, app-shell cache fallback ---- */
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((c) => c.put("./", copy));
          return response;
        })
        .catch(() => caches.match("./"))
    );
    return;
  }

  /* ---- everything else same-origin: cache-first ---- */
  event.respondWith(
    caches.match(req).then(
      (hit) =>
        hit ||
        fetch(req).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return response;
        })
    )
  );
});
