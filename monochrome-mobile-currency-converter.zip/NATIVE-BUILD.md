# MONO FX — Native Builds (Capacitor 8)

The web app is fully wired for the Capacitor shell: `src/lib/native.ts`
auto-switches to `@capacitor/haptics`, `@capacitor/share`, and
`@capacitor/status-bar` when `Capacitor.isNativePlatform()` is true, and falls
back to `navigator.vibrate` / Web Share on the web. `capacitor.config.ts`
points `webDir` at `dist` (the single-file production build).

Targets: **Android API 36** · **iOS 15+**

## One-time setup

```bash
# 1. Install dependencies (Capacitor 8 packages are already in package.json)
npm install

# 2. Build the web app
npm run build

# 3. Generate the native projects (run from the repo root)
npx cap add android
npx cap add ios

# 4. Copy dist + plugins into the native shells
npx cap sync
```

## Compile & run

```bash
# Android — opens Android Studio; hit Run on an API 36 device/emulator
npx cap open android

# iOS — opens Xcode; set your signing team, then Run (iOS 15+ target)
npx cap open ios
```

After any web change: `npm run build && npx cap sync`.

## What the shell gets automatically

| Concern            | Implementation |
| ------------------ | -------------- |
| Status bar         | `StatusBar` plugin, synced to the dark/light theme (`useTheme`) |
| Haptics            | `nativeImpact()` — light impact on every keypad press, swap, chip |
| Share sheet        | `nativeShareText()` — receipt text through the native share sheet |
| Notch / home bar   | `safe-top` / `safe-bottom` CSS (`env(safe-area-inset-*)`), `viewport-fit=cover` |
| Splash             | Pure black, 400 ms (`capacitor.config.ts → SplashScreen`) |
| Offline            | Entire app is one inlined `index.html` + cached assets — works in airplane mode |

## Release notes

- **Android**: build a signed AAB with `cd android && ./gradlew bundleRelease`
  → `android/app/build/outputs/bundle/release/app-release.aab`.
- **iOS**: Product → Archive in Xcode → distribute via App Store Connect or
  TestFlight.
- App id is `app.monofx.console` — change it in `capacitor.config.ts`
  **before** `npx cap add`, or update it in the native projects afterwards.
