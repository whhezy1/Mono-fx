import type { CapacitorConfig } from "@capacitor/cli";

/**
 * MONO FX — Capacitor 8 configuration.
 * Targets Android API 36 and iOS 15+. The web app is built into `dist`
 * as a single self-contained index.html; the native shells load it locally,
 * so the entire converter works with zero network access.
 */
const config: CapacitorConfig = {
  appId: "app.monofx.console",
  appName: "MONO FX",
  webDir: "dist",
  backgroundColor: "#000000",

  android: {
    backgroundColor: "#000000",
    allowMixedContent: false,
  },

  ios: {
    backgroundColor: "#000000",
    // draw under the status bar; safe-area CSS insets handle the overlap
    contentInset: "always",
    limitsNavigationsToAppBoundDomains: false,
  },

  plugins: {
    StatusBar: {
      style: "dark",
      backgroundColor: "#000000",
    },
    SplashScreen: {
      launchShowDuration: 400,
      backgroundColor: "#000000",
      splashFullScreen: true,
      splashImmersive: true,
    },
    Keyboard: {
      resize: "native",
      style: "dark",
    },
  },
};

export default config;
