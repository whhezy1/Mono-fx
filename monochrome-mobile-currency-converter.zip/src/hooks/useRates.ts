import { useCallback, useEffect, useRef, useState } from "react";
import { FALLBACK_RATES } from "../lib/currencies";

export type RateStatus = "boot" | "live" | "cached" | "offline" | "fallback";

interface RateState {
  rates: Record<string, number>;
  time: number | null; // last successful sync (epoch ms)
  status: RateStatus;
}

const LS_KEY = "monofx:rates:v1";

function readCache(): { rates: Record<string, number>; time: number } | null {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed?.rates || typeof parsed?.time !== "number") return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeCache(rates: Record<string, number>, time: number) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify({ rates, time }));
  } catch {
    /* storage full / private mode — non-fatal */
  }
}

/**
 * Live USD-based rates from open.er-api.com with graceful degradation:
 *   live → cached payload → bundled reference rates. Never blocks the UI.
 * Live values always win; bundled reference rates fill any gaps so every
 * listed currency resolves even when the API omits a code.
 */
export function useRates(autoFetch = true) {
  const autoRef = useRef(autoFetch);
  autoRef.current = autoFetch;
  const [state, setState] = useState<RateState>(() => {
    const cache = readCache();
    return cache
      ? { rates: { ...FALLBACK_RATES, ...cache.rates }, time: cache.time, status: "cached" }
      : { rates: FALLBACK_RATES, time: null, status: "boot" };
  });
  const [refreshing, setRefreshing] = useState(false);
  const [online, setOnline] = useState<boolean>(
    typeof navigator === "undefined" ? true : navigator.onLine
  );

  /** Returns true when a live sync succeeded. */
  const refresh = useCallback(async (): Promise<boolean> => {
    setRefreshing(true);
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 8000);
      const res = await fetch("https://open.er-api.com/v6/latest/USD", {
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      if (json?.result !== "success" || !json?.rates) throw new Error("bad payload");

      const live: Record<string, number> = {};
      for (const [k, v] of Object.entries(json.rates)) {
        if (typeof v === "number" && isFinite(v)) live[k] = v;
      }
      const merged = { ...FALLBACK_RATES, ...live };
      const time = Date.now();
      writeCache(merged, time);
      setState({ rates: merged, time, status: "live" });
      return true;
    } catch {
      setState((prev) => ({
        rates: prev.time ? prev.rates : FALLBACK_RATES,
        time: prev.time,
        status: !navigator.onLine ? "offline" : prev.time ? "cached" : "fallback",
      }));
      return false;
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (autoRef.current) void refresh(); // data-saver mode skips auto-sync
  }, [refresh]);

  // Track connectivity; re-sync the moment we come back online.
  useEffect(() => {
    const up = () => {
      setOnline(true);
      if (autoRef.current) void refresh();
    };
    const down = () => {
      setOnline(false);
      setState((prev) => ({
        ...prev,
        status: prev.status === "live" ? "offline" : prev.status,
      }));
    };
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, [refresh]);

  return {
    rates: state.rates,
    status: state.status,
    lastUpdated: state.time,
    online,
    refreshing,
    refresh,
  };
}
