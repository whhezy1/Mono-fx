import { useCallback, useEffect, useState } from "react";

export interface AssetState {
  /** USD price per whole unit, e.g. BTC: 97000 means 1 BTC = $97,000. */
  prices: Record<string, number>;
  time: number | null;
  live: boolean;
}

/** Reference prices — keep the basket alive with zero network. */
const REFERENCE: Record<string, number> = {
  BTC: 97000,
  ETH: 3600,
  XAU: 2650,
  XAG: 31.5,
};

const LS_KEY = "monofx:assets:v1";

function readCache(): { prices: Record<string, number>; time: number } | null {
  try {
    const parsed = JSON.parse(localStorage.getItem(LS_KEY) ?? "");
    if (parsed?.prices && typeof parsed?.time === "number") return parsed;
  } catch { /* first run */ }
  return null;
}

async function fetchWithTimeout(url: string, ms = 6000): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

/**
 * Live crypto (CoinGecko) + precious-metal (gold-api.com) prices in USD.
 * Each source fails independently; whatever resolves upgrades the cache.
 * `poll=false` (data-saver mode) disables all automatic fetching — the
 * returned `refresh()` still works for manual syncs.
 */
export function useAssetRates(poll: boolean): AssetState & { refresh: () => Promise<void> } {
  const [state, setState] = useState<AssetState>(() => {
    const cache = readCache();
    return cache
      ? { prices: { ...REFERENCE, ...cache.prices }, time: cache.time, live: false }
      : { prices: REFERENCE, time: null, live: false };
  });

  const refresh = useCallback(async () => {
    {
      const prices: Record<string, number> = {};

      const results = await Promise.allSettled([
        fetchWithTimeout(
          "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd"
        ).then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`)))),
        fetchWithTimeout("https://api.gold-api.com/price/XAU").then((r) =>
          r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))
        ),
        fetchWithTimeout("https://api.gold-api.com/price/XAG").then((r) =>
          r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))
        ),
      ]);

      const [crypto, gold, silver] = results;
      if (crypto.status === "fulfilled") {
        const b = crypto.value?.bitcoin?.usd;
        const e = crypto.value?.ethereum?.usd;
        if (Number.isFinite(b)) prices.BTC = b;
        if (Number.isFinite(e)) prices.ETH = e;
      }
      if (gold.status === "fulfilled" && Number.isFinite(gold.value?.price)) {
        prices.XAU = gold.value.price;
      }
      if (silver.status === "fulfilled" && Number.isFinite(silver.value?.price)) {
        prices.XAG = silver.value.price;
      }

      if (Object.keys(prices).length === 0) return;
      const merged = { ...REFERENCE, ...prices };
      const time = Date.now();
      try {
        localStorage.setItem(LS_KEY, JSON.stringify({ prices: merged, time }));
      } catch { /* non-fatal */ }
      setState({ prices: merged, time, live: true });
    }
  }, []);

  useEffect(() => {
    if (!poll) return; // data saver: no automatic polling at all
    void refresh();
    const id = setInterval(() => void refresh(), 120000); // refresh every 2 min
    return () => clearInterval(id);
  }, [poll, refresh]);

  return { ...state, refresh };
}
