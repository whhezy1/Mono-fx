import { useEffect, useRef, useState } from "react";
import {
  type HistoryPoint,
  isoDay,
  syntheticHistory,
} from "../lib/money";

export type HistorySource = "live" | "cache" | "est";

export interface History {
  points: HistoryPoint[];
  source: HistorySource;
  loading: boolean;
}

/** ECB reference currencies served by the Frankfurter time-series API. */
const FRANKFURTER = new Set([
  "EUR", "USD", "JPY", "BGN", "CZK", "DKK", "GBP", "HUF", "PLN", "RON", "SEK",
  "CHF", "ISK", "NOK", "TRY", "AUD", "BRL", "CAD", "CNY", "HKD", "IDR", "ILS",
  "INR", "KRW", "MXN", "MYR", "NZD", "PHP", "SGD", "THB", "ZAR",
]);

async function fetchLive(from: string, to: string): Promise<HistoryPoint[] | null> {
  const end = new Date();
  const start = new Date(end.getTime() - 6 * 86400000);
  const range = `${isoDay(start)}..${isoDay(end)}`;
  const hosts = ["api.frankfurter.dev/v1", "api.frankfurter.app"];

  for (const host of hosts) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6000);
      const res = await fetch(`https://${host}/${range}?from=${from}&to=${to}`, {
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (!res.ok) continue;
      const json = await res.json();
      const dates = Object.keys(json?.rates ?? {}).sort();
      const pts = dates
        .map((d) => ({ date: d, value: Number(json.rates[d][to]) }))
        .filter((p) => Number.isFinite(p.value));
      if (pts.length < 2) continue;
      return pts;
    } catch {
      /* try next host */
    }
  }
  return null;
}

function cacheKey(from: string, to: string): string {
  return `monofx:hist:${from}:${to}:${isoDay(new Date())}`;
}

function readCache(from: string, to: string): HistoryPoint[] | null {
  try {
    const raw = localStorage.getItem(cacheKey(from, to));
    if (!raw) return null;
    const pts = JSON.parse(raw) as HistoryPoint[];
    return Array.isArray(pts) && pts.length >= 2 ? pts : null;
  } catch {
    return null;
  }
}

function writeCache(from: string, to: string, points: HistoryPoint[]) {
  try {
    localStorage.setItem(cacheKey(from, to), JSON.stringify(points));
  } catch {
    /* non-fatal */
  }
}

/**
 * 7-day series for a pair. Renders instantly from cache or a deterministic
 * estimate, then upgrades to live Frankfurter data when the pair is covered.
 */
export function useHistory(from: string, to: string, rate: number | null): History {
  const rateRef = useRef(rate);
  rateRef.current = rate;

  const [history, setHistory] = useState<History>({
    points: [],
    source: "est",
    loading: true,
  });

  useEffect(() => {
    let alive = true;

    // Same currency on both sides → exact flat 1:1 series, no fake variance.
    if (from === to) {
      const today = Date.now();
      setHistory({
        points: Array.from({ length: 7 }, (_, i) => ({
          date: isoDay(new Date(today - (6 - i) * 86400000)),
          value: 1,
        })),
        source: "live",
        loading: false,
      });
      return;
    }

    const fallback = () =>
      syntheticHistory(from, to, rateRef.current && rateRef.current > 0 ? rateRef.current : 1);
    const cache = readCache(from, to);
    const canLive = FRANKFURTER.has(from) && FRANKFURTER.has(to);

    setHistory({ points: cache ?? fallback(), source: cache ? "cache" : "est", loading: canLive });
    if (!canLive) return;

    fetchLive(from, to)
      .then((pts) => {
        if (!alive) return;
        if (pts) {
          writeCache(from, to, pts);
          setHistory({ points: pts, source: "live", loading: false });
        } else {
          setHistory((h) => ({ ...h, loading: false }));
        }
      })
      .catch(() => alive && setHistory((h) => ({ ...h, loading: false })));

    return () => {
      alive = false;
    };
  }, [from, to]);

  return history;
}
