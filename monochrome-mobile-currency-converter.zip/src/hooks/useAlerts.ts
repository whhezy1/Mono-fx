import { useCallback, useEffect, useRef, useState } from "react";
import { ukey } from "../lib/auth";
import { crossRate } from "../lib/money";

export interface RateAlert {
  id: string;
  from: string;
  to: string;
  target: number;
  dir: "above" | "below";
  ts: number;
  done: boolean;
}

function load(userId: string): RateAlert[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(ukey(userId, "alerts")) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (a): a is RateAlert =>
        !!a &&
        typeof a === "object" &&
        typeof a.id === "string" &&
        typeof a.from === "string" &&
        typeof a.to === "string" &&
        Number.isFinite(a.target) &&
        (a.dir === "above" || a.dir === "below")
    );
  } catch {
    return [];
  }
}

/**
 * Custom target-rate alerts, evaluated on every rate sync.
 * Fires `onTrigger` once per alert (marked done, never re-fires).
 */
export function useAlerts(
  userId: string,
  rates: Record<string, number>,
  onTrigger: (alert: RateAlert, current: number) => void
) {
  const [alerts, setAlerts] = useState<RateAlert[]>(() => load(userId));
  const alertsRef = useRef(alerts);
  alertsRef.current = alerts;
  const onTriggerRef = useRef(onTrigger);
  onTriggerRef.current = onTrigger;
  const firstSync = useRef(true);

  // Reload when the active account changes.
  useEffect(() => {
    if (!userId) return;
    firstSync.current = true;
    setAlerts(load(userId));
  }, [userId]);

  useEffect(() => {
    if (!userId) return;
    try {
      localStorage.setItem(ukey(userId, "alerts"), JSON.stringify(alerts));
    } catch { /* non-fatal */ }
  }, [alerts, userId]);

  // Evaluate open alerts whenever a fresh rate payload lands.
  useEffect(() => {
    if (firstSync.current) {
      firstSync.current = false;
      return;
    }
    const hits: Array<{ alert: RateAlert; current: number }> = [];
    const next = alertsRef.current.map((a) => {
      if (a.done) return a;
      const cur = crossRate(rates, a.from, a.to);
      if (cur == null) return a;
      const hit = a.dir === "above" ? cur >= a.target : cur <= a.target;
      if (hit) {
        hits.push({ alert: a, current: cur });
        return { ...a, done: true };
      }
      return a;
    });
    if (hits.length) {
      setAlerts(next);
      hits.forEach(({ alert, current }) => onTriggerRef.current(alert, current));
    }
  }, [rates]);

  const add = useCallback(
    (from: string, to: string, target: number, dir: "above" | "below"): string | null => {
      if (!Number.isFinite(target) || target <= 0) return "ENTER A VALID TARGET RATE";
      if (from === to) return "PICK TWO DIFFERENT CURRENCIES";
      setAlerts((prev) =>
        [
          { id: `a_${Date.now().toString(36)}`, from, to, target, dir, ts: Date.now(), done: false },
          ...prev,
        ].slice(0, 20)
      );
      return null;
    },
    []
  );

  const remove = useCallback((id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  }, []);

  const clearAll = useCallback(() => setAlerts([]), []);

  return { alerts, add, remove, clearAll };
}
