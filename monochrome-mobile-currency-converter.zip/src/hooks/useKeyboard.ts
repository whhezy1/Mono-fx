import { useEffect, useRef, useState } from "react";

interface KeyboardHandlers {
  onDigit: (digit: string) => void;
  onDot: () => void;
  onBackspace: () => void;
  onClear: () => void;
  onSwap: () => void;
  /** Inline expression operators (+ − × ÷). */
  onOperator?: (op: string) => void;
  onEquals?: () => void;
  onPercent?: () => void;
  /** Show / hide the on-screen keypad dock. */
  onTogglePad?: () => void;
  /** When true (e.g. a sheet is open) all shortcuts are ignored. */
  disabled?: boolean;
}

/**
 * Global desktop-keyboard entry:
 *   0–9 type · . or , decimal · Backspace delete · Esc/Delete clear
 *   + - * / expression operators · = evaluate · % percent
 *   S or Enter swap (Enter only when no button holds focus) · K toggle keypad
 * Also reports which pad key to light up for tactile visual feedback.
 */
export function useKeyboard(handlers: KeyboardHandlers): string | null {
  const [litKey, setLitKey] = useState<string | null>(null);
  const ref = useRef(handlers);
  ref.current = handlers;
  const timer = useRef<number | null>(null);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const h = ref.current;
      if (h.disabled) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;

      const el = document.activeElement;
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return;

      let lit: string | null = null;

      if (/^[0-9]$/.test(e.key)) {
        h.onDigit(e.key);
        lit = e.key;
      } else if (e.key === "." || e.key === ",") {
        h.onDot();
        lit = ".";
      } else if (e.key === "Backspace") {
        h.onBackspace();
        lit = "del";
      } else if (e.key === "Delete" || e.key === "Escape") {
        h.onClear();
      } else if (e.key === "*" || e.key === "/") {
        const op = e.key === "*" ? "×" : "÷";
        h.onOperator?.(op);
        lit = op;
      } else if (e.key === "-" || e.key === "+") {
        const op = e.key === "-" ? "−" : "+";
        h.onOperator?.(op);
        lit = op;
      } else if (e.key === "=") {
        h.onEquals?.();
        lit = "=";
      } else if (e.key === "%") {
        h.onPercent?.();
        lit = "%";
      } else if (
        (e.key === "k" || e.key === "K") &&
        !(el instanceof HTMLButtonElement)
      ) {
        h.onTogglePad?.();
      } else if (
        (e.key === "s" || e.key === "S" || e.key === "Enter") &&
        !(el instanceof HTMLButtonElement) // don't double-fire focused buttons
      ) {
        h.onSwap();
      } else {
        return; // unhandled key — don't suppress it
      }

      e.preventDefault();

      if (lit) {
        setLitKey(lit);
        if (timer.current) window.clearTimeout(timer.current);
        timer.current = window.setTimeout(
          () => setLitKey((k) => (k === lit ? null : k)),
          160
        );
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, []);

  return litKey;
}
