import { useCallback, useEffect, useState } from "react";
import { isNativePlatform } from "../lib/native";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

export type InstallOutcome = "prompted" | "ios-guide" | "unavailable";

/**
 * Install plumbing for both platforms:
 * - Android/Chromium: captures `beforeinstallprompt` so the app (not the
 *   browser mini-banner) decides when to offer installation.
 * - iOS Safari: no install event exists — flags the device so the UI opens
 *   the "Share → Add to Home Screen" guide sheet instead.
 * Hidden entirely when already running standalone or inside Capacitor.
 */
export function useInstallPrompt() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [standalone, setStandalone] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    const nav = navigator as Navigator & { standalone?: boolean };
    setStandalone(
      window.matchMedia("(display-mode: standalone)").matches ||
        nav.standalone === true ||
        isNativePlatform()
    );
    setIos(/iphone|ipad|ipod/i.test(navigator.userAgent) && nav.standalone !== true);

    const onPrompt = (e: Event) => {
      e.preventDefault(); // we trigger prompt() from our own UI
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const canInstall = !installed && !standalone;

  const promptInstall = useCallback(async (): Promise<InstallOutcome> => {
    if (deferred) {
      await deferred.prompt();
      const choice = await deferred.userChoice;
      if (choice.outcome === "accepted") setDeferred(null);
      return "prompted";
    }
    if (/iphone|ipad|ipod/i.test(navigator.userAgent)) return "ios-guide";
    return "unavailable";
  }, [deferred]);

  return { canInstall, ios, standalone, promptInstall };
}
