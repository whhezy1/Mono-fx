import { useEffect, useState } from "react";
import { styleNativeStatusBar } from "../lib/native";

export type Theme = "dark" | "light";
const THEME_KEY = "monofx:theme";

/**
 * Dual monochrome theme with localStorage persistence. Applies
 * `data-theme` on <html> and syncs the browser chrome color.
 */
export function useTheme(): [Theme, () => void] {
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      return localStorage.getItem(THEME_KEY) === "light" ? "light" : "dark";
    } catch {
      return "dark";
    }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem(THEME_KEY, theme);
      const meta = document.querySelector('meta[name="theme-color"]');
      meta?.setAttribute("content", theme === "dark" ? "#000000" : "#ffffff");
    } catch { /* non-fatal */ }
    // match the device status bar when running inside the Capacitor shell
    void styleNativeStatusBar(theme === "dark");
  }, [theme]);

  const toggle = () => setTheme((t) => (t === "dark" ? "light" : "dark"));
  return [theme, toggle];
}
