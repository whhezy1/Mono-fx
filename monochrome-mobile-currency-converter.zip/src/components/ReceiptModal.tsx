import { useMemo, useState } from "react";
import Masked from "./Masked";
import type { AuthUser } from "../lib/auth";
import { flagOf } from "../lib/flags";
import {
  canNativeShare,
  copyAndOpen,
  downloadText,
  emailUrl,
  entryAmount,
  entryRef,
  facebookUrl,
  nativeShare,
  PASTE_APP_URLS,
  receiptText,
  redditUrl,
  smsUrl,
  telegramUrl,
  whatsappUrl,
  xUrl,
  type ConversionEntry,
} from "../lib/ledger";
import {
  EmailIcon,
  FacebookIcon,
  InstagramIcon,
  LinkedInIcon,
  RedditIcon,
  SnapchatIcon,
  SmsIcon,
  TelegramIcon,
  WhatsAppIcon,
  XIcon,
} from "./ShareIcons";
import { hashString } from "../lib/money";
import { formatRate, formatValue } from "../lib/money";
import { meta } from "../lib/currencies";

interface ReceiptModalProps {
  entry: ConversionEntry;
  user: AuthUser | null;
  onClose: () => void;
  onToast: (msg: string) => void;
  /** Privacy mode — masks amounts until tapped. */
  hidden: boolean;
}

/** Deterministic faux barcode — pure decoration, generated from the ref. */
function Barcode({ seed }: { seed: string }) {
  const bars = useMemo(() => {
    let h = hashString(seed);
    const out: number[] = [];
    for (let i = 0; i < 34; i++) {
      h = (Math.imul(h, 1103515245) + 12345) >>> 0;
      out.push(1 + (h % 3));
    }
    return out;
  }, [seed]);
  let x = 0;
  return (
    <svg viewBox="0 0 124 16" className="h-7 w-full" preserveAspectRatio="none" aria-hidden>
      {bars.map((w, i) => {
        const rect = <rect key={i} x={x} y="0" width={w} height="16" fill="currentColor" />;
        x += w + 1.6;
        return rect;
      })}
    </svg>
  );
}

const ic = "h-3.5 w-3.5 shrink-0";

/** Printable, shareable conversion receipt. */
export default function ReceiptModal({ entry, user, onClose, onToast, hidden }: ReceiptModalProps) {
  const [copied, setCopied] = useState(false);
  const text = useMemo(() => receiptText(entry, user), [entry, user]);
  const ref = entryRef(entry);
  const fm = meta(entry.from);
  const tm = meta(entry.to);
  const date = new Date(entry.ts);

  const shareBtn =
    "flex items-center justify-center gap-1.5 rounded-xl border border-line py-3 font-mono text-[8px] font-bold tracking-[0.18em] text-zinc-300 transition-all duration-150 active:scale-[0.96] active:bg-white active:text-black";

  const copyReceipt = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      onToast("RECEIPT COPIED TO CLIPBOARD");
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      onToast("CLIPBOARD UNAVAILABLE");
    }
  };

  return (
    <div className="absolute inset-0 z-[60] flex items-center justify-center p-4">
      <button
        aria-label="Close receipt"
        onClick={onClose}
        className="absolute inset-0 w-full animate-fade bg-[rgba(0,0,0,0.72)]"
      />

      {/* the receipt */}
      <div
        id="receipt-card"
        className="no-scrollbar relative w-full max-w-sm animate-pop rounded-3xl border border-zinc-600 bg-panel p-5 text-white shadow-[0_30px_80px_rgba(0,0,0,0.8)] max-h-[calc(100dvh-2.5rem)] overflow-y-auto"
      >
        {/* header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <svg width="26" height="26" viewBox="0 0 24 24" aria-hidden>
              <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.6" />
              <path d="M12 2a10 10 0 0 1 0 20Z" fill="currentColor" />
            </svg>
            <div>
              <p className="font-display text-base leading-none font-bold tracking-tight">
                MONO<span className="text-zinc-500">FX</span>
              </p>
              <p className="mt-1 font-mono text-[7px] tracking-[0.3em] text-zinc-500">
                CONVERSION RECEIPT
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
          >
            <svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
              <path d="m2 2 10 10M12 2 2 12" />
            </svg>
          </button>
        </div>

        {/* meta */}
        <div className="mt-4 space-y-1 font-mono text-[9px] tracking-wider text-zinc-400">
          <p className="flex justify-between"><span className="text-zinc-600">REF</span><span className="tabular-nums">{ref}</span></p>
          <p className="flex justify-between">
            <span className="text-zinc-600">DATE</span>
            <span className="tabular-nums">
              {date.toISOString().slice(0, 10)} {date.toLocaleTimeString("en-GB", { hour12: false })} UTC
            </span>
          </p>
          <p className="flex justify-between gap-4">
            <span className="shrink-0 text-zinc-600">ACCOUNT</span>
            <span className="truncate">{user ? `${user.name} · ${user.email}` : "GUEST"}</span>
          </p>
        </div>

        {/* perforation */}
        <div className="my-4 flex items-center gap-2">
          <span className="text-zinc-600">✂</span>
          <div className="flex-1 border-t border-dashed border-zinc-600" />
        </div>

        {/* from */}
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-line bg-black text-2xl">
            <span className="flag-mono">{flagOf(entry.from)}</span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[8px] tracking-[0.3em] text-zinc-500">SENT · {fm.country.toUpperCase()}</p>
            <p className="font-display text-lg font-bold tracking-wide">{entry.from}</p>
          </div>
          <p className="shrink-0 font-display text-xl font-bold tabular-nums">
            <Masked hidden={hidden}>{formatValue(entryAmount(entry), entry.from)}</Masked>
          </p>
        </div>

        {/* rate + simulated fee */}
        <div className="my-3 flex flex-col items-center gap-1.5">
          <span className="rounded-full border border-zinc-600 px-3.5 py-1.5 font-mono text-[10px] font-medium tabular-nums text-zinc-300">
            1 {entry.from} = {formatRate(entry.rate)} {entry.to}
          </span>
          {entry.feePct != null && entry.feePct > 0 && (
            <Masked hidden={hidden}>
              <span className="rounded-full border border-dashed border-zinc-500 px-3.5 py-1.5 font-mono text-[9px] font-medium tabular-nums text-zinc-400">
                FEE {entry.feePct}% · −{formatValue(entry.result * (entry.feePct / 100), entry.to)} →
                NET {formatValue(entry.result * (1 - entry.feePct / 100), entry.to)} {entry.to}
              </span>
            </Masked>
          )}
        </div>

        {/* to */}
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-2xl">
            <span className="flag-mono">{flagOf(entry.to)}</span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[8px] tracking-[0.3em] text-zinc-500">RECEIVED · {tm.country.toUpperCase()}</p>
            <p className="font-display text-lg font-bold tracking-wide">{entry.to}</p>
          </div>
          <p className="shrink-0 font-display text-xl font-bold tabular-nums">
            <Masked hidden={hidden}>{formatValue(entry.result, entry.to)}</Masked>
          </p>
        </div>

        {/* perforation + barcode */}
        <div className="my-4 border-t border-dashed border-zinc-600" />
        <div className="text-white">
          <Barcode seed={ref} />
        </div>
        <p className="mt-1.5 text-center font-mono text-[8px] tracking-[0.5em] text-zinc-500">{ref}</p>
        <p className="mt-3 text-center font-mono text-[7px] leading-relaxed tracking-[0.2em] text-zinc-600">
          RATES BY OPEN-ER-API · INDICATIVE ONLY · © 2026 MONO FX
          <br />
          STRICTLY BLACK &amp; WHITE
        </p>

        {/* ------------------------- share centre ------------------------- */}
        <div className="mt-4 space-y-2">
          {canNativeShare() && (
            <button
              onClick={() => void nativeShare(text).then((ok) => ok && onToast("SHARED"))}
              className={`${shareBtn} w-full bg-white text-black active:scale-[0.98]`}
            >
              <svg className={ic} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
                <circle cx="6" cy="12" r="2.6" /><circle cx="17.5" cy="5.5" r="2.6" /><circle cx="17.5" cy="18.5" r="2.6" />
                <path d="m8.4 10.7 6.8-3.9M8.4 13.3l6.8 3.9" />
              </svg>
              NATIVE SHARE
            </button>
          )}

          <div className="grid grid-cols-3 gap-2">
            <button onClick={() => void copyReceipt()} className={shareBtn}>
              <svg className={ic} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <rect x="9" y="9" width="11" height="11" rx="2" />
                <path d="M5 15V5a2 2 0 0 1 2-2h10" />
              </svg>
              {copied ? "COPIED ✓" : "COPY"}
            </button>
            <button
              onClick={() => {
                downloadText(`monofx-${ref}.txt`, text);
                onToast("RECEIPT DOWNLOADED");
              }}
              className={shareBtn}
            >
              <svg className={ic} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 3v12m0 0 4-4m-4 4-4-4" />
                <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
              </svg>
              .TXT
            </button>
            <button onClick={() => window.print()} className={shareBtn}>
              <svg className={ic} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M7 8V3h10v5" />
                <rect x="4" y="8" width="16" height="9" rx="2" />
                <path d="M7 14h10v7H7z" />
              </svg>
              PRINT
            </button>
          </div>

          {/* destination grid */}
          <div className="flex items-center gap-3 pt-1">
            <div className="h-px flex-1 bg-line" />
            <span className="font-mono text-[8px] tracking-[0.35em] text-zinc-500">SEND RECEIPT VIA</span>
            <div className="h-px flex-1 bg-line" />
          </div>

          <div className="grid grid-cols-5 gap-1.5">
            {(
              [
                ["X", xUrl(text), XIcon],
                ["WHATSAPP", whatsappUrl(text), WhatsAppIcon],
                ["TELEGRAM", telegramUrl(text), TelegramIcon],
                ["FACEBOOK", facebookUrl(text), FacebookIcon],
                ["REDDIT", redditUrl(text), RedditIcon],
                ["EMAIL", emailUrl(entry, text), EmailIcon],
                ["SMS", smsUrl(text), SmsIcon],
              ] as const
            ).map(([label, href, Icon]) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noreferrer"
                onClick={() => onToast(`OPENING ${label}…`)}
                aria-label={`Share via ${label}`}
                className="flex flex-col items-center gap-1.5 rounded-xl border border-line py-2.5 text-zinc-300 transition-all duration-150 active:scale-90 active:bg-white active:text-black"
              >
                <Icon />
                <span className="font-mono text-[6.5px] font-bold tracking-wider">{label}</span>
              </a>
            ))}

            {/* no share-link API — copy first, then open the app to paste */}
            {(
              [
                ["LINKEDIN", PASTE_APP_URLS.linkedin, LinkedInIcon],
                ["SNAPCHAT", PASTE_APP_URLS.snapchat, SnapchatIcon],
                ["INSTAGRAM", PASTE_APP_URLS.instagram, InstagramIcon],
              ] as const
            ).map(([label, url, Icon]) => (
              <button
                key={label}
                onClick={() =>
                  void copyAndOpen(text, url).then((ok) =>
                    onToast(ok ? `COPIED — PASTE IN ${label}` : `OPENING ${label}…`)
                  )
                }
                aria-label={`Copy receipt and open ${label}`}
                className="flex flex-col items-center gap-1.5 rounded-xl border border-dashed border-zinc-600 py-2.5 text-zinc-300 transition-all duration-150 active:scale-90 active:bg-white active:text-black"
              >
                <Icon />
                <span className="font-mono text-[6.5px] font-bold tracking-wider">{label}</span>
              </button>
            ))}
          </div>

          <p className="pt-0.5 text-center font-mono text-[7px] leading-relaxed tracking-[0.18em] text-zinc-600">
            DASHED CHIPS COPY THE RECEIPT FIRST — PASTE IT IN THE APP
          </p>
        </div>
      </div>
    </div>
  );
}
