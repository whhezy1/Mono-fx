import { useMemo, useState } from "react";
import Masked from "./Masked";
import { flagOf } from "../lib/flags";
import { entryAmount, entryRef, type ConversionEntry } from "../lib/ledger";
import { formatRate, formatValue } from "../lib/money";
import { cn } from "../utils/cn";

interface HistoryScreenProps {
  entries: ConversionEntry[];
  onRestore: (e: ConversionEntry) => void;
  onRemove: (id: string) => void;
  onClearAll: () => void;
  onExport: () => void;
  onReceipt: (e: ConversionEntry) => void;
  folderNameOf: (entryId: string) => string | null;
  onAssignFolder: (entryId: string) => void;
  /** Privacy mode — masks amounts until tapped. */
  hidden: boolean;
}

function fmtStamp(ts: number): string {
  const d = new Date(ts);
  return `${d.toLocaleDateString("en-US", { month: "short", day: "numeric" })} · ${d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false })}`;
}

/** Dedicated history view — searchable ledger of every saved conversion. */
export default function HistoryScreen({
  entries,
  onRestore,
  onRemove,
  onClearAll,
  onExport,
  onReceipt,
  folderNameOf,
  onAssignFolder,
  hidden,
}: HistoryScreenProps) {
  const [query, setQuery] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toUpperCase();
    if (!q) return entries;
    return entries.filter(
      (e) =>
        e.from.includes(q) ||
        e.to.includes(q) ||
        `${e.from}${e.to}`.includes(q) ||
        entryRef(e).includes(q) ||
        formatValue(entryAmount(e), e.from).includes(q)
    );
  }, [entries, query]);

  return (
    <div className="px-4">
      {/* header */}
      <div className="flex items-end justify-between">
        <div>
          <p className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">ACCOUNT LEDGER</p>
          <h2 className="mt-1 font-display text-2xl font-bold tracking-tight">History</h2>
        </div>
        <span className="rounded-full border border-line px-2.5 py-1 font-mono text-[10px] tabular-nums text-zinc-400">
          {entries.length} SAVED
        </span>
      </div>

      {/* search */}
      <div className="relative mt-3">
        <svg className="pointer-events-none absolute top-1/2 left-4 h-4 w-4 -translate-y-1/2 text-zinc-500" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
          <circle cx="7" cy="7" r="4.5" />
          <path d="m10.5 10.5 3.5 3.5" />
        </svg>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="SEARCH PAIR, AMOUNT OR REF…"
          className="w-full rounded-2xl border border-line bg-panel py-3.5 pr-4 pl-11 font-mono text-[11px] tracking-wider text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400"
        />
      </div>

      {/* actions */}
      <div className="mt-2.5 flex gap-2">
        <button
          onClick={onExport}
          disabled={!entries.length}
          className="flex-1 rounded-full bg-white py-2.5 font-mono text-[9px] font-bold tracking-[0.25em] text-black transition-all active:scale-[0.97] disabled:opacity-30"
        >
          ↓ EXPORT CSV
        </button>
        <button
          onClick={() => {
            if (!entries.length) return;
            if (confirmClear) {
              onClearAll();
              setConfirmClear(false);
            } else {
              setConfirmClear(true);
              window.setTimeout(() => setConfirmClear(false), 2500);
            }
          }}
          disabled={!entries.length}
          className={cn(
            "flex-1 rounded-full border py-2.5 font-mono text-[9px] font-bold tracking-[0.25em] transition-all active:scale-[0.97] disabled:opacity-30",
            confirmClear
              ? "animate-blink border-white bg-white text-black"
              : "border-line text-zinc-400 active:bg-white active:text-black"
          )}
        >
          {confirmClear ? "TAP AGAIN TO WIPE" : "CLEAR ALL"}
        </button>
      </div>

      {/* list */}
      {filtered.length === 0 ? (
        <div className="mt-10 flex flex-col items-center gap-3 text-center">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-700" aria-hidden>
            <path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5M12 7v5l3 2" />
          </svg>
          <p className="font-mono text-[10px] tracking-[0.2em] text-zinc-600">
            {entries.length === 0
              ? "NOTHING LOGGED YET — CONVERSIONS SAVE AUTOMATICALLY"
              : `NO MATCH FOR “${query.toUpperCase()}”`}
          </p>
        </div>
      ) : (
        <div className="mt-4 space-y-2.5 pb-4">
          {filtered.map((e, i) => (
            <article
              key={e.id}
              className={cn(
                "rounded-2xl border border-line bg-panel p-4",
                i === 0 && "animate-tick"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 font-display text-[13px] font-semibold tracking-wide">
                  <span className="flag-mono text-base leading-none">{flagOf(e.from)}</span>
                  {e.from}
                  <span className="text-zinc-600">→</span>
                  <span className="flag-mono text-base leading-none">{flagOf(e.to)}</span>
                  {e.to}
                </span>
                <span className="flex items-center gap-1.5">
                  {folderNameOf(e.id) && (
                    <span className="rounded-full bg-white px-2 py-px font-mono text-[7px] font-bold tracking-widest text-black">
                      ⌂ {folderNameOf(e.id)}
                    </span>
                  )}
                  <span className="font-mono text-[8px] tracking-widest text-zinc-600">{entryRef(e)}</span>
                </span>
              </div>

              <button
                onClick={() => onRestore(e)}
                className="mt-2 flex w-full items-baseline justify-between gap-3 text-left"
              >
                <span className="min-w-0">
                  <span className="block truncate font-display text-lg font-semibold tabular-nums">
                    <Masked hidden={hidden}>{formatValue(entryAmount(e), e.from)}</Masked>{" "}
                    <span className="text-sm text-zinc-500">{e.from}</span>
                    {e.feePct ? <span className="text-xs text-zinc-500"> · {e.feePct}% FEE</span> : null}
                  </span>
                  <span className="block font-mono text-[9px] tracking-wider text-zinc-500">
                    1 {e.from} = {formatRate(e.rate)} {e.to} · {fmtStamp(e.ts)}
                  </span>
                </span>
                <span className="shrink-0 text-right">
                  <span className="block font-display text-lg font-bold tabular-nums">
                    <Masked hidden={hidden}>{formatValue(e.result, e.to)}</Masked>
                  </span>
                  <span className="block font-mono text-[9px] tracking-widest text-zinc-500">{e.to}</span>
                </span>
              </button>

              <div className="mt-3 flex gap-2 border-t border-line pt-3">
                <button
                  onClick={() => onReceipt(e)}
                  className="flex-1 rounded-full bg-white py-2 font-mono text-[8px] font-bold tracking-[0.2em] text-black transition-all active:scale-[0.96]"
                >
                  🧾 RECEIPT
                </button>
                <button
                  onClick={() => onAssignFolder(e.id)}
                  className="flex-1 rounded-full border border-line py-2 font-mono text-[8px] font-bold tracking-[0.2em] text-zinc-300 transition-all active:scale-[0.96] active:bg-white active:text-black"
                >
                  ⌂ FOLDER
                </button>
                <button
                  onClick={() => onRestore(e)}
                  aria-label="Restore conversion"
                  className="flex w-14 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-[0.96] active:bg-white active:text-black"
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5" />
                  </svg>
                </button>
                <button
                  onClick={() => onRemove(e.id)}
                  aria-label="Delete entry"
                  className="flex w-16 items-center justify-center rounded-full border border-line text-zinc-500 transition-all active:scale-[0.96] active:bg-white active:text-black"
                >
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
                    <path d="m1.5 1.5 7 7m0-7-7 7" />
                  </svg>
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
