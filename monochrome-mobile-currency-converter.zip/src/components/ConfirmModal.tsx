import { cn } from "../utils/cn";

interface ConfirmModalProps {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  onClose: () => void;
}

/** Centered monochrome confirmation dialog for destructive actions. */
export default function ConfirmModal({
  open,
  title,
  body,
  confirmLabel,
  onConfirm,
  onClose,
}: ConfirmModalProps) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-[65] flex items-center justify-center p-6" role="alertdialog" aria-modal="true" aria-label={title}>
      <button
        aria-label="Cancel"
        onClick={onClose}
        className="absolute inset-0 w-full animate-fade bg-[rgba(0,0,0,0.72)]"
      />
      <div className="relative w-full max-w-xs animate-pop rounded-3xl border border-zinc-600 bg-panel p-5">
        <h3 className="font-display text-lg font-bold tracking-tight">{title}</h3>
        <p className="mt-2 font-mono text-[9px] leading-relaxed tracking-[0.15em] text-zinc-400">
          {body}
        </p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            onClick={onClose}
            className="rounded-full border border-line py-3 font-mono text-[9px] font-bold tracking-[0.25em] text-zinc-300 transition-all active:scale-[0.96] active:bg-white active:text-black"
          >
            CANCEL
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className={cn(
              "rounded-full bg-white py-3 font-mono text-[9px] font-bold tracking-[0.25em] text-black",
              "transition-all active:scale-[0.96]"
            )}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
