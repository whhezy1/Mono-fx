import { crossRate, formatRate } from "../lib/money";

interface TickerProps {
  rates: Record<string, number>;
  onSelect: (from: string, to: string) => void;
}

const PAIRS: Array<[string, string]> = [
  ["EUR", "USD"],
  ["GBP", "USD"],
  ["USD", "JPY"],
  ["USD", "NGN"],
  ["USD", "CNY"],
  ["AUD", "USD"],
  ["USD", "CHF"],
  ["USD", "INR"],
  ["USD", "BRL"],
  ["USD", "KRW"],
  ["BTC", "USD"],
  ["ETH", "USD"],
  ["XAU", "USD"],
];

/** Seamless monochrome rate tape — tap any pair to load it. */
export default function Ticker({ rates, onSelect }: TickerProps) {
  const items = PAIRS.map(([f, t]) => ({ f, t, rate: crossRate(rates, f, t) }));

  const row = (ariaHidden: boolean) => (
    <div className="flex shrink-0 items-center" aria-hidden={ariaHidden}>
      {items.map(({ f, t, rate }) => (
        <button
          key={`${f}${t}-${ariaHidden ? "b" : "a"}`}
          tabIndex={ariaHidden ? -1 : 0}
          onClick={() => onSelect(f, t)}
          className="group flex items-center gap-2 px-4 py-2 font-mono text-[11px] whitespace-nowrap transition-colors active:bg-white active:text-black"
        >
          <span className="tracking-wider text-zinc-500 group-active:text-black/60">
            {f}/{t}
          </span>
          <span className="font-medium tabular-nums text-white group-active:text-black">
            {rate ? formatRate(rate) : "—"}
          </span>
          <span className="pl-2 text-[7px] text-zinc-800 group-active:text-black/40">◆</span>
        </button>
      ))}
    </div>
  );

  return (
    <div className="relative overflow-hidden border-y border-line bg-black">
      <div className="flex w-max animate-marquee hover:[animation-play-state:paused]">
        {row(false)}
        {row(true)}
      </div>
      {/* edge fades */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-10 bg-gradient-to-r from-black to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-10 bg-gradient-to-l from-black to-transparent" />
    </div>
  );
}
