export interface ToastData {
  id: number;
  msg: string;
}

/** Transient monochrome notification pinned under the app bar. */
export default function Toast({ toast }: { toast: ToastData | null }) {
  if (!toast) return null;
  return (
    <div
      key={toast.id}
      role="status"
      className="animate-toast pointer-events-none absolute top-[4.6rem] left-1/2 z-40 flex items-center gap-2 rounded-full border border-zinc-600 bg-black px-4 py-2 shadow-[0_10px_36px_rgba(0,0,0,0.85)]"
    >
      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-white" />
      <span className="font-mono text-[10px] font-medium tracking-[0.18em] whitespace-nowrap text-white">
        {toast.msg}
      </span>
    </div>
  );
}
