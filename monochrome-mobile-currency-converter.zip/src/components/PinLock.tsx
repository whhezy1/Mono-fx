import { useEffect, useState } from "react";
import { hashPassword } from "../lib/auth";
import { cn } from "../utils/cn";

interface PinLockProps {
  mode: "unlock" | "setup";
  /** Stored hash to verify against (unlock mode only). */
  expectedHash?: string | null;
  onUnlocked: () => void;
  onSetupComplete?: (pin: string) => void;
  onClose: () => void;
}

/**
 * 4-digit passcode overlay. Fully opaque backdrop — nothing underneath is
 * visible while locked. Setup runs enter → confirm; errors shake the dots.
 */
export default function PinLock({
  mode,
  expectedHash,
  onUnlocked,
  onSetupComplete,
  onClose,
}: PinLockProps) {
  const [pin, setPin] = useState("");
  const [phase, setPhase] = useState<"enter" | "confirm">("enter");
  const [first, setFirst] = useState("");
  const [error, setError] = useState(false);

  const flash = () => {
    setError(true);
    setPin("");
    window.setTimeout(() => setError(false), 480);
  };

  const submit = (value: string) => {
    if (mode === "unlock") {
      if (expectedHash && hashPassword(value) === expectedHash) onUnlocked();
      else flash();
      return;
    }
    if (phase === "enter") {
      setFirst(value);
      setPhase("confirm");
      setPin("");
    } else if (value === first) {
      onSetupComplete?.(value);
    } else {
      flash();
      setPhase("enter");
      setFirst("");
    }
  };

  const press = (k: string) => {
    if (k === "del") return setPin((p) => p.slice(0, -1));
    if (k === "C") return setPin("");
    if (pin.length >= 4) return;
    const next = pin + k;
    setPin(next);
    if (next.length === 4) window.setTimeout(() => submit(next), 200);
  };

  // physical keyboard entry while the lock is up
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        press(e.key);
      } else if (e.key === "Backspace") {
        e.preventDefault();
        press("del");
      } else if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const title =
    mode === "unlock"
      ? "ENTER PASSCODE"
      : phase === "enter"
        ? "CREATE 4-DIGIT PASSCODE"
        : "CONFIRM YOUR PASSCODE";

  const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "del"];

  return (
    <div className="absolute inset-0 z-[70] flex flex-col items-center justify-center bg-black px-8" role="dialog" aria-modal="true" aria-label={title}>
      <button
        onClick={onClose}
        aria-label="Cancel"
        className="absolute top-5 right-5 flex h-9 w-9 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
      >
        <svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
          <path d="m2 2 10 10M12 2 2 12" />
        </svg>
      </button>

      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <rect x="5" y="10.5" width="14" height="10" rx="2.5" />
        <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
        <circle cx="12" cy="15.5" r="1.4" fill="currentColor" stroke="none" />
      </svg>

      <h2 className="mt-4 font-display text-lg font-bold tracking-[0.2em]">{title}</h2>
      <p className="mt-1 font-mono text-[8px] tracking-[0.3em] text-zinc-500">
        {mode === "unlock" ? "HISTORY & FOLDERS ARE PROTECTED" : "STORED ONLY ON THIS DEVICE"}
      </p>

      {/* dots */}
      <div className={cn("mt-6 flex gap-4", error && "animate-shake")}>
        {[0, 1, 2, 3].map((i) => (
          <span
            key={i}
            className={cn(
              "h-3.5 w-3.5 rounded-full border transition-all duration-150",
              i < pin.length ? "scale-110 border-white bg-white" : "border-zinc-500 bg-transparent"
            )}
          />
        ))}
      </div>
      {error && (
        <p className="mt-3 animate-blink font-mono text-[9px] tracking-[0.3em] text-white">
          {mode === "unlock" ? "WRONG PASSCODE" : "DID NOT MATCH — TRY AGAIN"}
        </p>
      )}

      {/* pad */}
      <div className="mt-6 grid grid-cols-3 gap-2.5">
        {KEYS.map((k) => (
          <button
            key={k}
            onClick={() => press(k)}
            aria-label={k === "del" ? "Delete digit" : k === "C" ? "Clear" : k}
            className="flex h-14 w-16 items-center justify-center rounded-full border border-line font-display text-xl font-medium transition-all duration-100 active:scale-90 active:bg-white active:text-black"
          >
            {k === "del" ? (
              <svg width="18" height="15" viewBox="0 0 26 22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M8.5 2.5h13A2.5 2.5 0 0 1 24 5v12a2.5 2.5 0 0 1-2.5 2.5h-13L2 11l6.5-8.5Z" />
                <path d="m12.5 8 5 5m0-5-5 5" />
              </svg>
            ) : (
              k
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
