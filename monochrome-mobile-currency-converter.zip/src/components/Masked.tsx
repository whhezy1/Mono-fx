import { useRef, useState } from "react";
import { cn } from "../utils/cn";

interface MaskedProps {
  hidden: boolean;
  className?: string;
  children: React.ReactNode;
}

/**
 * Privacy mask — renders •••••• while "Hide Amounts" is on.
 * Tap to reveal for 4 seconds, then it re-masks automatically.
 */
export default function Masked({ hidden, className, children }: MaskedProps) {
  const [peek, setPeek] = useState(false);
  const timer = useRef<number | null>(null);

  if (!hidden) return <span className={className}>{children}</span>;

  const reveal = () => {
    setPeek(true);
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setPeek(false), 4000);
  };

  if (peek) {
    return (
      <span className={cn(className, "cursor-pointer")} onClick={reveal} title="Tap to re-hide">
        {children}
      </span>
    );
  }

  return (
    <button
      onClick={reveal}
      aria-label="Hidden amount — tap to reveal"
      className={cn(
        className,
        "cursor-pointer tracking-[0.2em] text-zinc-500 transition-colors duration-150 active:text-white"
      )}
    >
      ••••••
    </button>
  );
}
