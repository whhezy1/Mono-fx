interface InstallCardProps {
  onInstall: () => void;
  compact?: boolean;
}

/** Monochrome "Install App" card — hidden by the parent when unavailable. */
export default function InstallCard({ onInstall, compact }: InstallCardProps) {
  return (
    <div className="rounded-[1.5rem] border border-dashed border-zinc-500 bg-black p-4">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white text-black">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
            <rect x="6" y="2.5" width="12" height="19" rx="2.5" />
            <path d="M12 17.5v-6m0 0-2.4 2.4m2.4-2.4 2.4 2.4" />
            <path d="M10 5.5h4" />
          </svg>
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-display text-[14px] font-bold tracking-tight">INSTALL APP</p>
          <p className="mt-0.5 font-mono text-[7.5px] leading-relaxed tracking-[0.18em] text-zinc-500">
            {compact
              ? "HOME SCREEN · FULL SCREEN · OFFLINE"
              : "ADD MONO FX TO YOUR HOME SCREEN — LAUNCHES FULL SCREEN, WORKS OFFLINE"}
          </p>
        </div>
      </div>
      <button
        onClick={onInstall}
        className="mt-3 w-full rounded-full bg-white py-3 font-mono text-[9px] font-bold tracking-[0.3em] text-black transition-all duration-150 active:scale-[0.97]"
      >
        ⤓ INSTALL MONO FX
      </button>
    </div>
  );
}
