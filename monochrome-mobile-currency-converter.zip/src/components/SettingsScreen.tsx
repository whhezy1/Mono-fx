import { useState } from "react";
import type { AuthUser } from "../lib/auth";
import { initialsOf } from "../lib/auth";
import type { FontScale, NumberFormatStyle, PrecisionPref, UserSettings } from "../lib/settings";
import { formatRate, formatValue } from "../lib/money";
import { BUILD } from "../lib/version";
import { cn } from "../utils/cn";
import ConfirmModal from "./ConfirmModal";
import InstallCard from "./InstallCard";

interface SettingsScreenProps {
  user: AuthUser;
  settings: UserSettings;
  onSettings: (patch: Partial<UserSettings>) => void;
  from: string;
  to: string;
  liveRate: number | null;
  defaultBase: string;
  onUpdateAccount: (name: string, email: string) => string | null;
  onChangeBase: () => void;
  onTogglePasscode: () => void;
  onSpeakTest: () => void;
  onClearRateCache: () => void;
  onDeleteHistory: () => void;
  onDownloadCsv: () => void;
  onDownloadJson: () => void;
  onSignOut: () => void;
  onDeleteAccount: () => void;
  historyCount: number;
  /** Install-to-home-screen (auto-hidden in standalone/Capacitor). */
  canInstall: boolean;
  onInstall: () => void;
}

/* ------------------------------ building blocks --------------------------- */

function Card({
  title,
  icon,
  defaultOpen = true,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="rounded-[1.5rem] border border-line bg-panel">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between px-5 py-4"
      >
        <span className="flex items-center gap-2.5 font-mono text-[10px] font-bold tracking-[0.3em] text-zinc-300">
          {icon}
          {title}
        </span>
        <svg
          className={cn("h-3 w-3 text-zinc-500 transition-transform duration-300", open && "rotate-180")}
          viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden
        >
          <path d="m2.5 4.5 3.5 3.5 3.5-3.5" />
        </svg>
      </button>
      <div
        className={cn(
          "grid transition-all duration-300",
          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        )}
      >
        <div className="overflow-hidden">
          <div className="px-5 pb-5">{children}</div>
        </div>
      </div>
    </section>
  );
}

function ToggleRow({
  label,
  desc,
  value,
  onChange,
  extra,
}: {
  label: string;
  desc: string;
  value: boolean;
  onChange: () => void;
  extra?: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-line py-3.5 last:border-0">
      <div className="min-w-0">
        <p className="font-display text-[13px] font-semibold tracking-wide">{label}</p>
        <p className="mt-1 font-mono text-[8px] leading-relaxed tracking-[0.14em] text-zinc-500">
          {desc}
        </p>
        {extra}
      </div>
      <button
        role="switch"
        aria-checked={value}
        aria-label={label}
        onClick={onChange}
        className={cn(
          "relative mt-0.5 h-8 w-14 shrink-0 rounded-full border transition-colors duration-200",
          value ? "border-zinc-400 bg-white" : "border-zinc-600 bg-black"
        )}
      >
        <span
          className={cn(
            "absolute top-1/2 h-6 w-6 -translate-y-1/2 rounded-full transition-all duration-200",
            value ? "left-[calc(100%-1.625rem)] bg-black" : "left-1 bg-white"
          )}
        />
      </button>
    </div>
  );
}

function Segmented<T extends string | number>({
  options,
  value,
  onChange,
  ariaLabel,
}: {
  options: Array<[T, string]>;
  value: T;
  onChange: (v: T) => void;
  ariaLabel: string;
}) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} className="grid gap-1 rounded-2xl border border-line bg-black p-1" style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }}>
      {options.map(([v, label]) => (
        <button
          key={String(v)}
          role="radio"
          aria-checked={value === v}
          onClick={() => onChange(v)}
          className={cn(
            "rounded-xl py-2.5 font-mono text-[8.5px] font-bold tracking-wider transition-all duration-150 active:scale-[0.96]",
            value === v ? "bg-white text-black" : "text-zinc-500"
          )}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

const icon = (d: string) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d={d} />
  </svg>
);

/* --------------------------------- screen --------------------------------- */

export default function SettingsScreen(props: SettingsScreenProps) {
  const { user, settings, onSettings } = props;
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [acctMsg, setAcctMsg] = useState<{ err: boolean; text: string } | null>(null);
  const [confirm, setConfirm] = useState<null | "cache" | "history" | "signout" | "account">(null);

  const saveAccount = () => {
    const err = props.onUpdateAccount(name, email);
    setAcctMsg(err ? { err: true, text: err } : { err: false, text: "PROFILE SAVED ✓" });
  };

  const pairKey = `${props.from}/${props.to}`;
  const manualValue = settings.manualRates[pairKey] ?? "";

  const input =
    "w-full rounded-xl border border-line bg-black px-3.5 py-3 font-mono text-[11px] tracking-wider text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400";

  const dataBtn =
    "flex items-center justify-center gap-2 rounded-xl border border-line py-3.5 font-mono text-[8.5px] font-bold tracking-[0.18em] text-zinc-300 transition-all duration-150 active:scale-[0.96] active:bg-white active:text-black";

  return (
    <div className="animate-fade px-4">
      <div className="flex items-end justify-between">
        <div>
          <p className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">PREFERENCES</p>
          <h2 className="mt-1 font-display text-2xl font-bold tracking-tight">Settings</h2>
        </div>
        <span className="font-mono text-[8px] tracking-[0.25em] text-zinc-600">BUILD {BUILD}</span>
      </div>

      <div className="mt-4 space-y-3 pb-4">
        {props.canInstall && <InstallCard onInstall={props.onInstall} />}

        {/* ---------------- account & security ---------------- */}
        <Card title="ACCOUNT & SECURITY" icon={icon("M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM4.5 20a7.5 7.5 0 0 1 15 0")}>
          <div className="flex items-center gap-3.5">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-white font-display text-lg font-bold text-black">
              {initialsOf(name || user.name)}
            </div>
            <div className="min-w-0 flex-1 space-y-1.5">
              <input
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, 32))}
                aria-label="Display name"
                placeholder="DISPLAY NAME"
                className={input}
              />
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                aria-label="Email address"
                placeholder="EMAIL"
                type="email"
                className={input}
              />
            </div>
          </div>
          <p className="mt-1.5 font-mono text-[7.5px] tracking-[0.2em] text-zinc-600">
            AVATAR INITIALS AUTO-GENERATED FROM NAME
          </p>
          {acctMsg && (
            <p className={cn("mt-2 font-mono text-[8px] font-bold tracking-[0.2em]", acctMsg.err ? "animate-blink text-white" : "text-zinc-400")}>
              {acctMsg.err ? `⚠ ${acctMsg.text}` : acctMsg.text}
            </p>
          )}
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              onClick={saveAccount}
              className="rounded-xl bg-white py-3 font-mono text-[9px] font-bold tracking-[0.25em] text-black transition-all active:scale-[0.96]"
            >
              SAVE PROFILE
            </button>
            <button
              onClick={props.onChangeBase}
              className="flex items-center justify-center gap-2 rounded-xl border border-line py-3 font-mono text-[9px] font-bold tracking-[0.2em] text-zinc-300 transition-all active:scale-[0.96] active:bg-white active:text-black"
            >
              BASE · {props.defaultBase} ▾
            </button>
          </div>
        </Card>

        {/* ---------------- privacy & app lock ---------------- */}
        <Card title="PRIVACY & APP LOCK" icon={icon("M12 3 4.5 6v5c0 4.5 3 8.5 7.5 10 4.5-1.5 7.5-5.5 7.5-10V6L12 3Z")}>
          <ToggleRow
            label="HIDE AMOUNTS"
            desc="MASK BALANCES IN HISTORY, BASKETS & RECEIPTS AS •••••• — TAP ANY MASK TO REVEAL IT BRIEFLY"
            value={settings.hideAmounts}
            onChange={() => onSettings({ hideAmounts: !settings.hideAmounts })}
          />
          <ToggleRow
            label="4-DIGIT PASSCODE LOCK"
            desc="REQUIRE A PIN TO OPEN CONVERSION HISTORY & EXPENSE FOLDERS"
            value={settings.passcodeOn}
            onChange={props.onTogglePasscode}
          />
        </Card>

        {/* ---------------- accessibility ---------------- */}
        <Card title="ACCESSIBILITY" icon={icon("M12 5.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM4 8.5c5 1.5 11 1.5 16 0M12 10v5m0 0-3 6m3-6 3 6")}>
          <div className="border-b border-line py-3.5">
            <p className="font-display text-[13px] font-semibold tracking-wide">TEXT SIZE</p>
            <p className="mt-1 font-mono text-[8px] tracking-[0.14em] text-zinc-500">
              SCALES THE WHOLE CONSOLE — APPLIES INSTANTLY
            </p>
            <div className="mt-2.5">
              <Segmented<FontScale>
                ariaLabel="Text size"
                options={[["normal", "NORMAL"], ["large", "LARGE +15%"], ["xl", "X-LARGE +30%"]]}
                value={settings.fontScale}
                onChange={(v) => onSettings({ fontScale: v })}
              />
            </div>
          </div>

          <ToggleRow
            label="SPEAK CONVERSION RESULTS"
            desc="READS THE CONVERTED TOTAL & CURRENCY ALOUD AFTER EACH CALCULATION"
            value={settings.speakResults}
            onChange={() => onSettings({ speakResults: !settings.speakResults })}
            extra={
              <button
                onClick={props.onSpeakTest}
                className="mt-2 rounded-full border border-line px-3 py-1.5 font-mono text-[8px] font-bold tracking-[0.2em] text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
              >
                ▶ TEST VOICE
              </button>
            }
          />
          <ToggleRow
            label="REDUCE MOTION"
            desc="DISABLES THE SWAP FLIP, DRAWER SLIDES & RATE-TAPE MARQUEE"
            value={settings.reduceMotion}
            onChange={() => onSettings({ reduceMotion: !settings.reduceMotion })}
          />
          <ToggleRow
            label="KEYPAD FEEDBACK"
            desc="HAPTIC VIBRATION + SUBTLE CLICK SOUND ON EVERY KEY PRESS"
            value={settings.feedback}
            onChange={() => onSettings({ feedback: !settings.feedback })}
          />
        </Card>

        {/* ---------------- regional & precision ---------------- */}
        <Card title="REGIONAL & PRECISION" icon={icon("M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3.5 9h17M3.5 15h17M12 3c-4.5 4-4.5 14 0 18 4.5-4 4.5-14 0-18Z")}>
          <div className="border-b border-line py-3.5">
            <p className="font-display text-[13px] font-semibold tracking-wide">NUMBER FORMAT</p>
            <p className="mt-1 font-mono text-[8px] tracking-[0.14em] text-zinc-500">
              APPLIES TO RESULTS, INPUTS, BASKETS & RECEIPTS · CSV EXPORT STAYS DOT-DECIMAL
            </p>
            <div className="mt-2.5">
              <Segmented<NumberFormatStyle>
                ariaLabel="Number format"
                options={[["comma", "1,250.50 · COMMA"], ["dot", "1.250,50 · DOT"]]}
                value={settings.numberFormat}
                onChange={(v) => onSettings({ numberFormat: v })}
              />
            </div>
            <p className="mt-2.5 rounded-xl border border-line bg-black px-3.5 py-2.5 text-right font-display text-xl font-semibold tabular-nums">
              {formatValue(1250.5, "USD")} <span className="font-mono text-[9px] text-zinc-500">LIVE PREVIEW</span>
            </p>
          </div>

          <div className="py-3.5">
            <p className="font-display text-[13px] font-semibold tracking-wide">DECIMAL PRECISION</p>
            <p className="mt-1 font-mono text-[8px] tracking-[0.14em] text-zinc-500">
              AUTO ADAPTS PER CURRENCY · CRYPTO ALWAYS KEEPS 8 DP
            </p>
            <div className="mt-2.5">
              <Segmented<PrecisionPref>
                ariaLabel="Decimal precision"
                options={[["auto", "AUTO"], [2, "2 DP"], [4, "4 DP"], [6, "6 DP"]]}
                value={settings.precision}
                onChange={(v) => onSettings({ precision: v })}
              />
            </div>
            <p className="mt-2.5 rounded-xl border border-line bg-black px-3.5 py-2.5 text-right font-display text-xl font-semibold tabular-nums">
              {formatValue(1234.567891, "USD")} <span className="font-mono text-[9px] text-zinc-500">1234.567891</span>
            </p>
          </div>
        </Card>

        {/* ---------------- rates & data saver ---------------- */}
        <Card title="RATES & DATA SAVER" icon={icon("M4 7c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3ZM4 7v10c0 1.7 3.6 3 8 3s8-1.3 8-3V7M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3")}>
          <ToggleRow
            label="MANUAL / STREET RATE"
            desc={`OVERRIDE THE LIVE RATE FOR ${props.from}→${props.to} — FOR CASH & STREET EXCHANGE`}
            value={settings.manualRate}
            onChange={() => onSettings({ manualRate: !settings.manualRate })}
            extra={
              settings.manualRate ? (
                <div className="mt-2.5 flex items-center gap-2 rounded-xl border border-line bg-black px-3 py-2">
                  <span className="shrink-0 font-mono text-[9px] font-bold tracking-wider text-zinc-400">
                    1 {props.from} =
                  </span>
                  <input
                    value={manualValue}
                    onChange={(e) =>
                      onSettings({
                        manualRates: {
                          ...settings.manualRates,
                          [pairKey]: e.target.value.replace(/[^\d.]/g, "").slice(0, 14),
                        },
                      })
                    }
                    placeholder={props.liveRate != null ? `LIVE ${formatRate(props.liveRate)}` : "RATE"}
                    inputMode="decimal"
                    aria-label={`Manual rate for ${props.from} to ${props.to}`}
                    className="min-w-0 flex-1 bg-transparent text-right font-mono text-sm font-semibold tabular-nums text-white placeholder-zinc-600 outline-none"
                  />
                  <span className="shrink-0 font-mono text-[9px] font-bold text-zinc-400">{props.to}</span>
                </div>
              ) : undefined
            }
          />
          <ToggleRow
            label="DATA SAVER MODE"
            desc="PAUSES ALL BACKGROUND RATE POLLING — NOTHING FETCHES UNTIL YOU TAP REFRESH"
            value={settings.dataSaver}
            onChange={() => onSettings({ dataSaver: !settings.dataSaver })}
          />
        </Card>

        {/* ---------------- data controls ---------------- */}
        <Card title="DATA CONTROLS" icon={icon("M3 7h18M8 7V5a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m-11 0 1 13a1 1 0 0 0 1 .9h8a1 1 0 0 0 1-.9l1-13")}>
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button onClick={() => setConfirm("cache")} className={dataBtn}>
              ⊘ CLEAR RATE CACHE
            </button>
            <button onClick={() => setConfirm("history")} className={dataBtn}>
              ⌫ DELETE HISTORY
            </button>
            <button onClick={props.onDownloadCsv} className={dataBtn}>
              ↓ MY DATA · CSV
            </button>
            <button onClick={props.onDownloadJson} className={dataBtn}>
              ↓ MY DATA · JSON
            </button>
          </div>
          <p className="mt-2.5 font-mono text-[7.5px] leading-relaxed tracking-[0.18em] text-zinc-600">
            {props.historyCount} CONVERSIONS STORED · EVERYTHING LIVES IN THIS BROWSER
          </p>
        </Card>

        {/* ---------------- session ---------------- */}
        <Card title="SESSION" icon={icon("M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3M15 8l4 4-4 4m4-4H9")} defaultOpen={false}>
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => setConfirm("signout")}
              className="rounded-xl bg-white py-3.5 font-mono text-[9px] font-bold tracking-[0.25em] text-black transition-all active:scale-[0.96]"
            >
              SIGN OUT
            </button>
            <button
              onClick={() => setConfirm("account")}
              className="rounded-xl border border-dashed border-zinc-500 py-3.5 font-mono text-[9px] font-bold tracking-[0.2em] text-zinc-400 transition-all active:scale-[0.96] active:bg-white active:text-black"
            >
              DELETE ACCOUNT
            </button>
          </div>
        </Card>
      </div>

      {/* confirmations */}
      <ConfirmModal
        open={confirm === "cache"}
        title="Clear offline rate cache?"
        body="CACHED RATE PAYLOADS AND TREND SERIES ARE WIPED. LIVE RATES REFETCH ON YOUR NEXT MANUAL REFRESH."
        confirmLabel="CLEAR CACHE"
        onConfirm={props.onClearRateCache}
        onClose={() => setConfirm(null)}
      />
      <ConfirmModal
        open={confirm === "history"}
        title="Delete all conversion history?"
        body={`${props.historyCount} LOGGED CONVERSIONS WILL BE PERMANENTLY REMOVED. FOLDERS KEEP THEIR NAMES BUT LOSE THEIR ENTRIES.`}
        confirmLabel="DELETE ALL"
        onConfirm={props.onDeleteHistory}
        onClose={() => setConfirm(null)}
      />
      <ConfirmModal
        open={confirm === "signout"}
        title="Sign out?"
        body="YOUR DATA STAYS ON THIS DEVICE AND WILL BE HERE WHEN YOU SIGN BACK IN."
        confirmLabel="SIGN OUT"
        onConfirm={props.onSignOut}
        onClose={() => setConfirm(null)}
      />
      <ConfirmModal
        open={confirm === "account"}
        title="Delete this account?"
        body="THE ACCOUNT, ITS HISTORY, FOLDERS, WATCHLIST, ALERTS AND SETTINGS ARE ERASED FROM THIS DEVICE. THIS CANNOT BE UNDONE."
        confirmLabel="DELETE FOREVER"
        onConfirm={props.onDeleteAccount}
        onClose={() => setConfirm(null)}
      />
    </div>
  );
}
