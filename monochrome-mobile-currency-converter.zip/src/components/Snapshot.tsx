import Masked from "./Masked";
import { meta } from "../lib/currencies";
import { amountOf, crossRate, formatInput, formatValue } from "../lib/money";
import { cn } from "../utils/cn";

interface SnapshotProps {
  raw: string;
  from: string;
  to: string;
  rates: Record<string, number>;
  onSelect: (code: string) => void;
  /** Privacy mode — masks values until tapped. */
  hidden: boolean;
}

const TARGETS = ["EUR", "GBP", "JPY", "NGN", "BTC", "XAU", "INR", "CHF"];

/**
 * Exchange-board card: what the current amount buys across major markets.
 * Dotted leaders, mono figures — tap any row to make it the target.
 */
export default function Snapshot({ raw, from, to, rates, onSelect, hidden }: SnapshotProps) {
  const amount = amountOf(raw);
  const rows = TARGETS.filter((code) => code !== from).map((code) => {
    const r = crossRate(rates, from, code);
    return { code, value: r != null ? amount * r : null };
  });

  return (
    <section className="rounded-[1.75rem] border border-line bg-panel px-5 pt-4 pb-2">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">GLOBAL SNAPSHOT</p>
          <p className="mt-1 font-display text-lg font-semibold tracking-tight">
            What {formatInput(raw)} {from} buys
          </p>
        </div>
        <svg width="22" height="22" viewBox="0 0 24 24" className="mt-1 text-zinc-500" aria-hidden>
          <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.4" />
          <path d="M2.5 12h19M12 2.5c2.6 2.5 4 5.8 4 9.5s-1.4 7-4 9.5c-2.6-2.5-4-5.8-4-9.5s1.4-7 4-9.5Z" fill="none" stroke="currentColor" strokeWidth="1.1" />
        </svg>
      </div>

      <div className="mt-1.5">
        {rows.map(({ code, value }) => {
          const m = meta(code);
          const active = code === to;
          return (
            <button
              key={code}
              onClick={() => onSelect(code)}
              className={cn(
                "group -mx-2 flex w-[calc(100%+1rem)] items-center gap-2 rounded-xl border-b border-line px-2 py-2.5 text-left transition-colors last:border-0",
                "active:bg-white/[0.06]"
              )}
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-black font-display text-[7px] font-bold">
                {m.symbol}
              </span>
              <span className="flex shrink-0 items-center gap-1.5">
                <span className="font-display text-sm font-semibold tracking-wide">{code}</span>
                {active && (
                  <span className="rounded-full bg-white px-1.5 py-px font-mono text-[7px] font-semibold tracking-widest text-black">
                    TARGET
                  </span>
                )}
              </span>
              <span className="mx-1 min-w-4 flex-1 border-b border-dotted border-zinc-700" />
              <Masked
                hidden={hidden}
                className="shrink-0 font-mono text-[13px] font-medium tabular-nums text-white"
              >
                {value != null ? formatValue(value, code) : "—"}
              </Masked>
            </button>
          );
        })}
      </div>
    </section>
  );
}
