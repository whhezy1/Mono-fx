import { useEffect, useMemo, useRef, useState } from "react";
import type { History } from "../hooks/useHistory";
import { fmtDayShort, formatRate } from "../lib/money";
import { cn } from "../utils/cn";

interface TrendChartProps extends History {
  from: string;
  to: string;
}

const H = 128;
const PX = 4; // horizontal padding
const PY = 10; // vertical padding

/** Minimalist 7-day trend line — pure white on charcoal, scrubbable by touch. */
export default function TrendChart({ points, source, loading, from, to }: TrendChartProps) {
  const [hover, setHover] = useState<number | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const [W, setW] = useState(320);

  // Measure the container so the viewBox maps 1:1 (no stretched circles).
  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width;
      if (w && Math.abs(w - W) > 1) setW(Math.round(w));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [W]);

  const geom = useMemo(() => {
    if (points.length < 2) return null;
    const values = points.map((p) => p.value);
    let min = Math.min(...values);
    let max = Math.max(...values);
    if (min === max) {
      min *= 0.998;
      max *= 1.002;
    }
    const span = max - min;
    const x = (i: number) => PX + (i * (W - PX * 2)) / (points.length - 1);
    const y = (v: number) => PY + ((max - v) / span) * (H - PY * 2);
    const line = points
      .map((p, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(2)} ${y(p.value).toFixed(2)}`)
      .join(" ");
    const area = `${line} L${x(points.length - 1).toFixed(2)} ${H} L${x(0).toFixed(2)} ${H} Z`;
    return { min, max, x, y, line, area };
  }, [points, W]);

  const change = useMemo(() => {
    if (points.length < 2 || points[0].value === 0) return 0;
    return ((points[points.length - 1].value - points[0].value) / points[0].value) * 100;
  }, [points]);

  const stats = useMemo(() => {
    if (!points.length) return null;
    const values = points.map((p) => p.value);
    return {
      high: Math.max(...values),
      low: Math.min(...values),
      avg: values.reduce((a, b) => a + b, 0) / values.length,
    };
  }, [points]);

  const handleMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!geom) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const frac = (e.clientX - rect.left) / rect.width;
    const idx = Math.round(frac * (points.length - 1));
    setHover(Math.min(points.length - 1, Math.max(0, idx)));
  };

  const hp = hover !== null ? points[hover] : null;
  const hoverLeftPct = hover !== null && geom ? (geom.x(hover) / W) * 100 : 0;
  const up = change >= 0;

  return (
    <section className="rounded-[1.75rem] border border-line bg-panel">
      {/* header */}
      <div className="flex items-start justify-between px-5 pt-4">
        <div>
          <p className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">7-DAY TREND</p>
          <p className="mt-1 font-display text-lg font-semibold tracking-tight">
            {from} <span className="text-zinc-600">→</span> {to}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <span
            className={cn(
              "rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold tabular-nums",
              up ? "bg-white text-black" : "border border-zinc-500 text-white"
            )}
          >
            {up ? "▲" : "▼"} {Math.abs(change).toFixed(2)}%
          </span>
          <span className="font-mono text-[9px] tracking-[0.2em] text-zinc-600">
            {loading ? (
              <span className="animate-blink text-zinc-400">SYNCING…</span>
            ) : source === "live" ? (
              "ECB · LIVE"
            ) : source === "cache" ? (
              "CACHED"
            ) : (
              "ESTIMATED"
            )}
          </span>
        </div>
      </div>

      {/* chart */}
      <div
        ref={boxRef}
        className="relative mx-3 mt-2 cursor-crosshair touch-none select-none"
        onPointerMove={handleMove}
        onPointerDown={handleMove}
        onPointerLeave={() => setHover(null)}
      >
        {!geom ? (
          <div className="flex h-32 animate-pulse items-center justify-center rounded-xl bg-white/[0.04] font-mono text-[10px] tracking-[0.3em] text-zinc-600">
            LOADING SERIES…
          </div>
        ) : (
          <>
            <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="h-32 w-full">
              <defs>
                <linearGradient id="monoArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--fg)" stopOpacity="0.16" />
                  <stop offset="100%" stopColor="var(--fg)" stopOpacity="0" />
                </linearGradient>
              </defs>
              {/* hairline grid */}
              {[0.25, 0.5, 0.75].map((f) => (
                <line
                  key={f}
                  x1="0"
                  x2={W}
                  y1={H * f}
                  y2={H * f}
                  stroke="var(--fg)"
                  strokeOpacity="0.06"
                  strokeWidth="1"
                  vectorEffect="non-scaling-stroke"
                />
              ))}
              <path d={geom.area} fill="url(#monoArea)" />
              <path
                d={geom.line}
                fill="none"
                stroke="var(--fg)"
                strokeWidth="2"
                strokeLinejoin="round"
                strokeLinecap="round"
                vectorEffect="non-scaling-stroke"
              />
              {/* hover crosshair */}
              {hover !== null && (
                <line
                  x1={geom.x(hover)}
                  x2={geom.x(hover)}
                  y1="0"
                  y2={H}
                  stroke="var(--fg)"
                  strokeOpacity="0.35"
                  strokeWidth="1"
                  strokeDasharray="2 3"
                  vectorEffect="non-scaling-stroke"
                />
              )}
              {/* live endpoint */}
              <circle cx={geom.x(points.length - 1)} cy={geom.y(points[points.length - 1].value)} r="6" fill="none" stroke="var(--fg)" strokeOpacity="0.3" strokeWidth="1.5" />
              <circle cx={geom.x(points.length - 1)} cy={geom.y(points[points.length - 1].value)} r="3" fill="var(--fg)" />
              {/* hover point */}
              {hover !== null && (
                <circle
                  cx={geom.x(hover)}
                  cy={geom.y(points[hover].value)}
                  r="4"
                  fill="var(--bg)"
                  stroke="var(--fg)"
                  strokeWidth="2"
                />
              )}
            </svg>

            {/* tooltip */}
            {hp && (
              <div
                className="pointer-events-none absolute -top-1 z-10 -translate-x-1/2 rounded-md bg-white px-2 py-1 text-center shadow-[0_4px_16px_rgba(0,0,0,0.6)]"
                style={{ left: `${Math.min(Math.max(hoverLeftPct, 14), 86)}%` }}
              >
                <p className="font-mono text-[8px] tracking-widest text-black/50">
                  {fmtDayShort(hp.date).toUpperCase()}
                </p>
                <p className="font-mono text-[11px] font-semibold tabular-nums text-black">
                  {formatRate(hp.value)}
                </p>
              </div>
            )}
          </>
        )}
      </div>

      {/* axis labels */}
      {geom && (
        <div className="flex justify-between px-5 pt-1 font-mono text-[8px] tracking-widest text-zinc-600">
          <span>{fmtDayShort(points[0].date).toUpperCase()}</span>
          <span className="text-zinc-700">DRAG TO SCRUB</span>
          <span>{fmtDayShort(points[points.length - 1].date).toUpperCase()}</span>
        </div>
      )}

      {/* stats */}
      {stats && (
        <div className="mt-3 grid grid-cols-3 divide-x divide-line border-t border-line">
          {(
            [
              ["7D HIGH", stats.high],
              ["7D LOW", stats.low],
              ["AVERAGE", stats.avg],
            ] as const
          ).map(([label, v]) => (
            <div key={label} className="px-4 py-3 text-center">
              <p className="font-mono text-[8px] tracking-[0.25em] text-zinc-500">{label}</p>
              <p className="mt-1 font-mono text-[12px] font-medium tabular-nums text-white">
                {formatRate(v)}
              </p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
