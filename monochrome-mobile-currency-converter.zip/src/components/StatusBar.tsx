import { useEffect, useState } from "react";

/** Simulated iOS-style status bar with a live clock. */
export default function StatusBar() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 5000);
    return () => clearInterval(id);
  }, []);

  const time = now.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });

  return (
    <div className="flex items-center justify-between px-6 pt-3 pb-1 font-mono text-[11px] font-medium text-white">
      <span className="tracking-wider tabular-nums">{time}</span>
      <div className="flex items-center gap-1.5">
        <span className="mr-0.5 text-[9px] tracking-widest text-zinc-400">MONO·5G</span>
        {/* signal */}
        <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor" aria-hidden>
          <rect x="0" y="7" width="3" height="4" rx="0.8" />
          <rect x="4.5" y="5" width="3" height="6" rx="0.8" />
          <rect x="9" y="2.5" width="3" height="8.5" rx="0.8" />
          <rect x="13.5" y="0" width="3" height="11" rx="0.8" opacity="0.35" />
        </svg>
        {/* wifi */}
        <svg width="15" height="11" viewBox="0 0 15 11" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
          <path d="M1.5 4a9 9 0 0 1 12 0" />
          <path d="M3.8 6.6a5.6 5.6 0 0 1 7.4 0" />
          <circle cx="7.5" cy="9.2" r="1.1" fill="currentColor" stroke="none" />
        </svg>
        {/* battery */}
        <svg width="25" height="12" viewBox="0 0 25 12" fill="none" aria-hidden>
          <rect x="0.75" y="0.75" width="21" height="10.5" rx="3" stroke="currentColor" strokeOpacity="0.4" strokeWidth="1" />
          <rect x="2.5" y="2.5" width="15" height="7" rx="1.6" fill="currentColor" />
          <path d="M23.5 4v4a2.2 2.2 0 0 0 0-4Z" fill="currentColor" fillOpacity="0.4" />
        </svg>
      </div>
    </div>
  );
}
