import { useState } from "react";
import { DEMO_EMAIL } from "../lib/auth";
import { BUILD } from "../lib/version";
import { cn } from "../utils/cn";

interface AuthScreenProps {
  onSignIn: (email: string, pass: string) => Promise<string | null>;
  onSignUp: (name: string, email: string, pass: string) => Promise<string | null>;
  onDemo: () => Promise<void>;
  /** Credential-free guest mode (device-local). */
  onGuest: () => void;
  /** Wipes all locally-stored accounts (two-step confirmed in this screen). */
  onReset: () => void;
}

/** Minimalist monochrome sign-in / account creation. */
export default function AuthScreen({ onSignIn, onSignUp, onDemo, onGuest, onReset }: AuthScreenProps) {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const submit = async () => {
    if (busy) return;
    setBusy(true);
    setError(null);
    const err =
      mode === "in" ? await onSignIn(email, pass) : await onSignUp(name, email, pass);
    setError(err);
    setBusy(false);
  };

  const input =
    "w-full rounded-2xl border border-line bg-panel px-4 py-3.5 font-mono text-sm text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400";

  return (
    <div className="flex flex-1 flex-col justify-center px-6 pb-10">
      {/* brand */}
      <div className="mb-8 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-line">
          <svg width="34" height="34" viewBox="0 0 24 24" aria-hidden>
            <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.6" />
            <path d="M12 2a10 10 0 0 1 0 20Z" fill="currentColor" />
          </svg>
        </div>
        <h1 className="font-display text-3xl font-bold tracking-tight">
          MONO<span className="text-zinc-500">FX</span>
        </h1>
        <p className="mt-2 font-mono text-[9px] tracking-[0.4em] text-zinc-500">
          STRICTLY BLACK &amp; WHITE
        </p>
      </div>

      {/* mode switch */}
      <div className="mb-5 grid grid-cols-2 gap-1 rounded-full border border-line bg-panel p-1">
        {(
          [
            ["in", "SIGN IN"],
            ["up", "CREATE ACCOUNT"],
          ] as const
        ).map(([m, label]) => (
          <button
            key={m}
            onClick={() => {
              setMode(m);
              setError(null);
            }}
            className={cn(
              "rounded-full py-2.5 font-mono text-[10px] font-semibold tracking-[0.2em] transition-all duration-200",
              mode === m ? "bg-white text-black" : "text-zinc-500"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* form */}
      <div className="space-y-3">
        {mode === "up" && (
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="FULL NAME"
            autoComplete="name"
            className={input}
          />
        )}
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="EMAIL ADDRESS"
          type="email"
          autoComplete="email"
          className={input}
        />
        <div className="relative">
          <input
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            placeholder="PASSWORD · MIN 6 CHARS"
            type={showPass ? "text" : "password"}
            autoComplete={mode === "in" ? "current-password" : "new-password"}
            onKeyDown={(e) => e.key === "Enter" && void submit()}
            className={`${input} pr-12`}
          />
          {/* show / hide password */}
          <button
            type="button"
            onClick={() => setShowPass((v) => !v)}
            onMouseDown={(e) => e.preventDefault()} // keep focus in the field
            aria-label={showPass ? "Hide password" : "Show password"}
            className="absolute top-1/2 right-2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full text-zinc-500 transition-all duration-150 hover:text-zinc-300 active:scale-90 active:bg-white active:text-black"
          >
            {showPass ? (
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="2.8" />
                <path d="m4 4 16 16" />
              </svg>
            ) : (
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="2.8" />
              </svg>
            )}
          </button>
        </div>

        {error && (
          <div className="flex items-center gap-2 rounded-xl border border-zinc-600 px-3.5 py-2.5">
            <span className="h-1.5 w-1.5 shrink-0 animate-blink rounded-full bg-white" />
            <p className="font-mono text-[9px] font-medium tracking-[0.15em] text-zinc-300">
              {error}
            </p>
          </div>
        )}

        <button
          onClick={() => void submit()}
          disabled={busy}
          className="w-full rounded-full bg-white py-4 font-display text-sm font-bold tracking-[0.2em] text-black transition-all duration-150 active:scale-[0.97] disabled:opacity-50"
        >
          {busy ? "VERIFYING…" : mode === "in" ? "SIGN IN →" : "CREATE ACCOUNT →"}
        </button>

        <div className="flex items-center gap-3 py-1">
          <div className="h-px flex-1 bg-line" />
          <span className="font-mono text-[8px] tracking-[0.3em] text-zinc-600">OR</span>
          <div className="h-px flex-1 bg-line" />
        </div>

        <button
          onClick={() => void onDemo()}
          className="w-full rounded-full border border-line py-3.5 font-mono text-[10px] font-medium tracking-[0.2em] text-zinc-300 transition-all duration-150 active:scale-[0.97] active:bg-white active:text-black"
        >
          USE DEMO ACCOUNT · {DEMO_EMAIL}
        </button>

        <button
          onClick={onGuest}
          className="w-full rounded-full border border-dashed border-zinc-600 py-3 font-mono text-[10px] font-medium tracking-[0.25em] text-zinc-500 transition-all duration-150 active:scale-[0.97] active:border-solid active:bg-white active:text-black"
        >
          CONTINUE AS GUEST →
        </button>

        {/* escape hatch: stale/corrupted local accounts can be wiped (two-step) */}
        <button
          onClick={() => {
            if (confirmReset) {
              onReset();
              setConfirmReset(false);
              setError(null);
            } else {
              setConfirmReset(true);
              window.setTimeout(() => setConfirmReset(false), 2500);
            }
          }}
          className={cn(
            "w-full rounded-full py-2 font-mono text-[8px] tracking-[0.25em] transition-all duration-150",
            confirmReset ? "animate-blink text-white underline" : "text-zinc-600 active:text-zinc-400"
          )}
        >
          {confirmReset ? "TAP AGAIN TO ERASE ALL LOCAL ACCOUNTS" : "STUCK? RESET LOCAL ACCOUNTS"}
        </button>
      </div>

      <p className="mt-6 text-center font-mono text-[8px] leading-relaxed tracking-[0.2em] text-zinc-600">
        LOCAL MOCK AUTH · ACCOUNTS &amp; DATA NEVER LEAVE THIS DEVICE
        <br />
        NOTE · ACCOUNTS ARE PER-BROWSER / PER-URL · BUILD {BUILD}
        <br />© 2026 MONO FX · MIT LICENSE
      </p>
    </div>
  );
}
