interface InstallSheetProps {
  open: boolean;
  onClose: () => void;
}

/**
 * iOS Safari has no install event — this bottom sheet walks the user through
 * the native "Add to Home Screen" flow with monochrome pictograms.
 */
export default function InstallSheet({ open, onClose }: InstallSheetProps) {
  if (!open) return null;

  const stepIcon = "flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-line bg-black text-white";

  return (
    <div className="absolute inset-0 z-[60] flex items-end justify-center" role="dialog" aria-modal="true" aria-label="Install on iPhone">
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 w-full animate-fade bg-[rgba(0,0,0,0.72)]"
      />
      <div className="relative w-full animate-rise rounded-t-[2rem] border-t border-x border-line bg-panel px-5 pt-3 pb-8">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-zinc-700" />

        <div className="flex items-start justify-between">
          <div>
            <h2 className="font-display text-xl font-bold tracking-tight">Install on iPhone</h2>
            <p className="mt-1 font-mono text-[9px] tracking-[0.3em] text-zinc-500">
              SAFARI · THREE TAPS · TAKES 10 SECONDS
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close sheet"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
              <path d="m2 2 10 10M12 2 2 12" />
            </svg>
          </button>
        </div>

        <div className="mt-5 space-y-4">
          {/* step 1 — share */}
          <div className="flex items-center gap-4">
            <div className={stepIcon}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 3v12m0-12L8 7m4-4 4 4" />
                <path d="M5 11v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8" />
              </svg>
            </div>
            <div>
              <p className="font-display text-[14px] font-semibold tracking-wide">
                <span className="mr-2 font-mono text-[10px] text-zinc-500">01</span>Tap the Share icon
              </p>
              <p className="mt-0.5 font-mono text-[8px] tracking-[0.18em] text-zinc-500">
                SQUARE WITH AN UP ARROW · BOTTOM TOOLBAR
              </p>
            </div>
          </div>

          {/* step 2 — scroll */}
          <div className="flex items-center gap-4">
            <div className={stepIcon}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 4v13m0 0-3.5-3.5M12 17l3.5-3.5" />
                <path d="M5 20.5h14" />
              </svg>
            </div>
            <div>
              <p className="font-display text-[14px] font-semibold tracking-wide">
                <span className="mr-2 font-mono text-[10px] text-zinc-500">02</span>Scroll the sheet
              </p>
              <p className="mt-0.5 font-mono text-[8px] tracking-[0.18em] text-zinc-500">
                SWIPE UP THROUGH THE ACTION LIST
              </p>
            </div>
          </div>

          {/* step 3 — add */}
          <div className="flex items-center gap-4">
            <div className={stepIcon}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <rect x="4" y="4" width="16" height="16" rx="4" />
                <path d="M12 8.5v7M8.5 12h7" />
              </svg>
            </div>
            <div>
              <p className="font-display text-[14px] font-semibold tracking-wide">
                <span className="mr-2 font-mono text-[10px] text-zinc-500">03</span>Tap “Add to Home Screen”
              </p>
              <p className="mt-0.5 font-mono text-[8px] tracking-[0.18em] text-zinc-500">
                THEN CONFIRM “ADD” — THE ◐ ICON APPEARS
              </p>
            </div>
          </div>
        </div>

        <p className="mt-5 rounded-xl border border-line bg-black px-3.5 py-2.5 font-mono text-[8px] leading-relaxed tracking-[0.18em] text-zinc-500">
          NOTE · THIS WORKS IN SAFARI ONLY — CHROME &amp; FIREFOX ON IOS USE SAFARI’S
          ENGINE AND FOLLOW THE SAME STEPS
        </p>
      </div>
    </div>
  );
}
