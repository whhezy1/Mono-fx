import Masked from "./Masked";
import { meta } from "../lib/currencies";
import { amountOf, crossRate, fmtClock, formatInput, formatRate, formatValue } from "../lib/money";
import { cn } from "../utils/cn";

interface BasketScreenProps {
  raw: string;
  from: string;
  rates: Record<string, number>;
  /** Codes currently included in the basket. */
  codes: string[];
  onToggle: (code: string) => void;
  /** Loads a code as the converter target and returns home. */
  onSelect: (code: string) => void;
  onCopySummary: () => void;
  /** Returns to the classic 1-to-1 converter. */
  onBack: () => void;
  assets: { live: boolean; time: number | null };
  /** Privacy mode — masks values until tapped. */
  hidden: boolean;
}

/** Everything one amount buys — fiat majors plus crypto & metals, at once. */
export const BASKET_TARGETS = ["EUR", "GBP", "JPY", "NGN", "CNY", "INR", "BTC", "ETH", "XAU", "XAG"];

export default function BasketScreen({
  raw,
  from,
  rates,
  codes,
  onToggle,
  onSelect,
  onCopySummary,
  onBack,
  assets,
  hidden,
}: BasketScreenProps) {
  const amount = amountOf(raw);
  const included = new Set(codes);

  return (
    <div className="animate-fade px-4">
      <button
        onClick={onBack}
        className="mb-2 flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 font-mono text-[9px] font-semibold tracking-[0.2em] text-zinc-400 transition-all duration-150 active:scale-95 active:bg-white active:text-black"
      >
        ‹ 1-TO-1 CONVERTER
      </button>
      <div className="flex items-end justify-between">
        <div>
          <p className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">MULTI-CONVERT</p>
          <h2 className="mt-1 font-display text-2xl font-bold tracking-tight">Basket</h2>
        </div>
        <span
          className={cn(
            "flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[8px] tracking-[0.2em]",
            assets.live ? "border-zinc-400 text-zinc-300" : "border-line text-zinc-500"
          )}
        >
          <span className={cn("h-1 w-1 rounded-full", assets.live ? "animate-pulse-dot bg-white" : "bg-zinc-600")} />
          {assets.live ? `ASSETS LIVE ${assets.time ? fmtClock(assets.time) : ""}` : "ASSETS · REFERENCE"}
        </span>
      </div>

      <p className="mt-2 font-mono text-[10px] tracking-wider text-zinc-400">
        <span className="font-semibold text-white">{formatInput(raw)} {from}</span> BUYS ACROSS{" "}
        {codes.length} OF {BASKET_TARGETS.length} TARGETS · TICK ☑ TO INCLUDE
      </p>

      {/* rows */}
      <div className="mt-3 space-y-1.5">
        {BASKET_TARGETS.map((code, i) => {
          const m = meta(code);
          const r = crossRate(rates, from, code);
          const value = r != null ? amount * r : null;
          const on = included.has(code);
          return (
            <div
              key={code}
              className={cn(
                "animate-tick flex items-stretch overflow-hidden rounded-2xl border transition-colors",
                on ? "border-line bg-panel" : "border-line bg-panel opacity-50"
              )}
              style={{ animationDelay: `${i * 35}ms` }}
            >
              {/* include toggle */}
              <button
                onClick={() => onToggle(code)}
                aria-label={on ? `Remove ${code} from basket` : `Add ${code} to basket`}
                className="flex w-11 shrink-0 items-center justify-center border-r border-line font-mono text-sm transition-all active:bg-white active:text-black"
              >
                {on ? "■" : "□"}
              </button>

              {/* load as target */}
              <button
                onClick={() => onSelect(code)}
                className="group flex min-w-0 flex-1 items-center gap-2.5 px-3 py-3 text-left transition-colors active:bg-white/[0.06]"
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-black font-display text-[9px] font-bold">
                  {m.symbol}
                </span>
                <span className="min-w-0">
                  <span className="block font-display text-[13px] font-semibold tracking-wide">
                    {code}
                    <span className="ml-1.5 font-mono text-[8px] font-normal tracking-widest text-zinc-600">
                      {m.country.toUpperCase()}
                    </span>
                  </span>
                  <span className="block font-mono text-[8px] tabular-nums text-zinc-500">
                    1 {from} = {r != null ? formatRate(r) : "—"} {code}
                  </span>
                </span>
                <span className="mx-1 min-w-3 flex-1 self-center border-b border-dotted border-zinc-700" />
                <span className="shrink-0 text-right">
                  <Masked
                    hidden={hidden}
                    className="block font-display text-[15px] font-bold tabular-nums"
                  >
                    {value != null ? formatValue(value, code) : "—"}
                  </Masked>
                  <span className="block font-mono text-[8px] tracking-widest text-zinc-500">{code}</span>
                </span>
              </button>
            </div>
          );
        })}
      </div>

      <button
        onClick={onCopySummary}
        disabled={codes.length === 0}
        className="mt-4 w-full rounded-full bg-white py-3.5 font-mono text-[10px] font-bold tracking-[0.25em] text-black transition-all active:scale-[0.97] disabled:opacity-30"
      >
        ⧉ COPY BASKET SUMMARY
      </button>
      <p className="mt-3 pb-2 text-center font-mono text-[8px] tracking-[0.2em] text-zinc-600">
        TAP A ROW TO MAKE IT THE CONVERTER TARGET
      </p>
    </div>
  );
}
