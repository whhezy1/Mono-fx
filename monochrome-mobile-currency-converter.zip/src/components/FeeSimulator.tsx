import { cn } from "../utils/cn";

interface FeeSimulatorProps {
  feePct: number; // active preset (0 when custom)
  isCustom: boolean;
  custom: string;
  onPreset: (pct: number) => void;
  onCustom: (s: string) => void;
}

const PRESETS: Array<[number, string]> = [
  [0, "MID-MKT"],
  [1.5, "1.5%"],
  [3, "3%"],
  [5, "5%"],
];

/**
 * Bank & card markup simulator — reveals the hidden spread between the
 * mid-market rate and what banks/card issuers typically apply.
 */
export default function FeeSimulator({ feePct, isCustom, custom, onPreset, onCustom }: FeeSimulatorProps) {
  return (
    <div className="mt-3">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[8px] tracking-[0.3em] text-zinc-500">
          BANK / CARD MARKUP
        </span>
        <span className="font-mono text-[8px] tracking-[0.2em] text-zinc-600">
          SIMULATION ONLY
        </span>
      </div>
      <div className="mt-1.5 grid grid-cols-5 gap-1">
        {PRESETS.map(([p, label]) => (
          <button
            key={p}
            onClick={() => onPreset(p)}
            className={cn(
              "rounded-full border py-1.5 font-mono text-[8px] font-bold tracking-wider transition-all duration-150 active:scale-90",
              !isCustom && feePct === p
                ? "border-white bg-white text-black"
                : "border-line text-zinc-400"
            )}
          >
            {label}
          </button>
        ))}
        <button
          onClick={() => onCustom("")}
          className={cn(
            "rounded-full border py-1.5 font-mono text-[8px] font-bold tracking-wider transition-all duration-150 active:scale-90",
            isCustom ? "border-white bg-white text-black" : "border-line text-zinc-400"
          )}
        >
          CUSTOM
        </button>
      </div>
      {isCustom && (
        <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-line bg-black px-3 py-1.5">
          <span className="font-mono text-[8px] tracking-[0.25em] text-zinc-500">MARKUP</span>
          <input
            value={custom}
            onChange={(e) => onCustom(e.target.value.replace(/[^\d.]/g, "").slice(0, 5))}
            placeholder="0.0"
            inputMode="decimal"
            className="min-w-0 flex-1 bg-transparent text-right font-mono text-sm font-semibold tabular-nums text-white placeholder-zinc-600 outline-none"
          />
          <span className="font-mono text-xs font-bold text-zinc-400">%</span>
        </div>
      )}
    </div>
  );
}
