import { useState } from "react";
import type { AuthUser } from "../lib/auth";
import type { Theme } from "../hooks/useTheme";
import { meta } from "../lib/currencies";
import { flagOf } from "../lib/flags";
import { cn } from "../utils/cn";

interface ProfileScreenProps {
  user: AuthUser;
  theme: Theme;
  onToggleTheme: () => void;
  favorites: string[];
  /** Default base currency applied on sign-in. */
  defaultBase: string;
  onChangeBase: () => void;
  stats: { pairs: number; alerts: number; conversions: number };
  onClearData: () => void;
  onSignOut: () => void;
  onOpenSettings: () => void;
}

/** Account card, defaults, appearance, pinned currencies and data controls. */
export default function ProfileScreen({
  user,
  theme,
  onToggleTheme,
  favorites,
  defaultBase,
  onChangeBase,
  stats,
  onClearData,
  onSignOut,
  onOpenSettings,
}: ProfileScreenProps) {
  const [confirmWipe, setConfirmWipe] = useState(false);
  const baseMeta = meta(defaultBase);

  return (
    <div className="animate-fade px-4">
      <p className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">ACCOUNT</p>
      <h2 className="mt-1 font-display text-2xl font-bold tracking-tight">Profile</h2>

      {/* identity card */}
      <section className="mt-4 rounded-[1.75rem] border border-line bg-panel p-5">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full border border-line bg-black">
            <svg width="34" height="34" viewBox="0 0 24 24" aria-hidden>
              <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.5" />
              <path d="M12 2a10 10 0 0 1 0 20Z" fill="currentColor" />
            </svg>
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-xl font-bold tracking-tight">{user.name}</p>
            <p className="truncate font-mono text-[10px] tracking-wider text-zinc-500">{user.email}</p>
            <p className="mt-1 font-mono text-[8px] tracking-[0.25em] text-zinc-600">
              MEMBER SINCE{" "}
              {new Date(user.createdAt)
                .toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
                .toUpperCase()}{" "}
              · ID {user.id.toUpperCase()}
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 divide-x divide-line rounded-2xl border border-line">
          {(
            [
              ["CONVERSIONS", stats.conversions],
              ["WATCHED", stats.pairs],
              ["ALERT RULES", stats.alerts],
            ] as const
          ).map(([label, n]) => (
            <div key={label} className="px-2 py-3 text-center">
              <p className="font-display text-xl font-bold tabular-nums">{n}</p>
              <p className="mt-0.5 font-mono text-[7px] tracking-[0.25em] text-zinc-500">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* defaults */}
      <section className="mt-3 rounded-[1.75rem] border border-line bg-panel px-5 py-4">
        <p className="font-display text-sm font-semibold tracking-wide">Defaults</p>
        <button
          onClick={onChangeBase}
          className="mt-3 flex w-full items-center justify-between rounded-2xl border border-line bg-black px-4 py-3.5 transition-all active:scale-[0.98] active:border-zinc-400"
        >
          <span className="text-left">
            <span className="block font-mono text-[8px] tracking-[0.3em] text-zinc-500">
              BASE CURRENCY · APPLIED ON SIGN-IN
            </span>
            <span className="mt-1 flex items-center gap-2 font-display text-base font-bold tracking-wide">
              <span className="flag-mono text-lg leading-none">{flagOf(defaultBase)}</span>
              {defaultBase}
              <span className="font-mono text-[9px] font-normal tracking-wider text-zinc-500">
                {baseMeta.name.toUpperCase()}
              </span>
            </span>
          </span>
          <svg className="h-3.5 w-3.5 text-zinc-500" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
            <path d="m2.5 4.5 3.5 3.5 3.5-3.5" />
          </svg>
        </button>
      </section>

      {/* appearance */}
      <section className="mt-3 rounded-[1.75rem] border border-line bg-panel px-5 py-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-display text-sm font-semibold tracking-wide">Appearance</p>
            <p className="mt-0.5 font-mono text-[9px] tracking-[0.2em] text-zinc-500">
              DUAL MONOCHROME · SAVED TO THIS DEVICE
            </p>
          </div>
          <button
            onClick={onToggleTheme}
            role="switch"
            aria-checked={theme === "light"}
            className={cn(
              "relative h-9 w-[4.2rem] rounded-full border transition-colors duration-300",
              theme === "light" ? "border-zinc-400 bg-white" : "border-zinc-600 bg-black"
            )}
          >
            <span
              className={cn(
                "absolute top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-[11px] transition-all duration-300",
                theme === "light" ? "left-[calc(100%-2rem)] bg-black text-white" : "left-1 bg-white text-black"
              )}
            >
              {theme === "light" ? "◑" : "◐"}
            </span>
          </button>
        </div>
      </section>

      {/* pinned currencies */}
      <section className="mt-3 rounded-[1.75rem] border border-line bg-panel px-5 py-4">
        <p className="font-display text-sm font-semibold tracking-wide">Pinned currencies</p>
        <p className="mt-0.5 font-mono text-[9px] tracking-[0.2em] text-zinc-500">STARRED IN THE CURRENCY SHEET</p>
        {favorites.length === 0 ? (
          <p className="mt-3 font-mono text-[9px] tracking-[0.2em] text-zinc-600">NONE PINNED YET</p>
        ) : (
          <div className="mt-3 flex flex-wrap gap-2">
            {favorites.map((code) => (
              <span
                key={code}
                className="flex items-center gap-1.5 rounded-full border border-line bg-black px-3 py-1.5 font-mono text-[10px] font-medium tracking-wider"
              >
                <span className="flag-mono text-xs leading-none">{flagOf(code)}</span>
                {code}
              </span>
            ))}
          </div>
        )}
      </section>

      {/* data controls */}
      <section className="mt-3 rounded-[1.75rem] border border-line bg-panel px-5 py-4">
        <p className="font-display text-sm font-semibold tracking-wide">Data</p>
        <div className="mt-3 space-y-2">
          <button
            onClick={onOpenSettings}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-line py-3 font-mono text-[9px] font-bold tracking-[0.25em] text-zinc-300 transition-all active:scale-[0.98] active:bg-white active:text-black"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
              <circle cx="12" cy="12" r="3.2" />
              <path d="M12 2.8v2.6M12 18.6v2.6M2.8 12h2.6M18.6 12h2.6M5.5 5.5l1.8 1.8M16.7 16.7l1.8 1.8M18.5 5.5l-1.8 1.8M7.3 16.7l-1.8 1.8" />
            </svg>
            PRIVACY · ACCESSIBILITY · DATA
          </button>
          <button
            onClick={() => {
              if (confirmWipe) {
                onClearData();
                setConfirmWipe(false);
              } else {
                setConfirmWipe(true);
                window.setTimeout(() => setConfirmWipe(false), 2500);
              }
            }}
            className={cn(
              "w-full rounded-xl border py-3 font-mono text-[9px] font-bold tracking-[0.25em] transition-all active:scale-[0.98]",
              confirmWipe
                ? "animate-blink border-white bg-white text-black"
                : "border-line text-zinc-300 active:bg-white active:text-black"
            )}
          >
            {confirmWipe ? "TAP AGAIN TO ERASE EVERYTHING" : "ERASE MY HISTORY, PAIRS & ALERTS"}
          </button>
          <button
            onClick={onSignOut}
            className="w-full rounded-xl bg-white py-3 font-mono text-[9px] font-bold tracking-[0.3em] text-black transition-all active:scale-[0.98]"
          >
            SIGN OUT →
          </button>
        </div>
      </section>

      <p className="mt-5 pb-4 text-center font-mono text-[8px] leading-relaxed tracking-[0.25em] text-zinc-600">
        MOCK LOCAL AUTH · YOUR DATA NEVER LEAVES THIS DEVICE
      </p>
    </div>
  );
}
