import { crossRate, formatRate } from "../lib/money";
import { cn } from "../utils/cn";

export interface WatchPair {
  id: string;
  from: string;
  to: string;
}

interface WatchlistPanelProps {
  pairs: WatchPair[];
  rates: Record<string, number>;
  onPinCurrent: () => void;
  onLoad: (from: string, to: string) => void;
  onRemove: (id: string) => void;
}

/** Pinned currency pairs with live rates — tap to load into the converter. */
export default function WatchlistPanel({
  pairs,
  rates,
  onPinCurrent,
  onLoad,
  onRemove,
}: WatchlistPanelProps) {
  return (
    <div>
      <button
        onClick={onPinCurrent}
        className="mb-1.5 w-full rounded-xl border border-dashed border-zinc-600 py-2.5 font-mono text-[9px] font-medium tracking-[0.25em] text-zinc-400 transition-all duration-150 active:scale-[0.97] active:border-zinc-400 active:text-white"
      >
        + PIN CURRENT PAIR
      </button>

      {pairs.length === 0 ? (
        <p className="py-2 text-center font-mono text-[9px] tracking-[0.2em] text-zinc-600">
          NO PAIRS PINNED YET
        </p>
      ) : (
        pairs.map((p) => {
          const r = crossRate(rates, p.from, p.to);
          return (
            <div
              key={p.id}
              className="mb-1 flex items-center rounded-xl border border-line bg-black pr-1 transition-colors"
            >
              <button
                onClick={() => onLoad(p.from, p.to)}
                className="flex min-w-0 flex-1 items-center gap-2 px-3 py-2.5 text-left active:bg-white/[0.06]"
              >
                <span className="font-display text-[13px] font-semibold tracking-wide">
                  {p.from}
                  <span className="text-zinc-600">/</span>
                  {p.to}
                </span>
                <span className="mx-1 min-w-3 flex-1 border-b border-dotted border-zinc-700" />
                <span className="font-mono text-[11px] font-medium tabular-nums">
                  {r != null ? formatRate(r) : "—"}
                </span>
              </button>
              <button
                onClick={() => onRemove(p.id)}
                aria-label={`Remove ${p.from}/${p.to}`}
                className={cn(
                  "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-zinc-600",
                  "transition-all duration-150 active:scale-75 active:bg-white active:text-black"
                )}
              >
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
                  <path d="m1.5 1.5 7 7m0-7-7 7" />
                </svg>
              </button>
            </div>
          );
        })
      )}
    </div>
  );
}
