/**
 * Monochrome brand glyphs for the receipt share grid — simplified
 * line/fill paths in currentColor so they invert with the theme.
 */

interface IconProps {
  size?: number;
}

const dims = (size: number) => ({ width: size, height: size, "aria-hidden": true as const });

export const XIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.8 3H21l-6.9 7.9L22.2 21h-6.4l-5-6.5L5.1 21H1.9l7.4-8.5L1.5 3h6.6l4.5 5.9L17.8 3zm-1.2 16.1h1.8L7.4 4.8H5.5l11.1 14.3z" />
  </svg>
);

export const WhatsAppIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.4A10 10 0 1 0 12 2zm5.2 14.2c-.2.6-1.2 1.2-1.7 1.2-.4.1-1 .2-3.3-.7-2.9-1.2-4.8-4.1-4.9-4.3-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2 0 .4-.1.5l-.5.6c-.1.2-.2.4 0 .6a8 8 0 0 0 3.6 3.2c.3.1.4.1.6-.1l.8-1c.2-.3.4-.2.6-.1l2 1c.3.1.5.2.5.4 0 .1 0 .7-.2 1.2z" />
  </svg>
);

export const TelegramIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="currentColor">
    <path d="M21.7 3.3 2.9 10.6c-1 .4-1 1.1 0 1.4l4.8 1.5 1.8 5.6c.3.8.8 1 1.5.5l2.6-2.4 4.9 3.6c.8.5 1.4.2 1.6-.8l2.6-15.4c.3-1.2-.4-1.7-1-1.3zM8.5 13.5l9.2-5.8c.5-.3.9.2.5.5l-7.6 6.9-.3 3.2-1.8-4.8z" />
  </svg>
);

export const FacebookIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="currentColor">
    <path d="M13.4 21.5v-8h2.7l.4-3.1h-3.1V8.4c0-.9.3-1.5 1.6-1.5h1.6V4.1c-.3 0-1.3-.1-2.4-.1-2.4 0-4 1.4-4 4.1v2.3H7.5v3.1h2.7v8h3.2z" />
  </svg>
);

export const LinkedInIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="currentColor">
    <path d="M6.8 8.7H3.6V20h3.2V8.7zM5.2 7.3a1.9 1.9 0 1 0 0-3.7 1.9 1.9 0 0 0 0 3.7zM20.4 13.7c0-3-1.6-4.4-3.7-4.4-1.7 0-2.5.9-2.9 1.6V8.7h-3.2V20h3.2v-5.9c0-1.4.7-2.3 1.8-2.3 1.1 0 1.6.8 1.6 2.3V20h3.2v-6.3z" />
  </svg>
);

export const RedditIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="14.5" r="6" />
    <path d="m12.4 8.7 1-4.4 2.8.7" />
    <circle cx="16.3" cy="5" r="1.1" fill="currentColor" stroke="none" />
    <circle cx="9.7" cy="13.6" r="1" fill="currentColor" stroke="none" />
    <circle cx="14.3" cy="13.6" r="1" fill="currentColor" stroke="none" />
    <path d="M9.6 16.6c1.5 1.1 3.3 1.1 4.8 0" />
    <path d="M6.4 11.3 4.9 9.9M17.6 11.3l1.5-1.4" />
  </svg>
);

export const EmailIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="5" width="18" height="14" rx="2" />
    <path d="m3.5 7 8.5 6 8.5-6" />
  </svg>
);

export const SmsIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12a8.5 8.5 0 0 1-12.4 7.5L3 21l1.5-5.6A8.5 8.5 0 1 1 21 12Z" />
    <circle cx="8.5" cy="12" r="1" fill="currentColor" stroke="none" />
    <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
    <circle cx="15.5" cy="12" r="1" fill="currentColor" stroke="none" />
  </svg>
);

export const SnapchatIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2.8c-3.2 0-5.5 2.4-5.5 5.7v2.8c-.6.2-1.4-.2-1.9-.1-.6.2-.7.7-.4 1.1.4.6 1.4 1 2.1 1.3-.2 1.1-1.1 2.2-2 2.8-.5.3-.6.9 0 1.1.9.4 2.1.4 2.7.7.3 1 .8 2.2 2.2 2.2 1.1 0 1.8-.6 2.8-.6s1.7.6 2.8.6c1.4 0 1.9-1.2 2.2-2.2.6-.3 1.8-.3 2.7-.7.6-.2.5-.8 0-1.1-.9-.6-1.8-1.7-2-2.8.7-.3 1.7-.7 2.1-1.3.3-.4.2-.9-.4-1.1-.5-.1-1.3.3-1.9.1V8.5c0-3.3-2.3-5.7-5.5-5.7z" />
  </svg>
);

export const InstagramIcon = ({ size = 15 }: IconProps) => (
  <svg {...dims(size)} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
    <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
    <circle cx="12" cy="12" r="3.8" />
    <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none" />
  </svg>
);
