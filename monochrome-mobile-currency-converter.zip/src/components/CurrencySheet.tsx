import { useEffect, useMemo, useRef, useState } from "react";
import { CURRENCIES, meta } from "../lib/currencies";
import { crossRate, formatRate } from "../lib/money";
import { cn } from "../utils/cn";

export type SheetSide = "from" | "to" | "base";

interface CurrencySheetProps {
  side: SheetSide | null;
  from: string;
  to: string;
  /** Current default base currency (used when side === "base"). */
  base: string;
  rates: Record<string, number>;
  favorites: string[];
  onSelect: (code: string) => void;
  onToggleFavorite: (code: string) => void;
  onClose: () => void;
}

function StarIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="15" height="15" viewBox="0 0 20 20" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" aria-hidden>
      <path d="M10 2.6l2.25 4.55 5.02.73-3.63 3.54.86 5-4.5-2.37-4.5 2.37.86-5L2.73 7.88l5.02-.73L10 2.6z" />
    </svg>
  );
}

/** Full-height bottom sheet with live search + pinnable currencies. */
export default function CurrencySheet({
  side,
  from,
  to,
  base,
  rates,
  favorites,
  onSelect,
  onToggleFavorite,
  onClose,
}: CurrencySheetProps) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (side) {
      setQuery("");
      const t = setTimeout(() => inputRef.current?.focus(), 250);
      return () => clearTimeout(t);
    }
  }, [side]);

  useEffect(() => {
    if (!side) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [side, onClose]);

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return CURRENCIES;
    return CURRENCIES.filter(
      (c) =>
        c.code.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.country.toLowerCase().includes(q) ||
        c.symbol.toLowerCase().includes(q)
    );
  }, [query]);

  if (!side) return null;

  const current = side === "base" ? base : side === "from" ? from : to;
  const other = side === "base" ? "" : side === "from" ? to : from;
  const favSet = new Set(favorites);
  const pinned = matches.filter((c) => favSet.has(c.code));
  const rest = matches.filter((c) => !favSet.has(c.code));

  const renderRow = (c: (typeof CURRENCIES)[number]) => {
    const selected = c.code === current;
    const isOther = c.code === other;
    const perUsd = crossRate(rates, "USD", c.code);
    const faved = favSet.has(c.code);
    return (
      <div
        key={c.code}
        className={cn(
          "flex items-center rounded-2xl pr-1 transition-all duration-100",
          selected ? "bg-white text-black" : "text-white active:bg-zinc-800/80"
        )}
      >
        <button
          onClick={() => onSelect(c.code)}
          className="flex min-w-0 flex-1 items-center gap-3 px-3 py-3 text-left"
        >
          <span
            className={cn(
              "flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border font-display text-[10px] font-bold",
              selected ? "border-black/25 bg-black text-white" : "border-line bg-black text-white"
            )}
          >
            {meta(c.code).symbol}
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex items-center gap-2">
              <span className="font-display text-[15px] font-semibold tracking-wide">
                {c.code}
              </span>
              {isOther && (
                <span
                  className={cn(
                    "rounded-full border px-1.5 py-px font-mono text-[8px] tracking-widest",
                    selected ? "border-black/30 text-black/60" : "border-zinc-600 text-zinc-400"
                  )}
                >
                  {side === "from" ? "TARGET" : "SOURCE"}
                </span>
              )}
            </span>
            <span
              className={cn(
                "block truncate text-xs",
                selected ? "text-black/60" : "text-zinc-500"
              )}
            >
              {c.name} · {c.country}
            </span>
          </span>
          <span className="shrink-0 text-right">
            <span className="block font-mono text-xs font-medium tabular-nums">
              {c.code === "USD" ? "BASE" : perUsd ? formatRate(perUsd) : "—"}
            </span>
            <span
              className={cn(
                "block font-mono text-[8px] tracking-widest",
                selected ? "text-black/50" : "text-zinc-600"
              )}
            >
              {c.code === "USD" ? "REFERENCE" : "PER 1 USD"}
            </span>
          </span>
        </button>
        <button
          onClick={() => onToggleFavorite(c.code)}
          aria-label={faved ? `Unpin ${c.code}` : `Pin ${c.code}`}
          className={cn(
            "flex h-11 w-9 shrink-0 items-center justify-center rounded-xl transition-all duration-150 active:scale-75",
            selected ? "text-black/70" : faved ? "text-white" : "text-zinc-600"
          )}
        >
          <StarIcon filled={faved} />
        </button>
      </div>
    );
  };

  return (
    <div className="absolute inset-0 z-50" role="dialog" aria-modal="true">
      {/* backdrop */}
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 w-full animate-fade bg-[rgba(0,0,0,0.7)]"
      />

      {/* panel */}
      <div className="absolute inset-x-0 bottom-0 flex max-h-[85%] animate-rise flex-col rounded-t-[2rem] border-t border-x border-line bg-panel">
        <div className="mx-auto mt-3 h-1 w-10 shrink-0 rounded-full bg-zinc-700" />

        <div className="flex items-start justify-between px-5 pt-3 pb-2">
          <div>
            <h2 className="font-display text-xl font-bold tracking-tight">
              Select currency
            </h2>
            <p className="mt-0.5 font-mono text-[9px] tracking-[0.3em] text-zinc-500">
              {CURRENCIES.length} CURRENCIES · SET AS{" "}
              {side === "base"
                ? "DEFAULT BASE CURRENCY"
                : side === "from"
                  ? "SOURCE · YOU SEND"
                  : "TARGET · THEY GET"}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close sheet"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
              <path d="m2 2 10 10M12 2 2 12" />
            </svg>
          </button>
        </div>

        {/* search */}
        <div className="relative px-4 pb-3">
          <svg className="pointer-events-none absolute top-1/2 left-8 h-4 w-4 -translate-y-[calc(50%+6px)] text-zinc-500" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
            <circle cx="7" cy="7" r="4.5" />
            <path d="m10.5 10.5 3.5 3.5" />
          </svg>
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search code, country or name…"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            className="w-full rounded-2xl border border-line bg-black py-3.5 pr-11 pl-11 font-mono text-sm text-white placeholder-zinc-600 transition-colors outline-none focus:border-zinc-400"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="absolute top-1/2 right-8 flex h-6 w-6 -translate-y-[calc(50%+6px)] items-center justify-center rounded-full bg-zinc-800 text-zinc-300 transition-colors active:bg-white active:text-black"
            >
              <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
                <path d="m1.5 1.5 7 7m0-7-7 7" />
              </svg>
            </button>
          )}
        </div>

        {/* list */}
        <div className="no-scrollbar flex-1 overflow-y-auto px-3 pb-8">
          {matches.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-14 text-center">
              <span className="font-display text-3xl font-bold text-zinc-700">∅</span>
              <p className="font-mono text-[11px] tracking-wider text-zinc-500">
                NO CURRENCY MATCHES “{query.toUpperCase()}”
              </p>
            </div>
          ) : (
            <>
              {pinned.length > 0 && (
                <>
                  <p className="px-3 pt-1 pb-1.5 font-mono text-[8px] tracking-[0.3em] text-zinc-600">
                    ★ PINNED — {pinned.length}
                  </p>
                  {pinned.map(renderRow)}
                  <div className="mx-3 my-2 h-px bg-line" />
                </>
              )}
              <p className="px-3 pt-1 pb-1.5 font-mono text-[8px] tracking-[0.3em] text-zinc-600">
                ALL CURRENCIES — {rest.length}
              </p>
              {favorites.length === 0 && (
                <p className="px-3 pb-2 font-mono text-[9px] tracking-wider text-zinc-600">
                  TIP · TAP ★ TO PIN FREQUENT CURRENCIES HERE
                </p>
              )}
              {rest.map(renderRow)}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
