import { useEffect, useState } from "react";
import type { ExpenseFolder } from "../lib/folders";
import { formatValue } from "../lib/money";
import { cn } from "../utils/cn";

export type FolderSheetState =
  | { mode: "manage" }
  | { mode: "assign"; entryId: string }
  | null;

interface FolderSheetProps {
  state: FolderSheetState;
  folders: ExpenseFolder[];
  defaultCurrency: string;
  spendOf: (f: ExpenseFolder) => number;
  folderIdOfEntry: (entryId: string) => string | null;
  onCreate: (name: string, budget: number) => void;
  onDelete: (id: string) => void;
  onAssign: (folderId: string | null) => void;
  onClose: () => void;
}

/** Monochrome budget bar for a folder. */
export function BudgetBar({ spend, budget }: { spend: number; budget: number }) {
  const pct = budget > 0 ? Math.min(100, (spend / budget) * 100) : 0;
  const over = budget > 0 && spend > budget;
  return (
    <div className="h-1 w-full overflow-hidden rounded-full bg-zinc-800">
      <div
        className={cn("h-full rounded-full bg-white", over && "animate-blink")}
        style={{ width: budget > 0 ? `${pct}%` : "0%" }}
      />
    </div>
  );
}

/** Bottom sheet: manage folders (create/delete/budget) or assign an entry. */
export default function FolderSheet({
  state,
  folders,
  defaultCurrency,
  spendOf,
  folderIdOfEntry,
  onCreate,
  onDelete,
  onAssign,
  onClose,
}: FolderSheetProps) {
  const [name, setName] = useState("");
  const [budget, setBudget] = useState("");
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  useEffect(() => {
    if (state) {
      setName("");
      setBudget("");
      setConfirmDel(null);
    }
  }, [state]);

  useEffect(() => {
    if (!state) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [state, onClose]);

  if (!state) return null;

  const assigning = state.mode === "assign" ? folderIdOfEntry(state.entryId) : null;

  return (
    <div className="absolute inset-0 z-50" role="dialog" aria-modal="true">
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 w-full animate-fade bg-[rgba(0,0,0,0.7)]"
      />
      <div className="absolute inset-x-0 bottom-0 flex max-h-[80%] animate-rise flex-col rounded-t-[2rem] border-t border-x border-line bg-panel">
        <div className="mx-auto mt-3 h-1 w-10 shrink-0 rounded-full bg-zinc-700" />

        <div className="flex items-start justify-between px-5 pt-3 pb-3">
          <div>
            <h2 className="font-display text-xl font-bold tracking-tight">
              {state.mode === "assign" ? "Move to folder" : "Trip & expense folders"}
            </h2>
            <p className="mt-0.5 font-mono text-[9px] tracking-[0.3em] text-zinc-500">
              {state.mode === "assign"
                ? "GROUP THIS CONVERSION"
                : `BUDGETS IN ${defaultCurrency} · MONOCHROME BARS`}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close sheet"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
              <path d="m2 2 10 10M12 2 2 12" />
            </svg>
          </button>
        </div>

        <div className="no-scrollbar flex-1 overflow-y-auto px-4 pb-8">
          {state.mode === "assign" && (
            <button
              onClick={() => onAssign(null)}
              className={cn(
                "mb-1.5 flex w-full items-center justify-between rounded-2xl border px-4 py-3.5 font-mono text-[10px] font-bold tracking-[0.25em] transition-all active:scale-[0.98]",
                assigning === null
                  ? "border-white bg-white text-black"
                  : "border-dashed border-zinc-600 text-zinc-400"
              )}
            >
              NO FOLDER {assigning === null && <span>●</span>}
            </button>
          )}

          {folders.map((f) => {
            const spend = spendOf(f);
            const active = state.mode === "assign" && assigning === f.id;
            return (
              <div
                key={f.id}
                className={cn(
                  "mb-1.5 rounded-2xl border bg-black px-4 py-3 transition-colors",
                  active ? "border-white" : "border-line"
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  {state.mode === "assign" ? (
                    <button
                      onClick={() => onAssign(f.id)}
                      className="flex min-w-0 flex-1 items-center justify-between gap-2 text-left"
                    >
                      <span className="flex items-center gap-2 font-display text-[14px] font-semibold tracking-wide">
                        <span className="text-zinc-500">⌂</span> {f.name}
                      </span>
                      <span className="font-mono text-xs">{active ? "●" : "○"}</span>
                    </button>
                  ) : (
                    <>
                      <span className="flex min-w-0 items-center gap-2 font-display text-[14px] font-semibold tracking-wide">
                        <span className="text-zinc-500">⌂</span>
                        <span className="truncate">{f.name}</span>
                      </span>
                      <button
                        onClick={() => {
                          if (confirmDel === f.id) {
                            onDelete(f.id);
                            setConfirmDel(null);
                          } else {
                            setConfirmDel(f.id);
                            window.setTimeout(() => setConfirmDel(null), 2200);
                          }
                        }}
                        className={cn(
                          "shrink-0 rounded-full border px-2.5 py-1 font-mono text-[8px] font-bold tracking-widest transition-all active:scale-90",
                          confirmDel === f.id
                            ? "animate-blink border-white bg-white text-black"
                            : "border-line text-zinc-500 active:bg-white active:text-black"
                        )}
                      >
                        {confirmDel === f.id ? "SURE?" : "DELETE"}
                      </button>
                    </>
                  )}
                </div>
                <div className="mt-2">
                  <BudgetBar spend={spend} budget={f.budget} />
                  <p className="mt-1.5 flex justify-between font-mono text-[9px] tabular-nums text-zinc-500">
                    <span>
                      {formatValue(spend, f.currency)} {f.currency} · {f.entryIds.length}{" "}
                      {f.entryIds.length === 1 ? "ENTRY" : "ENTRIES"}
                    </span>
                    <span>
                      {f.budget > 0
                        ? spend > f.budget
                          ? `OVER BY ${formatValue(spend - f.budget, f.currency)}`
                          : `${Math.round((spend / f.budget) * 100)}% OF ${formatValue(f.budget, f.currency)}`
                        : "NO BUDGET SET"}
                    </span>
                  </p>
                </div>
              </div>
            );
          })}

          {folders.length === 0 && state.mode === "assign" && (
            <p className="py-4 text-center font-mono text-[9px] tracking-[0.2em] text-zinc-600">
              NO FOLDERS YET — CREATE ONE BELOW
            </p>
          )}

          {/* create form */}
          <div className="mt-2 rounded-2xl border border-dashed border-zinc-600 p-3.5">
            <p className="mb-2 font-mono text-[8px] tracking-[0.3em] text-zinc-500">NEW FOLDER</p>
            <input
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 24))}
              placeholder="NAME · E.G. TOKYO TRIP"
              className="w-full rounded-xl border border-line bg-black px-3 py-2.5 font-mono text-[11px] tracking-wider text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400"
            />
            <div className="mt-1.5 flex gap-1.5">
              <input
                value={budget}
                onChange={(e) => setBudget(e.target.value.replace(/[^\d.]/g, "").slice(0, 12))}
                placeholder={`BUDGET IN ${defaultCurrency} · OPTIONAL`}
                inputMode="decimal"
                className="min-w-0 flex-1 rounded-xl border border-line bg-black px-3 py-2.5 font-mono text-[11px] tabular-nums text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400"
              />
              <button
                onClick={() => {
                  if (!name.trim()) return;
                  onCreate(name.trim(), Number(budget) || 0);
                  setName("");
                  setBudget("");
                }}
                disabled={!name.trim()}
                className="shrink-0 rounded-xl bg-white px-4 font-mono text-[10px] font-bold tracking-widest text-black transition-all active:scale-90 disabled:opacity-30"
              >
                CREATE
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
