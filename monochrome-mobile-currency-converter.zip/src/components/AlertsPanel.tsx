import { useState } from "react";
import type { RateAlert } from "../hooks/useAlerts";
import { crossRate, formatRate } from "../lib/money";
import { cn } from "../utils/cn";

export interface AlertPrefs {
  inApp: boolean;
  push: boolean;
}

interface AlertsPanelProps {
  alerts: RateAlert[];
  from: string;
  to: string;
  rates: Record<string, number>;
  prefs: AlertPrefs;
  onPrefs: (p: AlertPrefs) => void;
  onAdd: (target: number, dir: "above" | "below") => string | null;
  onRemove: (id: string) => void;
}

/** Target-rate alerts with in-app / push delivery toggles. */
export default function AlertsPanel({ alerts, from, to, rates, prefs, onPrefs, onAdd, onRemove }: AlertsPanelProps) {
  const [target, setTarget] = useState("");
  const [dir, setDir] = useState<"above" | "below">("above");
  const [error, setError] = useState<string | null>(null);

  const current = crossRate(rates, from, to);

  const submit = () => {
    const err = onAdd(Number(target), dir);
    setError(err);
    if (!err) setTarget("");
  };

  const Toggle = ({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) => (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[8px] font-bold tracking-widest transition-all duration-200 active:scale-90",
        on ? "border-white bg-white text-black" : "border-zinc-600 text-zinc-500"
      )}
    >
      <span className={cn("h-1 w-1 rounded-full", on ? "bg-black" : "bg-zinc-600")} />
      {label}
    </button>
  );

  return (
    <div>
      {/* delivery toggles */}
      <div className="mb-2 flex items-center justify-between">
        <span className="font-mono text-[8px] tracking-[0.3em] text-zinc-600">NOTIFY VIA</span>
        <span className="flex gap-1.5">
          <Toggle on={prefs.inApp} label="IN-APP" onClick={() => onPrefs({ ...prefs, inApp: !prefs.inApp })} />
          <Toggle on={prefs.push} label="PUSH" onClick={() => onPrefs({ ...prefs, push: !prefs.push })} />
        </span>
      </div>

      {/* form */}
      <div className="rounded-2xl border border-line bg-black p-3">
        <p className="mb-2 font-mono text-[9px] tracking-[0.25em] text-zinc-500">
          ALERT ON {from}→{to}
          {current != null && <span className="text-zinc-400"> · NOW {formatRate(current)}</span>}
        </p>
        <div className="flex gap-1.5">
          <input
            value={target}
            onChange={(e) => setTarget(e.target.value.replace(/[^\d.]/g, ""))}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="TARGET RATE"
            inputMode="decimal"
            className="min-w-0 flex-1 rounded-xl border border-line bg-panel px-3 py-2.5 font-mono text-xs tabular-nums text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400"
          />
          <button
            onClick={submit}
            className="shrink-0 rounded-xl bg-white px-3.5 font-mono text-[10px] font-semibold tracking-widest text-black transition-transform duration-100 active:scale-90"
          >
            ADD
          </button>
        </div>
        <div className="mt-1.5 grid grid-cols-2 gap-1 rounded-xl border border-line p-1">
          {(
            [
              ["above", "▲ AT / ABOVE"],
              ["below", "▼ AT / BELOW"],
            ] as const
          ).map(([d, label]) => (
            <button
              key={d}
              onClick={() => setDir(d)}
              className={cn(
                "rounded-lg py-1.5 font-mono text-[9px] font-medium tracking-wider transition-all",
                dir === d ? "bg-white text-black" : "text-zinc-500"
              )}
            >
              {label}
            </button>
          ))}
        </div>
        {error && <p className="mt-2 font-mono text-[8px] tracking-[0.2em] text-zinc-400">⚠ {error}</p>}
      </div>

      {/* list */}
      {alerts.length === 0 ? (
        <p className="py-2 text-center font-mono text-[9px] tracking-[0.2em] text-zinc-600">NO ALERTS SET</p>
      ) : (
        <div className="mt-1.5">
          {alerts.map((a) => {
            const cur = crossRate(rates, a.from, a.to);
            return (
              <div key={a.id} className="mb-1 flex items-center gap-2 rounded-xl border border-line bg-black px-3 py-2">
                <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", a.done ? "bg-zinc-600" : "animate-pulse-dot bg-white")} />
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-[12px] font-semibold tracking-wide">
                    {a.from}→{a.to} {a.dir === "above" ? "≥" : "≤"} {formatRate(a.target)}
                  </span>
                  <span className="block font-mono text-[9px] tabular-nums text-zinc-500">
                    {a.done ? "TRIGGERED" : cur != null ? `NOW ${formatRate(cur)}` : "—"}
                  </span>
                </span>
                {a.done && (
                  <span className="shrink-0 rounded-full bg-white px-2 py-0.5 font-mono text-[8px] font-bold tracking-widest text-black">
                    HIT
                  </span>
                )}
                <button
                  onClick={() => onRemove(a.id)}
                  aria-label="Remove alert"
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-zinc-600 transition-all active:scale-75 active:bg-white active:text-black"
                >
                  <svg width="9" height="9" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden>
                    <path d="m1.5 1.5 7 7m0-7-7 7" />
                  </svg>
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
