import { cn } from "../utils/cn";
import VoiceButton from "./VoiceButton";

interface KeypadProps {
  /** "0"–"9", ".", "del", "AC", "%", "+", "−", "×", "÷", "=" */
  onPress: (key: string) => void;
  onClear: () => void;
  /** Pad key currently lit by a physical keyboard press. */
  litKey?: string | null;
  onVoiceResult: (transcript: string) => void;
  onVoiceUnsupported: () => void;
  /** Minimized state — only the grab-handle bar stays visible. */
  collapsed: boolean;
  onToggle: () => void;
}

/** iOS-style 4×5 pad: digits + inline expression operators + voice input. */
const KEYS = [
  "AC", "del", "%", "÷",
  "7", "8", "9", "×",
  "4", "5", "6", "−",
  "1", "2", "3", "+",
  "0", ".", "=",
];

export default function Keypad({
  onPress,
  onClear,
  litKey,
  onVoiceResult,
  onVoiceUnsupported,
  collapsed,
  onToggle,
}: KeypadProps) {
  return (
    <div
      className="safe-bottom absolute inset-x-0 bottom-0 z-30 border-t border-line bg-black transition-transform duration-300"
      style={{
        transform: collapsed ? "translateY(calc(100% - 2.25rem))" : "translateY(0)",
        transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)",
      }}
    >
      {/* grab handle — tap to collapse / expand the dock */}
      <button
        onClick={onToggle}
        aria-expanded={!collapsed}
        aria-label={collapsed ? "Show keypad" : "Hide keypad"}
        className="flex h-9 w-full items-center justify-center gap-2 border-b border-line font-mono text-[9px] font-semibold tracking-[0.3em] text-zinc-500 transition-colors active:bg-white active:text-black"
      >
        <svg
          className={cn("h-3 w-3 transition-transform duration-300", collapsed && "rotate-180")}
          viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden
        >
          <path d="m2.5 4.5 3.5 3.5 3.5-3.5" />
        </svg>
        {collapsed ? "KEYPAD · TAP TO OPEN" : "KEYPAD · TAP TO HIDE"}
      </button>

      <div className="flex items-center justify-between px-5 pt-2 pb-1.5">
        <button
          onClick={onClear}
          className="font-mono text-[10px] font-medium tracking-[0.25em] text-zinc-500 transition-colors active:text-white"
        >
          AC · CLEAR
        </button>
        <span className="hidden font-mono text-[9px] tracking-[0.2em] text-zinc-700 sm:block">
          KEYS · 0-9 · + − × ÷ · = · ⌫ · ESC · S⇅ · K
        </span>
        <VoiceButton onResult={onVoiceResult} onUnsupported={onVoiceUnsupported} />
      </div>

      <div className="grid grid-cols-4 gap-px border-t border-line bg-line">
        {KEYS.map((key) => {
          const lit = litKey === key;
          const isOp = key === "÷" || key === "×" || key === "−" || key === "+" || key === "=";
          return (
            <button
              key={key}
              aria-label={
                key === "del" ? "Backspace" : key === "AC" ? "All clear" :
                key === "%" ? "Percent" : key === "=" ? "Equals" :
                key === "." ? "Decimal point" : key
              }
              onClick={() => (key === "AC" ? onClear() : onPress(key))}
              className={cn(
                "flex h-12 items-center justify-center bg-black font-display text-[22px] font-medium text-white select-none",
                "transition-colors duration-100 active:bg-white active:text-black sm:h-14",
                isOp && "text-zinc-400",
                key === "0" && "col-span-2",
                lit && "bg-white text-black"
              )}
            >
              {key === "del" ? (
                <svg width="22" height="18" viewBox="0 0 26 22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M8.5 2.5h13A2.5 2.5 0 0 1 24 5v12a2.5 2.5 0 0 1-2.5 2.5h-13L2 11l6.5-8.5Z" />
                  <path d="m12.5 8 5 5m0-5-5 5" />
                </svg>
              ) : (
                key
              )}
            </button>
          );
        })}
      </div>

      {/* home indicator */}
      <div className="flex justify-center pt-2 pb-2.5">
        <div className="h-1 w-28 rounded-full bg-zinc-700" />
      </div>
    </div>
  );
}
