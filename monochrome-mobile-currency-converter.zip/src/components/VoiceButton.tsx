import { useEffect, useRef, useState } from "react";
import { cn } from "../utils/cn";

interface VoiceButtonProps {
  onResult: (transcript: string) => void;
  onUnsupported: () => void;
}

type Recognizer = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
};

/**
 * Web Speech API microphone — say "250 usd to eur" or just a number.
 * Pulses with an expanding mono ring while listening.
 */
export default function VoiceButton({ onResult, onUnsupported }: VoiceButtonProps) {
  const [listening, setListening] = useState(false);
  const recRef = useRef<Recognizer | null>(null);

  // Clean up on unmount.
  useEffect(() => {
    return () => {
      try {
        recRef.current?.stop();
      } catch { /* already stopped */ }
    };
  }, []);

  const toggle = () => {
    if (listening) {
      try {
        recRef.current?.stop();
      } catch { /* non-fatal */ }
      setListening(false);
      return;
    }

    const w = window as unknown as {
      SpeechRecognition?: new () => Recognizer;
      webkitSpeechRecognition?: new () => Recognizer;
    };
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!Ctor) {
      onUnsupported();
      return;
    }

    const rec = new Ctor();
    rec.lang = "en-US";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (e) => {
      const t = e.results[0]?.[0]?.transcript?.trim();
      if (t) onResult(t);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recRef.current = rec;
    setListening(true);
    try {
      rec.start();
    } catch {
      setListening(false);
    }
  };

  return (
    <button
      onClick={toggle}
      aria-label={listening ? "Stop listening" : "Voice input"}
      className={cn(
        "relative flex h-8 w-8 items-center justify-center rounded-full border transition-all duration-200 active:scale-90",
        listening
          ? "border-white bg-white text-black"
          : "border-line text-zinc-400 active:bg-white active:text-black"
      )}
    >
      {/* expanding mono pulse while listening */}
      {listening && (
        <>
          <span className="absolute inset-0 animate-ping rounded-full border border-white opacity-60" />
          <span className="absolute -inset-1.5 animate-pulse rounded-full border border-zinc-600" />
        </>
      )}
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <rect x="9" y="2.5" width="6" height="11" rx="3" />
        <path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7" />
      </svg>
    </button>
  );
}
