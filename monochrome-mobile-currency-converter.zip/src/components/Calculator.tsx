import { useState } from "react";
import { formatValue } from "../lib/money";
import { cn } from "../utils/cn";

interface CalculatorProps {
  /** Pushes the computed value onto the converter pad. */
  onSend: (value: string) => void;
  /** Live converted total from the main converter (for the tip splitter). */
  converted: number | null;
  /** Target currency code of the live converted total. */
  currency: string;
}

/* ------------------------------ math engine ------------------------------ */

function compute(a: number, b: number, op: string): number {
  switch (op) {
    case "+": return a + b;
    case "−": return a - b;
    case "×": return a * b;
    case "÷": return b === 0 ? NaN : a / b;
    default: return b;
  }
}

function fmt(n: number): string {
  if (!Number.isFinite(n)) return "UNDEFINED";
  const a = Math.abs(n);
  if (a !== 0 && (a >= 1e12 || a < 1e-6)) return n.toExponential(4);
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: a < 1 ? 8 : a < 1000 ? 4 : 2,
  }).format(n);
}

/* ------------------------------ classic pad ------------------------------ */

function MathPad({ onSend }: { onSend: (v: string) => void }) {
  const [disp, setDisp] = useState("0");
  const [acc, setAcc] = useState<number | null>(null);
  const [op, setOp] = useState<string | null>(null);
  const [fresh, setFresh] = useState(true);

  const current = () => Number(disp.replace(/,/g, "")) || 0;

  const digit = (d: string) => {
    setDisp((r) => {
      if (fresh) return d;
      const plain = r.replace(/,/g, "");
      if (plain.replace(/[.-]/g, "").length >= 12) return r;
      if (plain === "0") return d;
      return plain + d;
    });
    setFresh(false);
  };

  const press = (k: string) => {
    if (/^[0-9]$/.test(k)) return digit(k);
    if (k === ".") {
      if (fresh) {
        setDisp("0.");
        setFresh(false);
      } else setDisp((r) => (r.includes(".") ? r : `${r}.`));
      return;
    }
    if (k === "del") {
      if (!fresh)
        setDisp((r) => {
          const plain = r.replace(/,/g, "");
          const next = plain.slice(0, -1);
          return next === "" || next === "-" ? "0" : next;
        });
      return;
    }
    if (k === "C") {
      setDisp("0"); setAcc(null); setOp(null); setFresh(true);
      return;
    }
    if (k === "%") {
      setDisp(fmt(current() / 100));
      setFresh(true);
      return;
    }
    if (k === "=") {
      if (acc == null || op == null) return;
      setDisp(fmt(compute(acc, current(), op)));
      setAcc(null); setOp(null); setFresh(true);
      return;
    }
    // operator
    const cur = current();
    if (acc == null || op == null) setAcc(cur);
    else if (!fresh) {
      const v = compute(acc, cur, op);
      setAcc(v);
      setDisp(fmt(v));
    }
    setOp(k);
    setFresh(true);
  };

  const KEYS = ["C", "del", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "="];

  return (
    <div>
      <div className="rounded-2xl border border-line bg-black px-4 py-3">
        <p className="h-4 text-right font-mono text-[10px] tabular-nums text-zinc-600">
          {acc != null && op ? `${fmt(acc)} ${op}` : "\u00A0"}
        </p>
        <p className={cn("truncate text-right font-display font-semibold tabular-nums", disp.length > 12 ? "text-lg" : "text-2xl")}>
          {disp}
        </p>
      </div>
      <div className="mt-2 grid grid-cols-4 gap-1">
        {KEYS.map((k) => (
          <button
            key={k}
            onClick={() => press(k)}
            className={cn(
              "flex h-11 items-center justify-center rounded-xl border border-line font-display text-lg font-medium transition-all duration-100 active:scale-90 active:bg-white active:text-black",
              k === "0" && "col-span-2",
              ["÷", "×", "−", "+", "="].includes(k) ? "bg-panel text-white" : "bg-black text-white",
              k === "C" && "text-zinc-400"
            )}
          >
            {k === "del" ? (
              <svg width="18" height="15" viewBox="0 0 26 22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M8.5 2.5h13A2.5 2.5 0 0 1 24 5v12a2.5 2.5 0 0 1-2.5 2.5h-13L2 11l6.5-8.5Z" />
                <path d="m12.5 8 5 5m0-5-5 5" />
              </svg>
            ) : (
              k
            )}
          </button>
        ))}
      </div>
      <button
        onClick={() => {
          const v = current();
          if (Number.isFinite(v) && Math.abs(v) > 0) onSend(String(Math.abs(v)));
        }}
        className="mt-2 w-full rounded-xl bg-white py-3 font-mono text-[10px] font-semibold tracking-[0.25em] text-black transition-all duration-150 active:scale-[0.97]"
      >
        SEND RESULT TO CONVERTER →
      </button>
    </div>
  );
}

/* --------------------------- travel tip splitter -------------------------- */

const TIP_PRESETS = [0, 5, 10, 15, 20];

function TravelSplit({ converted, currency }: { converted: number | null; currency: string }) {
  const [amount, setAmount] = useState("");
  const [tipPct, setTipPct] = useState(10);
  const [people, setPeople] = useState(2);

  const base = Number(amount) || 0;
  const tip = (base * tipPct) / 100;
  const total = base + tip;
  const per = total / Math.max(1, people);

  return (
    <div className="space-y-2.5">
      <button
        onClick={() => converted != null && setAmount(String(Number(converted.toFixed(8))))}
        disabled={converted == null || converted <= 0}
        className="w-full rounded-xl border border-dashed border-zinc-600 py-2.5 font-mono text-[9px] font-medium tracking-[0.22em] text-zinc-400 transition-all active:scale-[0.97] active:border-zinc-400 active:text-white disabled:opacity-40"
      >
        ⤓ LOAD CONVERTED TOTAL {converted != null && converted > 0 ? `· ${formatValue(converted, currency)} ${currency}` : ""}
      </button>

      <input
        value={amount}
        onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))}
        placeholder={`BILL AMOUNT IN ${currency}`}
        inputMode="decimal"
        className="w-full rounded-2xl border border-line bg-black px-4 py-3 font-mono text-sm tabular-nums text-white placeholder-zinc-600 outline-none transition-colors focus:border-zinc-400"
      />

      {/* tip presets + custom stepper */}
      <div className="grid grid-cols-5 gap-1">
        {TIP_PRESETS.map((p) => (
          <button
            key={p}
            onClick={() => setTipPct(p)}
            className={cn(
              "rounded-xl border py-2.5 font-mono text-[10px] font-semibold tabular-nums transition-all active:scale-90",
              tipPct === p ? "border-white bg-white text-black" : "border-line text-zinc-400"
            )}
          >
            {p}%
          </button>
        ))}
      </div>
      <div className="flex items-center justify-between rounded-xl border border-line bg-black px-3 py-2">
        <span className="font-mono text-[9px] tracking-[0.25em] text-zinc-500">CUSTOM TIP</span>
        <span className="flex items-center gap-3">
          <button onClick={() => setTipPct((p) => Math.max(0, p - 1))} className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-lg transition-all active:scale-90 active:bg-white active:text-black">−</button>
          <span className="w-12 text-center font-display text-lg font-bold tabular-nums">{tipPct}%</span>
          <button onClick={() => setTipPct((p) => Math.min(100, p + 1))} className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-lg transition-all active:scale-90 active:bg-white active:text-black">+</button>
        </span>
      </div>

      {/* people stepper */}
      <div className="flex items-center justify-between rounded-xl border border-line bg-black px-3 py-2">
        <span className="font-mono text-[9px] tracking-[0.25em] text-zinc-500">SPLIT BETWEEN</span>
        <span className="flex items-center gap-3">
          <button onClick={() => setPeople((p) => Math.max(1, p - 1))} className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-lg transition-all active:scale-90 active:bg-white active:text-black">−</button>
          <span className="w-12 text-center font-display text-lg font-bold tabular-nums">
            {people} <span className="text-[10px] font-medium text-zinc-500">{people === 1 ? "PERSON" : "PEOPLE"}</span>
          </span>
          <button onClick={() => setPeople((p) => Math.min(30, p + 1))} className="flex h-8 w-8 items-center justify-center rounded-full border border-line text-lg transition-all active:scale-90 active:bg-white active:text-black">+</button>
        </span>
      </div>

      {/* results */}
      <div className="space-y-1.5 rounded-2xl border border-line bg-black p-3.5">
        <p className="flex justify-between font-mono text-[10px] tabular-nums text-zinc-400">
          <span className="tracking-[0.2em]">TIP · {tipPct}%</span>
          <span>{fmt(tip)} {currency}</span>
        </p>
        <p className="flex justify-between font-mono text-[10px] tabular-nums text-zinc-400">
          <span className="tracking-[0.2em]">GRAND TOTAL</span>
          <span>{fmt(total)} {currency}</span>
        </p>
        <div className="mt-1.5 flex items-center justify-between rounded-xl bg-white px-3.5 py-3 text-black">
          <span className="font-mono text-[9px] font-bold tracking-[0.2em]">PER PERSON</span>
          <span className="font-display text-xl font-bold tabular-nums">
            {fmt(per)} <span className="text-xs">{currency}</span>
          </span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ tabbed shell ----------------------------- */

/** Sidebar calculator: classic pad + travel tip splitter, tabbed. */
export default function Calculator({ onSend, converted, currency }: CalculatorProps) {
  const [tab, setTab] = useState<"pad" | "travel">("pad");
  return (
    <div>
      <div className="mb-2 grid grid-cols-2 gap-1 rounded-full border border-line bg-black p-1">
        {(
          [
            ["pad", "⌨ PAD"],
            ["travel", "✈ TRAVEL SPLIT"],
          ] as const
        ).map(([t, label]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "rounded-full py-2 font-mono text-[9px] font-bold tracking-[0.18em] transition-all duration-200",
              tab === t ? "bg-white text-black" : "text-zinc-500"
            )}
          >
            {label}
          </button>
        ))}
      </div>
      {tab === "pad" ? (
        <MathPad onSend={onSend} />
      ) : (
        <TravelSplit converted={converted} currency={currency} />
      )}
    </div>
  );
}
