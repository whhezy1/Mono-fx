import { useState } from "react";
import { initialsOf, type AuthUser } from "../lib/auth";
import { BUILD } from "../lib/version";
import type { Theme } from "../hooks/useTheme";
import type { RateAlert } from "../hooks/useAlerts";
import { cn } from "../utils/cn";
import AlertsPanel, { type AlertPrefs } from "./AlertsPanel";
import Calculator from "./Calculator";
import { BudgetBar } from "./FolderSheet";
import InstallCard from "./InstallCard";
import type { ExpenseFolder } from "../lib/folders";
import { formatValue } from "../lib/money";
import WatchlistPanel, { type WatchPair } from "./WatchlistPanel";

export type View = "home" | "basket" | "history" | "profile" | "settings";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  user: AuthUser;
  view: View;
  onNav: (v: View) => void;
  theme: Theme;
  onToggleTheme: () => void;
  pairs: WatchPair[];
  rates: Record<string, number>;
  onPinCurrent: () => void;
  onLoadPair: (from: string, to: string) => void;
  onRemovePair: (id: string) => void;
  folders: ExpenseFolder[];
  spendOf: (f: ExpenseFolder) => number;
  onManageFolders: () => void;
  alerts: RateAlert[];
  from: string;
  to: string;
  alertPrefs: AlertPrefs;
  onAlertPrefs: (p: AlertPrefs) => void;
  onAddAlert: (target: number, dir: "above" | "below") => string | null;
  onRemoveAlert: (id: string) => void;
  onSendCalc: (value: string) => void;
  converted: number | null;
  currency: string;
  onExportCsv: () => void;
  historyCount: number;
  onSignOut: () => void;
  /** Install-to-home-screen (auto-hidden in standalone/Capacitor). */
  canInstall: boolean;
  onInstall: () => void;
}

const NAV: Array<{ view: View; label: string; icon: React.ReactNode }> = [
  {
    view: "home",
    label: "CONVERTER",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
        <path d="M4 7h13m0 0-3-3m3 3-3 3M20 17H7m0 0 3-3m-3 3 3 3" />
      </svg>
    ),
  },
  {
    view: "basket",
    label: "BASKET · MULTI",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
        <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
        <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
      </svg>
    ),
  },
  {
    view: "history",
    label: "HISTORY",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5M12 7v5l3 2" />
      </svg>
    ),
  },
  {
    view: "profile",
    label: "PROFILE",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21c1.5-3.5 4.5-5 8-5s6.5 1.5 8 5" />
      </svg>
    ),
  },
  {
    view: "settings",
    label: "SETTINGS",
    icon: (
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
        <circle cx="12" cy="12" r="3.2" />
        <path d="M12 2.8v2.6M12 18.6v2.6M2.8 12h2.6M18.6 12h2.6M5.5 5.5l1.8 1.8M16.7 16.7l1.8 1.8M18.5 5.5l-1.8 1.8M7.3 16.7l-1.8 1.8" />
      </svg>
    ),
  },
];

function Section({
  title,
  badge,
  defaultOpen,
  children,
}: {
  title: string;
  badge?: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <div className="border-b border-line">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center justify-between px-2 py-3">
        <span className="flex items-center gap-2 font-mono text-[9px] font-semibold tracking-[0.3em] text-zinc-400">
          {title}
          {badge && (
            <span className="rounded-full bg-white px-1.5 py-px text-[8px] font-bold text-black">{badge}</span>
          )}
        </span>
        <svg
          className={cn("h-3 w-3 text-zinc-500 transition-transform duration-300", open && "rotate-180")}
          viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden
        >
          <path d="m2.5 4.5 3.5 3.5 3.5-3.5" />
        </svg>
      </button>
      <div className={cn("grid transition-all duration-300", open ? "grid-rows-[1fr] pb-3 opacity-100" : "grid-rows-[0fr] opacity-0")}>
        <div className="overflow-hidden px-1">{children}</div>
      </div>
    </div>
  );
}

/** Slide-out drawer: navigation + watchlist, alerts, calculator, export, theme. */
export default function Sidebar(props: SidebarProps) {
  if (!props.open) return null;
  const { user } = props;

  return (
    <div className="absolute inset-0 z-50">
      <button
        aria-label="Close menu"
        onClick={props.onClose}
        className="absolute inset-0 w-full animate-fade bg-[rgba(0,0,0,0.65)]"
      />
      <aside className="absolute inset-y-0 left-0 flex w-[85%] max-w-[320px] animate-drawer flex-col border-r border-line bg-panel">
        {/* user card */}
        <div className="flex items-center gap-3 border-b border-line px-4 pt-5 pb-4">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white font-display text-sm font-bold text-black">
            {initialsOf(user.name)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-[15px] font-bold tracking-tight">{user.name}</p>
            <p className="truncate font-mono text-[9px] tracking-wider text-zinc-500">{user.email}</p>
          </div>
          <button
            onClick={props.onClose}
            aria-label="Close"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line text-zinc-400 transition-all active:scale-90 active:bg-white active:text-black"
          >
            <svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
              <path d="m2 2 10 10M12 2 2 12" />
            </svg>
          </button>
        </div>

        {/* body */}
        <div className="no-scrollbar flex-1 overflow-y-auto px-3">
          {props.canInstall && (
            <div className="pt-3">
              <InstallCard onInstall={props.onInstall} compact />
            </div>
          )}

          {/* nav */}
          <div className="space-y-1 border-b border-line py-3">
            {NAV.map((n) => (
              <button
                key={n.view}
                onClick={() => props.onNav(n.view)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 font-mono text-[10px] font-semibold tracking-[0.25em] transition-all duration-150",
                  props.view === n.view ? "bg-white text-black" : "text-zinc-400 active:bg-white/[0.06]"
                )}
              >
                {n.icon}
                {n.label}
                {n.view === "history" && props.historyCount > 0 && (
                  <span
                    className={cn(
                      "ml-auto rounded-full px-2 py-px text-[9px] font-bold tabular-nums",
                      props.view === n.view ? "bg-black text-white" : "bg-white text-black"
                    )}
                  >
                    {props.historyCount}
                  </span>
                )}
                {n.view === props.view && props.view !== "history" && <span className="ml-auto text-[10px]">●</span>}
              </button>
            ))}
          </div>

          <Section title="WATCHLIST" badge={String(props.pairs.length)} defaultOpen>
            <WatchlistPanel
              pairs={props.pairs}
              rates={props.rates}
              onPinCurrent={props.onPinCurrent}
              onLoad={props.onLoadPair}
              onRemove={props.onRemovePair}
            />
          </Section>

          <Section title="EXPENSE FOLDERS" badge={String(props.folders.length)}>
            {props.folders.length === 0 ? (
              <p className="py-1 text-center font-mono text-[9px] tracking-[0.2em] text-zinc-600">
                NO FOLDERS YET
              </p>
            ) : (
              props.folders.slice(0, 4).map((f) => {
                const spend = props.spendOf(f);
                return (
                  <div key={f.id} className="mb-1.5 rounded-xl border border-line bg-black px-3 py-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate font-display text-[11px] font-semibold tracking-wide">
                        ⌂ {f.name}
                      </span>
                      <span className="shrink-0 font-mono text-[9px] tabular-nums text-zinc-500">
                        {formatValue(spend, f.currency)}
                        {f.budget > 0 && ` / ${formatValue(f.budget, f.currency)}`}
                      </span>
                    </div>
                    <div className="mt-1.5">
                      <BudgetBar spend={spend} budget={f.budget} />
                    </div>
                  </div>
                );
              })
            )}
            <button
              onClick={props.onManageFolders}
              className="mt-0.5 w-full rounded-xl border border-dashed border-zinc-600 py-2 font-mono text-[9px] font-medium tracking-[0.25em] text-zinc-400 transition-all active:scale-[0.97] active:border-zinc-400 active:text-white"
            >
              + MANAGE FOLDERS
            </button>
          </Section>

          <Section title="RATE ALERTS" badge={String(props.alerts.filter((a) => !a.done).length)}>
            <AlertsPanel
              alerts={props.alerts}
              from={props.from}
              to={props.to}
              rates={props.rates}
              prefs={props.alertPrefs}
              onPrefs={props.onAlertPrefs}
              onAdd={props.onAddAlert}
              onRemove={props.onRemoveAlert}
            />
          </Section>

          <Section title="CALCULATOR · TRAVEL TOOLS">
            <Calculator onSend={props.onSendCalc} converted={props.converted} currency={props.currency} />
          </Section>

          {/* export + theme */}
          <div className="space-y-2 py-3">
            <button
              onClick={props.onExportCsv}
              className="flex w-full items-center gap-3 rounded-xl border border-line bg-black px-3 py-3 font-mono text-[10px] font-medium tracking-[0.25em] text-zinc-300 transition-all duration-150 active:scale-[0.98] active:bg-white active:text-black"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 3v12m0 0 4-4m-4 4-4-4" />
                <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
              </svg>
              EXPORT HISTORY · CSV
              <span className="ml-auto tabular-nums text-zinc-600">{props.historyCount}</span>
            </button>

            <div className="flex items-center justify-between rounded-xl border border-line bg-black px-3 py-2.5">
              <span className="font-mono text-[10px] font-medium tracking-[0.25em] text-zinc-300">APPEARANCE</span>
              <div className="grid grid-cols-2 gap-1 rounded-full border border-line p-0.5">
                {(
                  [
                    ["dark", "◐ DARK"],
                    ["light", "◑ LIGHT"],
                  ] as const
                ).map(([t, label]) => (
                  <button
                    key={t}
                    onClick={() => props.theme !== t && props.onToggleTheme()}
                    className={cn(
                      "rounded-full px-2.5 py-1 font-mono text-[8px] font-bold tracking-widest transition-all duration-200",
                      props.theme === t ? "bg-white text-black" : "text-zinc-500"
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* footer */}
        <div className="border-t border-line px-3 py-3">
          <button
            onClick={props.onSignOut}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-line py-3 font-mono text-[10px] font-semibold tracking-[0.3em] text-zinc-300 transition-all duration-150 active:scale-[0.98] active:bg-white active:text-black"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
              <path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3M15 8l4 4-4 4m4-4H9" />
            </svg>
            SIGN OUT
          </button>
          <p className="mt-2.5 text-center font-mono text-[8px] leading-relaxed tracking-[0.3em] text-zinc-600">
            © 2026 MONO FX · LOCAL-FIRST
            <br />
            BUILD {BUILD}
          </p>
        </div>
      </aside>
    </div>
  );
}
