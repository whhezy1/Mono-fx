import { Capacitor } from "@capacitor/core";
import { Haptics, ImpactStyle } from "@capacitor/haptics";
import { Share } from "@capacitor/share";
import { StatusBar, Style } from "@capacitor/status-bar";

/**
 * Native bridge layer.
 * Inside the Capacitor shell these call the real device APIs; on the web
 * every helper is a silent no-op (returning false) so callers can fall back
 * to navigator.vibrate / navigator.share.
 */

export function isNativePlatform(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** Light impact haptic. Returns true when a native haptic was fired. */
export function nativeImpact(): boolean {
  if (!isNativePlatform()) return false;
  Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
  return true;
}

/** Native share sheet with the receipt text. */
export async function nativeShareText(text: string, title = "MONO FX Receipt"): Promise<boolean> {
  if (!isNativePlatform()) return false;
  try {
    await Share.share({ text, title, dialogTitle: "Share receipt" });
    return true;
  } catch {
    return false;
  }
}

/** Match the device status bar to the active monochrome theme. */
export async function styleNativeStatusBar(dark: boolean): Promise<void> {
  if (!isNativePlatform()) return;
  try {
    await StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light });
    await StatusBar.setBackgroundColor({ color: dark ? "#000000" : "#ffffff" });
    await StatusBar.setOverlaysWebView({ overlay: true });
  } catch { /* plugin unavailable */ }
}
