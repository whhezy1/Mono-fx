/** Build marker — surfaced in the console and on the auth screen so it's
 * always obvious which bundle is actually running (stale-cache debugging). */
export const BUILD = "2.2.0-pwa";
