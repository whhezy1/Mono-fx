import type { AuthUser } from "./auth";
import { meta } from "./currencies";
import { flagOf } from "./flags";
import { amountOf, formatRate, formatValue, isValidRaw } from "./money";
import { isNativePlatform, nativeShareText } from "./native";

/** One completed conversion, frozen at the moment it was made. */
export interface ConversionEntry {
  id: string;
  ts: number;
  raw: string; // amount as typed (may be a keypad expression)
  from: string;
  to: string;
  rate: number; // 1 from = rate to (at conversion time)
  result: number;
  feePct?: number; // simulated bank/card markup, when > 0
}

/** Typed source amount of an entry. */
export const entryAmount = (e: ConversionEntry): number => amountOf(e.raw);

export function loadEntries(key: string): ConversionEntry[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (e): e is ConversionEntry =>
        !!e &&
        typeof e === "object" &&
        typeof e.id === "string" &&
        typeof e.ts === "number" &&
        isValidRaw(e.raw) &&
        typeof e.from === "string" &&
        typeof e.to === "string" &&
        Number.isFinite(e.rate) &&
        Number.isFinite(e.result) &&
        (e.feePct === undefined || Number.isFinite(e.feePct))
    );
  } catch {
    return [];
  }
}

export function saveEntries(key: string, entries: ConversionEntry[]) {
  try {
    localStorage.setItem(key, JSON.stringify(entries));
  } catch { /* non-fatal */ }
}

/* -------------------------------- receipt -------------------------------- */

export function entryRef(e: ConversionEntry): string {
  return `MF-${Number.parseInt(e.id, 36).toString(36).toUpperCase().padStart(6, "X").slice(-6)}`;
}

function stamp(ts: number): string {
  const d = new Date(ts);
  return `${d.toISOString().slice(0, 10)} ${d.toLocaleTimeString("en-GB", { hour12: false })}`;
}

/** Plain-text receipt — for clipboard, WhatsApp, Telegram and .txt download. */
export function receiptText(e: ConversionEntry, user: AuthUser | null): string {
  const fm = meta(e.from);
  const tm = meta(e.to);
  const line = "─".repeat(34);
  return [
    "◐ MONO FX — CONVERSION RECEIPT",
    line,
    `REF       ${entryRef(e)}`,
    `DATE      ${stamp(e.ts)} UTC`,
    user ? `ACCOUNT   ${user.name} <${user.email}>` : "ACCOUNT   GUEST",
    line,
    `SEND      ${flagOf(e.from)} ${e.from} · ${fm.country}`,
    `          ${formatValue(entryAmount(e), e.from)} ${e.from}`,
    `RATE      1 ${e.from} = ${formatRate(e.rate)} ${e.to}`,
    ...(e.feePct && e.feePct > 0
      ? [
          `FEE       ${e.feePct}% SIMULATED MARKUP`,
          `          −${formatValue(e.result * (e.feePct / 100), e.to)} ${e.to}`,
          `NET GET   ${formatValue(e.result * (1 - e.feePct / 100), e.to)} ${e.to}`,
        ]
      : []),
    `RECEIVE   ${flagOf(e.to)} ${e.to} · ${tm.country}`,
    `          ${formatValue(e.result, e.to)} ${e.to}`,
    line,
    "RATES BY OPEN-ER-API · INDICATIVE ONLY",
    "MONOFX — STRICTLY BLACK & WHITE",
  ].join("\n");
}

/* --------------------------------- export -------------------------------- */

export function buildCsv(entries: ConversionEntry[]): string {
  const head = "timestamp_iso,ref,from,to,amount,rate,result,fee_pct";
  const rows = entries.map((e) =>
    [
      new Date(e.ts).toISOString(),
      entryRef(e),
      e.from,
      e.to,
      entryAmount(e),
      e.rate,
      Number(e.result.toFixed(8)),
      e.feePct ?? 0,
    ].join(",")
  );
  return [head, ...rows].join("\n");
}

export function downloadText(filename: string, text: string, mime = "text/plain") {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* -------------------------------- sharing -------------------------------- */

const APP_URL = "https://monofx.app";

export function whatsappUrl(text: string): string {
  return `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
}

export function telegramUrl(text: string): string {
  return `https://t.me/share/url?url=${encodeURIComponent(APP_URL)}&text=${encodeURIComponent(text)}`;
}

/** X (Twitter) compose intent. */
export function xUrl(text: string): string {
  return `https://x.com/intent/post?text=${encodeURIComponent(text)}`;
}

/** Facebook sharer — `quote` carries the receipt text. */
export function facebookUrl(text: string): string {
  return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(APP_URL)}&quote=${encodeURIComponent(text)}`;
}

/** Reddit submit — first receipt line becomes the post title. */
export function redditUrl(text: string): string {
  const title = text.split("\n")[0].slice(0, 120);
  return `https://www.reddit.com/submit?url=${encodeURIComponent(APP_URL)}&title=${encodeURIComponent(title)}`;
}

/** Pre-filled email draft. */
export function emailUrl(e: ConversionEntry, text: string): string {
  return `mailto:?subject=${encodeURIComponent(`MONO FX Receipt ${entryRef(e)}`)}&body=${encodeURIComponent(text)}`;
}

/** Native messaging app with the receipt pre-filled. */
export function smsUrl(text: string): string {
  return `sms:?body=${encodeURIComponent(text)}`;
}

/**
 * Copy-then-open flow for platforms without a share-link API
 * (Snapchat, Instagram, LinkedIn): the receipt goes to the clipboard,
 * then the app opens so the user can paste. Returns clipboard success.
 */
export async function copyAndOpen(text: string, url: string): Promise<boolean> {
  let copied = false;
  try {
    await navigator.clipboard.writeText(text);
    copied = true;
  } catch { /* open the app anyway */ }
  window.open(url, "_blank", "noopener,noreferrer");
  return copied;
}

/** Fallback homes for the copy-and-open destinations. */
export const PASTE_APP_URLS = {
  linkedin: "https://www.linkedin.com/feed/",
  snapchat: "https://www.snapchat.com/",
  instagram: "https://www.instagram.com/",
} as const;

export function canNativeShare(): boolean {
  return (
    isNativePlatform() ||
    (typeof navigator !== "undefined" && typeof navigator.share === "function")
  );
}

/** Native sheet inside Capacitor first, Web Share API on the web. */
export async function nativeShare(text: string): Promise<boolean> {
  try {
    if (await nativeShareText(text)) return true;
    if (typeof navigator.share === "function") {
      await navigator.share({ title: "MONO FX Receipt", text });
      return true;
    }
  } catch { /* dismissed */ }
  return false;
}
