/**
 * Per-user settings: privacy, passcode lock, accessibility, regional
 * formatting, manual rate overrides and data saver. Persisted to
 * localStorage under the owning account's key.
 */

export type FontScale = "normal" | "large" | "xl";
export type NumberFormatStyle = "comma" | "dot"; // 1,250.50 ↔ 1.250,50
export type PrecisionPref = "auto" | 2 | 4 | 6;

export interface UserSettings {
  /* privacy & security */
  hideAmounts: boolean;
  passcodeOn: boolean;
  passcodeHash: string | null; // SHA-256 of the 4-digit PIN
  /* accessibility */
  fontScale: FontScale;
  speakResults: boolean;
  reduceMotion: boolean;
  feedback: boolean; // keypad haptic + click
  /* regional & precision */
  numberFormat: NumberFormatStyle;
  precision: PrecisionPref;
  /* rates & data */
  manualRate: boolean;
  manualRates: Record<string, string>; // pair "FROM/TO" → custom rate
  dataSaver: boolean;
}

export const DEFAULT_SETTINGS: UserSettings = {
  hideAmounts: false,
  passcodeOn: false,
  passcodeHash: null,
  fontScale: "normal",
  speakResults: false,
  reduceMotion: false,
  feedback: true,
  numberFormat: "comma",
  precision: "auto",
  manualRate: false,
  manualRates: {},
  dataSaver: false,
};

/** Font scale → CSS zoom multiplier applied to the device shell. */
export const FONT_ZOOM: Record<FontScale, number> = {
  normal: 1,
  large: 1.15,
  xl: 1.3,
};

const bool = (v: unknown, d: boolean): boolean => (typeof v === "boolean" ? v : d);

export function loadSettings(key: string): UserSettings {
  try {
    const p = JSON.parse(localStorage.getItem(key) ?? "");
    if (!p || typeof p !== "object") return { ...DEFAULT_SETTINGS };
    const precision: PrecisionPref =
      p.precision === 2 || p.precision === 4 || p.precision === 6 ? p.precision : "auto";
    return {
      hideAmounts: bool(p.hideAmounts, false),
      passcodeOn: bool(p.passcodeOn, false),
      passcodeHash: typeof p.passcodeHash === "string" ? p.passcodeHash : null,
      fontScale:
        p.fontScale === "large" || p.fontScale === "xl" ? p.fontScale : "normal",
      speakResults: bool(p.speakResults, false),
      reduceMotion: bool(p.reduceMotion, false),
      feedback: bool(p.feedback, true),
      numberFormat: p.numberFormat === "dot" ? "dot" : "comma",
      precision,
      manualRate: bool(p.manualRate, false),
      manualRates:
        p.manualRates && typeof p.manualRates === "object" && !Array.isArray(p.manualRates)
          ? p.manualRates
          : {},
      dataSaver: bool(p.dataSaver, false),
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(key: string, s: UserSettings) {
  try {
    localStorage.setItem(key, JSON.stringify(s));
  } catch { /* non-fatal */ }
}
