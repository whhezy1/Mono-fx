/**
 * Trip & expense folders — group saved conversions, track a monochrome
 * budget bar per folder. Stored per-user; all math happens in the App where
 * live rates are available.
 */

export interface ExpenseFolder {
  id: string;
  name: string;
  currency: string; // budget & spend are expressed in this currency
  budget: number; // 0 = no budget set
  entryIds: string[];
  createdAt: number;
}

export function loadFolders(key: string): ExpenseFolder[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (f): f is ExpenseFolder =>
        !!f &&
        typeof f === "object" &&
        typeof f.id === "string" &&
        typeof f.name === "string" &&
        typeof f.currency === "string" &&
        Number.isFinite(f.budget) &&
        Array.isArray(f.entryIds)
    );
  } catch {
    return [];
  }
}

export function saveFolders(key: string, folders: ExpenseFolder[]) {
  try {
    localStorage.setItem(key, JSON.stringify(folders));
  } catch { /* non-fatal */ }
}
