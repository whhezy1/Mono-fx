import { HIGH_DECIMAL, ZERO_DECIMAL } from "./currencies";

/* ------------------------- global format preferences ----------------------- */

export type PrecisionPref = "auto" | 2 | 4 | 6;

interface FormatConfig {
  locale: string; // "en-US" → 1,250.50 · "de-DE" → 1.250,50
  precision: PrecisionPref;
}

let FORMAT: FormatConfig = { locale: "en-US", precision: "auto" };

/**
 * Applied from the user's Regional settings. Every formatter in this module
 * (and therefore every screen, receipt and basket) reads it live.
 * CSV export deliberately bypasses this — machine-readable output stays
 * dot-decimal regardless of display locale.
 */
export function configureFormatting(cfg: Partial<FormatConfig>) {
  FORMAT = { ...FORMAT, ...cfg };
}

export const formatConfig = (): FormatConfig => FORMAT;

/* ---------------------------------- rates --------------------------------- */

/** Cross rate via the USD base. Returns null when data is missing/invalid. */
export function crossRate(
  rates: Record<string, number> | null,
  from: string,
  to: string
): number | null {
  if (!rates) return null;
  const f = rates[from];
  const t = rates[to];
  if (!f || !t || !isFinite(f) || !isFinite(t)) return null;
  // Round to 10 decimals to keep float noise (0.30000000004…) out of the UI.
  return Number((t / f).toFixed(10));
}

/* ------------------------------- formatting ------------------------------- */

/**
 * 2 decimals by default, 4 for sub-unit results (micro values),
 * 6 for dust, and 0 for zero-decimal currencies (JPY, KRW, VND…).
 */
export function decimalsFor(code: string, value: number): number {
  // crypto & metals always keep their native precision
  if (HIGH_DECIMAL[code] != null) return HIGH_DECIMAL[code];
  if (FORMAT.precision !== "auto") return FORMAT.precision;
  if (ZERO_DECIMAL.has(code)) return 0;
  const a = Math.abs(value);
  if (a > 0 && a < 0.0001) return 6;
  if (a > 0 && a < 1) return 4;
  return 2;
}

/** Locale-grouped amount, e.g. 1250.5 → "1,250.50" */
export function formatValue(value: number, code: string): string {
  if (!isFinite(value)) return "—";
  const d = decimalsFor(code, value);
  return new Intl.NumberFormat(FORMAT.locale, {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  }).format(value);
}

/** Unit-rate formatting: more precision for small rates, grouped for big ones. */
export function formatRate(value: number): string {
  if (!isFinite(value)) return "—";
  // Sub-dust rates (e.g. USD→BTC ≈ 1.03e-8) need scientific notation.
  if (value > 0 && value < 0.0001) return Number(value.toPrecision(3)).toString();
  const d = value >= 1000 ? 2 : value >= 0.01 ? 4 : 6;
  return new Intl.NumberFormat(FORMAT.locale, {
    minimumFractionDigits: Math.min(d, 4),
    maximumFractionDigits: d,
  }).format(value);
}

/* ------------------------- inline keypad expressions ----------------------- */

/** Keypad operators in display form. */
export const EXPR_OPS = "+−×÷";
const OP_MAP: Record<string, string> = { "−": "-", "×": "*", "÷": "/" };

/**
 * Evaluate a keypad expression with ×÷-before-+- precedence.
 * Prefix semantics: a trailing operator is ignored ("100+" → 100), matching
 * native calculator behaviour while the user keeps typing.
 */
export function evalExpression(raw: string): number | null {
  if (!raw) return null;
  let s = raw
    .split("")
    .map((c) => OP_MAP[c] ?? c)
    .join("");
  if (s.startsWith("-")) s = `0${s}`; // results of "=" may be negative
  if (!/^[\d.+\-*/]+$/.test(s)) return null;

  const nums: number[] = [];
  const ops: string[] = [];
  const re = /(\d*\.?\d+)|([+\-*/])/g;
  let m: RegExpExecArray | null;
  let lastEnd = 0;
  while ((m = re.exec(s)) !== null) {
    if (m.index !== lastEnd) return null;
    lastEnd = re.lastIndex;
    if (m[1] !== undefined) nums.push(Number(m[1]));
    else ops.push(m[2]);
  }
  if (lastEnd !== s.length || nums.length === 0) return null;
  if (ops.length > nums.length - 1 && ops.length !== nums.length) return null;

  const values = [...nums];
  const operators = ops.slice(0, nums.length - 1); // drop a trailing operator

  // first pass: × and ÷
  for (let i = 0; i < operators.length; ) {
    if (operators[i] === "*" || operators[i] === "/") {
      const r = operators[i] === "*" ? values[i] * values[i + 1] : values[i] / values[i + 1];
      values.splice(i, 2, r);
      operators.splice(i, 1);
    } else {
      i++;
    }
  }
  // second pass: + and −
  let acc = values[0];
  for (let i = 0; i < operators.length; i++) {
    acc = operators[i] === "+" ? acc + values[i + 1] : acc - values[i + 1];
  }
  return Number.isFinite(acc) ? acc : null;
}

/** Expression-aware amount: 0 when incomplete/invalid. */
export function amountOf(raw: string): number {
  return evalExpression(raw) ?? 0;
}

function groupSegment(seg: string): string {
  if (seg === "") return "";
  const [int, frac] = seg.split(".");
  try {
    const grouped = new Intl.NumberFormat(FORMAT.locale, { maximumFractionDigits: 0 }).format(
      BigInt(int || "0")
    );
    return seg.includes(".") ? `${grouped}.${frac ?? ""}` : grouped;
  } catch {
    return seg; // defensive: never crash on malformed input
  }
}

/** Display formatter: groups every numeric segment, keeps operators spaced. */
export function formatInput(raw: string): string {
  if (!raw) return "0";
  const parts = raw.split(/([+−×÷])/);
  if (parts.length === 1) return groupSegment(raw) || "0";
  return parts
    .map((p) => (p.length === 1 && EXPR_OPS.includes(p) ? ` ${p} ` : groupSegment(p)))
    .join("");
}

/** True when a raw keypad string is a well-formed expression. */
export function isValidRaw(raw: unknown): raw is string {
  return (
    typeof raw === "string" &&
    raw.length > 0 &&
    raw.length <= 48 &&
    /^-?(\d{0,12}(\.\d{0,8})?)([+×÷−](?![+×÷−])(\d{0,12}(\.\d{0,8})?)?)*$/.test(raw)
  );
}

export function parseAmount(raw: string): number {
  const n = Number(raw);
  return isFinite(n) ? n : 0;
}

/* ------------------------------ deterministic ----------------------------- */

export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* --------------------------------- dates ---------------------------------- */

export function isoDay(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function fmtDayShort(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function fmtClock(ts: number): string {
  return new Date(ts).toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

/* --------------------------- synthetic 7-day walk -------------------------- */

export interface HistoryPoint {
  date: string; // ISO day
  value: number;
}

/**
 * Deterministic random walk ending exactly at the live cross rate.
 * Used when the pair is outside Frankfurter's ECB coverage (e.g. NGN)
 * or the device is offline — labelled "EST." in the UI.
 */
export function syntheticHistory(
  from: string,
  to: string,
  endRate: number,
  days = 7
): HistoryPoint[] {
  const rand = mulberry32(hashString(`${from}/${to}/${isoDay(new Date())}`));
  const values: number[] = [endRate];
  for (let i = 1; i < days; i++) {
    const delta = (rand() - 0.5) * 0.012; // ±0.6% daily drift
    values.unshift(Number((values[0] / (1 + delta)).toFixed(10)));
  }
  const today = new Date();
  return values.map((v, i) => {
    const d = new Date(today.getTime() - (days - 1 - i) * 86400000);
    return { date: isoDay(d), value: v };
  });
}
