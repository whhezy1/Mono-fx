/**
 * ISO-4217 code → emoji flag. Rendered through a grayscale filter in-app to
 * keep the strict monochrome identity ("mono flags"); full color returns in
 * exported receipts & shared text where it belongs.
 */
const FLAGS: Record<string, string> = {
  USD: "🇺🇸", EUR: "🇪🇺", GBP: "🇬🇧", JPY: "🇯🇵", NGN: "🇳🇬", CNY: "🇨🇳", INR: "🇮🇳",
  CAD: "🇨🇦", AUD: "🇦🇺", CHF: "🇨🇭", SEK: "🇸🇪", NOK: "🇳🇴", DKK: "🇩🇰", NZD: "🇳🇿",
  SGD: "🇸🇬", HKD: "🇭🇰", KRW: "🇰🇷", MXN: "🇲🇽", BRL: "🇧🇷", ZAR: "🇿🇦", AED: "🇦🇪",
  SAR: "🇸🇦", QAR: "🇶🇦", TRY: "🇹🇷", RUB: "🇷🇺", PLN: "🇵🇱", THB: "🇹🇭", IDR: "🇮🇩",
  PHP: "🇵🇭", MYR: "🇲🇾", VND: "🇻🇳", EGP: "🇪🇬", KES: "🇰🇪", GHS: "🇬🇭", ARS: "🇦🇷",
  CLP: "🇨🇱", COP: "🇨🇴", ISK: "🇮🇸",
  CZK: "🇨🇿", HUF: "🇭🇺", RON: "🇷🇴", BGN: "🇧🇬", RSD: "🇷🇸", BAM: "🇧🇦", MKD: "🇲🇰",
  ALL: "🇦🇱", MDL: "🇲🇩", UAH: "🇺🇦", BYN: "🇧🇾", GEL: "🇬🇪", AMD: "🇦🇲", AZN: "🇦🇿",
  GIP: "🇬🇮", FKP: "🇫🇰", SHP: "🇸🇭",
  ILS: "🇮🇱", KWD: "🇰🇼", BHD: "🇧🇭", OMR: "🇴🇲", JOD: "🇯🇴", LBP: "🇱🇧", IQD: "🇮🇶",
  IRR: "🇮🇷", SYP: "🇸🇾", YER: "🇾🇪", AFN: "🇦🇫",
  PKR: "🇵🇰", BDT: "🇧🇩", LKR: "🇱🇰", NPR: "🇳🇵", BTN: "🇧🇹", MVR: "🇲🇻",
  TWD: "🇹🇼", MOP: "🇲🇴", MNT: "🇲🇳", KZT: "🇰🇿", KGS: "🇰🇬", TJS: "🇹🇯", TMT: "🇹🇲",
  UZS: "🇺🇿", MMK: "🇲🇲", KHR: "🇰🇭", LAK: "🇱🇦", BND: "🇧🇳",
  MAD: "🇲🇦", TND: "🇹🇳", DZD: "🇩🇿", LYD: "🇱🇾", SDG: "🇸🇩",
  XOF: "🌍", XAF: "🌍", XCD: "🌍", XPF: "🌍",
  CVE: "🇨🇻", GMD: "🇬🇲", GNF: "🇬🇳", SLE: "🇸🇱", LRD: "🇱🇷", MRU: "🇲🇷", STN: "🇸🇹",
  ETB: "🇪🇹", TZS: "🇹🇿", UGX: "🇺🇬", RWF: "🇷🇼", BIF: "🇧🇮", CDF: "🇨🇩", MGA: "🇲🇬",
  MUR: "🇲🇺", SCR: "🇸🇨", DJF: "🇩🇯", ERN: "🇪🇷", SOS: "🇸🇴", AOA: "🇦🇴", ZMW: "🇿🇲",
  MWK: "🇲🇼", MZN: "🇲🇿", BWP: "🇧🇼", NAD: "🇳🇦", SZL: "🇸🇿", LSL: "🇱🇸",
  DOP: "🇩🇴", JMD: "🇯🇲", HTG: "🇭🇹", GTQ: "🇬🇹", HNL: "🇭🇳", NIO: "🇳🇮", CRC: "🇨🇷",
  PAB: "🇵🇦", BZD: "🇧🇿", KYD: "🇰🇾", BSD: "🇧🇸", BBD: "🇧🇧", TTD: "🇹🇹", BMD: "🇧🇲",
  AWG: "🇦🇼", ANG: "🇨🇼", GYD: "🇬🇾", SRD: "🇸🇷", VES: "🇻🇪", BOB: "🇧🇴", PYG: "🇵🇾",
  UYU: "🇺🇾", PEN: "🇵🇪",
  FJD: "🇫🇯", PGK: "🇵🇬", SBD: "🇸🇧", VUV: "🇻🇺", WST: "🇼🇸", TOP: "🇹🇴",
  /* assets render their glyph — monochrome by nature */
  BTC: "₿", ETH: "Ξ", XAU: "Au", XAG: "Ag",
};

export function flagOf(code: string): string {
  return FLAGS[code] ?? "🏳️";
}
