import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Mock local authentication — accounts live entirely in localStorage and
 * nothing ever leaves the device.
 *
 * Passwords are hashed with a pure-JS SHA-256 (FIPS 180-4). crypto.subtle is
 * deliberately avoided: it only exists in secure contexts, so a hash created
 * on http:// (legacy djb2 fallback) would never verify on localhost / https
 * (SHA-256) — locking users out with correct credentials. Pure JS is
 * deterministic everywhere; legacy djb2 hashes migrate automatically on
 * sign-in. Core logic is framework-free so it can be tested headlessly.
 */

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  createdAt: number;
}

interface StoredUser extends AuthUser {
  passHash: string;
}

export interface AuthResult {
  user: AuthUser | null;
  error: string | null;
}

const USERS_KEY = "monofx:users";
const SESSION_KEY = "monofx:session";

export const DEMO_EMAIL = "demo@monofx.app";
export const DEMO_PASS = "demo1234";

/** Guest mode — a device-local pseudo-account, no credentials needed. */
export const GUEST_ID = "guest";
const guestUser = (): AuthUser => ({
  id: GUEST_ID,
  name: "Guest",
  email: "guest@this-device",
  createdAt: Date.now(),
});

export function signInGuestUser(): AuthUser {
  try {
    localStorage.setItem(SESSION_KEY, GUEST_ID);
  } catch { /* non-fatal */ }
  return guestUser();
}

/** Per-user storage key so accounts never share data. */
export const ukey = (userId: string, key: string) => `monofx:u:${userId}:${key}`;

/* ------------------------------ hashing ---------------------------------- */

const rotr = (x: number, n: number) => (x >>> n) | (x << (32 - n));

// First 32 bits of the fractional parts of the cube roots of the first 64 primes.
const K = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

/** Pure-JS SHA-256 — byte-for-byte identical to crypto.subtle.digest. */
export function hashPassword(text: string): string {
  const bytes = new TextEncoder().encode(text);
  const l = bytes.length;
  const bitLen = l * 8;

  // message padding: append 0x80, zeros, then 64-bit big-endian bit length
  const padded = new Uint8Array((((l + 8) >> 6) + 1) << 6);
  padded.set(bytes);
  padded[l] = 0x80;
  const dv = new DataView(padded.buffer);
  dv.setUint32(padded.length - 8, Math.floor(bitLen / 0x100000000));
  dv.setUint32(padded.length - 4, bitLen >>> 0);

  const H = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ];
  const w = new Uint32Array(64);

  for (let i = 0; i < padded.length; i += 64) {
    for (let t = 0; t < 16; t++) w[t] = dv.getUint32(i + t * 4);
    for (let t = 16; t < 64; t++) {
      const x = w[t - 15];
      const y = w[t - 2];
      const s0 = rotr(x, 7) ^ rotr(x, 18) ^ (x >>> 3);
      const s1 = rotr(y, 17) ^ rotr(y, 19) ^ (y >>> 10);
      w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
    }

    let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];

    for (let t = 0; t < 64; t++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[t] + w[t]) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0;
      d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }

    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0;
    H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0;
    H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }

  return H.map((x) => x.toString(16).padStart(8, "0")).join("");
}

/** Legacy context-dependent fallback — kept only to migrate old accounts. */
function legacyDjb2(text: string): string {
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
  return `djb2:${(h >>> 0).toString(16)}`;
}

/* ------------------------------ storage ---------------------------------- */

function readUsers(): StoredUser[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(USERS_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeUsers(users: StoredUser[]) {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch { /* non-fatal */ }
}

function readSession(): string | null {
  try {
    return localStorage.getItem(SESSION_KEY);
  } catch {
    return null;
  }
}

const strip = (v: StoredUser | null | undefined): AuthUser | null =>
  v ? { id: v.id, name: v.name, email: v.email, createdAt: v.createdAt } : null;

export function validEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

/* --------------------------- core (testable) ------------------------------ */

/** Create an account and start a session. */
export function signUpWith(name: string, email: string, pass: string): AuthResult {
  const cleanEmail = email.trim().toLowerCase();
  if (name.trim().length < 2) return { user: null, error: "NAME MUST BE AT LEAST 2 CHARACTERS" };
  if (!validEmail(cleanEmail)) return { user: null, error: "ENTER A VALID EMAIL ADDRESS" };
  if (pass.length < 6) return { user: null, error: "PASSWORD MUST BE AT LEAST 6 CHARACTERS" };
  const users = readUsers();
  if (users.some((u) => u.email === cleanEmail)) {
    return { user: null, error: "ACCOUNT ALREADY EXISTS — SIGN IN INSTEAD" };
  }
  const stored: StoredUser = {
    id: `u_${Date.now().toString(36)}`,
    name: name.trim(),
    email: cleanEmail,
    createdAt: Date.now(),
    passHash: hashPassword(pass),
  };
  writeUsers([...users, stored]);
  try {
    localStorage.setItem(SESSION_KEY, stored.id);
  } catch { /* non-fatal */ }
  return { user: strip(stored), error: null };
}

/** Verify credentials, migrate legacy hashes, start a session. */
export function signInWith(email: string, pass: string): AuthResult {
  const users = readUsers();
  const found = users.find((u) => u.email === email.trim().toLowerCase());
  if (!found) {
    return {
      user: null,
      error: "NO ACCOUNT FOUND · ACCOUNTS LIVE IN THIS BROWSER ONLY — TRY DEMO",
    };
  }

  const hash = hashPassword(pass);
  if (hash !== found.passHash) {
    // Migrate accounts stored under the legacy context-dependent fallback.
    if (found.passHash === legacyDjb2(pass)) {
      found.passHash = hash;
      writeUsers(users.map((u) => (u.id === found.id ? found : u)));
    } else {
      return {
        user: null,
        error: "INCORRECT PASSWORD · CHECK CAPS LOCK / AUTOFILL — USE THE 👁 BUTTON",
      };
    }
  }

  try {
    localStorage.setItem(SESSION_KEY, found.id);
  } catch { /* non-fatal */ }
  return { user: strip(found), error: null };
}

/** Ensures the demo account exists, then signs it in. */
export function signInDemoUser(): AuthUser {
  const users = readUsers();
  let demo = users.find((u) => u.email === DEMO_EMAIL);
  if (!demo) {
    demo = {
      id: "demo",
      name: "Demo Trader",
      email: DEMO_EMAIL,
      createdAt: Date.now(),
      passHash: hashPassword(DEMO_PASS),
    };
    writeUsers([...users, demo]);
  }
  try {
    localStorage.setItem(SESSION_KEY, demo.id);
  } catch { /* non-fatal */ }
  return strip(demo)!;
}

/* --------------------------- account management --------------------------- */

/** 1–2 letter avatar mark derived from the display name. */
export const initialsOf = (name: string): string => {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "◐";
  return parts
    .map((p) => p[0]!.toUpperCase())
    .slice(0, 2)
    .join("");
};

const DATA_SUFFIXES = [
  "prefs", "favs", "pairs", "history", "basket",
  "alertprefs", "alerts", "folders", "fee", "settings",
];

/** Remove every localStorage entry owned by an account. */
export function deleteAccountData(userId: string) {
  try {
    DATA_SUFFIXES.forEach((s) => localStorage.removeItem(ukey(userId, s)));
    localStorage.removeItem(SESSION_KEY);
  } catch { /* non-fatal */ }
}

/** Edit display name / email with validation. Returns an error or null. */
export function updateAccountFields(
  userId: string,
  patch: { name?: string; email?: string }
): string | null {
  if (userId === GUEST_ID) return null; // guest edits stay in-memory
  const users = readUsers();
  const me = users.find((u) => u.id === userId);
  if (!me) return "ACCOUNT NOT FOUND";
  const name = (patch.name ?? me.name).trim();
  const email = (patch.email ?? me.email).trim().toLowerCase();
  if (name.length < 2) return "NAME MUST BE AT LEAST 2 CHARACTERS";
  if (!validEmail(email)) return "ENTER A VALID EMAIL ADDRESS";
  if (users.some((u) => u.email === email && u.id !== userId)) return "EMAIL ALREADY IN USE";
  me.name = name;
  me.email = email;
  writeUsers(users);
  return null;
}

/** Permanently remove the account record and all of its data. */
export function removeAccount(userId: string) {
  if (userId !== GUEST_ID) writeUsers(readUsers().filter((u) => u.id !== userId));
  deleteAccountData(userId);
}

/** Nuclear option for hopelessly stale local state — wipes accounts only. */
export function resetLocalAccounts() {
  try {
    localStorage.removeItem(USERS_KEY);
    localStorage.removeItem(SESSION_KEY);
  } catch { /* non-fatal */ }
}

/** Restore the session saved on this device, if any. */
export function restoreSession(): AuthUser | null {
  const id = readSession();
  if (!id) return null;
  if (id === GUEST_ID) return guestUser();
  return strip(readUsers().find((u) => u.id === id) ?? null);
}

/* -------------------------------- hook ------------------------------------ */

export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(() => restoreSession());

  const signIn = useCallback(async (email: string, pass: string): Promise<string | null> => {
    const r = signInWith(email, pass);
    if (r.user) setUser(r.user);
    return r.error;
  }, []);

  const signUp = useCallback(
    async (name: string, email: string, pass: string): Promise<string | null> => {
      const r = signUpWith(name, email, pass);
      if (r.user) setUser(r.user);
      return r.error;
    },
    []
  );

  const signOut = useCallback(() => {
    try {
      localStorage.removeItem(SESSION_KEY);
    } catch { /* non-fatal */ }
    setUser(null);
  }, []);

  const demo = useCallback(() => {
    setUser(signInDemoUser());
  }, []);

  const guest = useCallback(() => {
    setUser(signInGuestUser());
  }, []);

  const reset = useCallback(() => {
    resetLocalAccounts();
    setUser(null);
  }, []);

  const userRef = useRef(user);
  userRef.current = user;

  const update = useCallback((patch: { name?: string; email?: string }): string | null => {
    const u = userRef.current;
    if (!u) return "NOT SIGNED IN";
    const err = updateAccountFields(u.id, patch);
    if (err) return err;
    setUser((prev) =>
      prev
        ? {
            ...prev,
            name: (patch.name ?? prev.name).trim(),
            email: (patch.email ?? prev.email).trim().toLowerCase(),
          }
        : prev
    );
    return null;
  }, []);

  const destroy = useCallback(() => {
    const u = userRef.current;
    if (!u) return;
    removeAccount(u.id);
    setUser(null);
  }, []);

  // cross-tab session sync (cheap nicety)
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === SESSION_KEY || e.key === USERS_KEY) setUser(restoreSession());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  return { user, signIn, signUp, signOut, demo, guest, reset, update, destroy };
}
