export interface Currency {
  code: string;
  symbol: string;
  name: string;
  country: string;
}

/**
 * ISO-4217 universe shown in the selector sheet (~140 currencies).
 * Symbols render in monochrome roundels — no flags, keeping the theme strict.
 * Majors first, then grouped by region.
 */
export const CURRENCIES: Currency[] = [
  /* ---- majors ---- */
  { code: "USD", symbol: "$", name: "US Dollar", country: "United States" },
  { code: "EUR", symbol: "€", name: "Euro", country: "Eurozone" },
  { code: "GBP", symbol: "£", name: "British Pound", country: "United Kingdom" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen", country: "Japan" },
  { code: "NGN", symbol: "₦", name: "Nigerian Naira", country: "Nigeria" },
  { code: "CNY", symbol: "¥", name: "Chinese Yuan", country: "China" },
  { code: "INR", symbol: "₹", name: "Indian Rupee", country: "India" },
  { code: "CAD", symbol: "$", name: "Canadian Dollar", country: "Canada" },
  { code: "AUD", symbol: "$", name: "Australian Dollar", country: "Australia" },
  { code: "CHF", symbol: "Fr", name: "Swiss Franc", country: "Switzerland" },
  { code: "SEK", symbol: "kr", name: "Swedish Krona", country: "Sweden" },
  { code: "NOK", symbol: "kr", name: "Norwegian Krone", country: "Norway" },
  { code: "DKK", symbol: "kr", name: "Danish Krone", country: "Denmark" },
  { code: "NZD", symbol: "$", name: "New Zealand Dollar", country: "New Zealand" },
  { code: "SGD", symbol: "$", name: "Singapore Dollar", country: "Singapore" },
  { code: "HKD", symbol: "$", name: "Hong Kong Dollar", country: "Hong Kong" },
  { code: "KRW", symbol: "₩", name: "South Korean Won", country: "South Korea" },
  { code: "MXN", symbol: "$", name: "Mexican Peso", country: "Mexico" },
  { code: "BRL", symbol: "R$", name: "Brazilian Real", country: "Brazil" },
  { code: "ZAR", symbol: "R", name: "South African Rand", country: "South Africa" },
  { code: "AED", symbol: "د.إ", name: "UAE Dirham", country: "United Arab Emirates" },
  { code: "SAR", symbol: "﷼", name: "Saudi Riyal", country: "Saudi Arabia" },
  { code: "QAR", symbol: "QR", name: "Qatari Riyal", country: "Qatar" },
  { code: "TRY", symbol: "₺", name: "Turkish Lira", country: "Türkiye" },
  { code: "RUB", symbol: "₽", name: "Russian Ruble", country: "Russia" },
  { code: "PLN", symbol: "zł", name: "Polish Złoty", country: "Poland" },
  { code: "THB", symbol: "฿", name: "Thai Baht", country: "Thailand" },
  { code: "IDR", symbol: "Rp", name: "Indonesian Rupiah", country: "Indonesia" },
  { code: "PHP", symbol: "₱", name: "Philippine Peso", country: "Philippines" },
  { code: "MYR", symbol: "RM", name: "Malaysian Ringgit", country: "Malaysia" },
  { code: "VND", symbol: "₫", name: "Vietnamese Dong", country: "Vietnam" },
  { code: "EGP", symbol: "E£", name: "Egyptian Pound", country: "Egypt" },
  { code: "KES", symbol: "KSh", name: "Kenyan Shilling", country: "Kenya" },
  { code: "GHS", symbol: "GH₵", name: "Ghanaian Cedi", country: "Ghana" },
  { code: "ARS", symbol: "AR$", name: "Argentine Peso", country: "Argentina" },
  { code: "CLP", symbol: "CL$", name: "Chilean Peso", country: "Chile" },
  { code: "COP", symbol: "CO$", name: "Colombian Peso", country: "Colombia" },
  { code: "ISK", symbol: "kr", name: "Icelandic Króna", country: "Iceland" },

  /* ---- Europe ---- */
  { code: "CZK", symbol: "Kč", name: "Czech Koruna", country: "Czechia" },
  { code: "HUF", symbol: "Ft", name: "Hungarian Forint", country: "Hungary" },
  { code: "RON", symbol: "lei", name: "Romanian Leu", country: "Romania" },
  { code: "BGN", symbol: "лв", name: "Bulgarian Lev", country: "Bulgaria" },
  { code: "RSD", symbol: "din", name: "Serbian Dinar", country: "Serbia" },
  { code: "BAM", symbol: "KM", name: "Convertible Mark", country: "Bosnia & Herzegovina" },
  { code: "MKD", symbol: "ден", name: "Macedonian Denar", country: "North Macedonia" },
  { code: "ALL", symbol: "L", name: "Albanian Lek", country: "Albania" },
  { code: "MDL", symbol: "L", name: "Moldovan Leu", country: "Moldova" },
  { code: "UAH", symbol: "₴", name: "Ukrainian Hryvnia", country: "Ukraine" },
  { code: "BYN", symbol: "Br", name: "Belarusian Ruble", country: "Belarus" },
  { code: "GEL", symbol: "₾", name: "Georgian Lari", country: "Georgia" },
  { code: "AMD", symbol: "֏", name: "Armenian Dram", country: "Armenia" },
  { code: "AZN", symbol: "₼", name: "Azerbaijani Manat", country: "Azerbaijan" },
  { code: "GIP", symbol: "£", name: "Gibraltar Pound", country: "Gibraltar" },
  { code: "FKP", symbol: "£", name: "Falkland Islands Pound", country: "Falkland Islands" },
  { code: "SHP", symbol: "£", name: "Saint Helena Pound", country: "Saint Helena" },

  /* ---- Middle East ---- */
  { code: "ILS", symbol: "₪", name: "Israeli New Shekel", country: "Israel" },
  { code: "KWD", symbol: "KD", name: "Kuwaiti Dinar", country: "Kuwait" },
  { code: "BHD", symbol: "BD", name: "Bahraini Dinar", country: "Bahrain" },
  { code: "OMR", symbol: "﷼", name: "Omani Rial", country: "Oman" },
  { code: "JOD", symbol: "JD", name: "Jordanian Dinar", country: "Jordan" },
  { code: "LBP", symbol: "L£", name: "Lebanese Pound", country: "Lebanon" },
  { code: "IQD", symbol: "ع.د", name: "Iraqi Dinar", country: "Iraq" },
  { code: "IRR", symbol: "﷼", name: "Iranian Rial", country: "Iran" },
  { code: "SYP", symbol: "£S", name: "Syrian Pound", country: "Syria" },
  { code: "YER", symbol: "﷼", name: "Yemeni Rial", country: "Yemen" },
  { code: "AFN", symbol: "؋", name: "Afghan Afghani", country: "Afghanistan" },

  /* ---- South Asia ---- */
  { code: "PKR", symbol: "₨", name: "Pakistani Rupee", country: "Pakistan" },
  { code: "BDT", symbol: "৳", name: "Bangladeshi Taka", country: "Bangladesh" },
  { code: "LKR", symbol: "₨", name: "Sri Lankan Rupee", country: "Sri Lanka" },
  { code: "NPR", symbol: "₨", name: "Nepalese Rupee", country: "Nepal" },
  { code: "BTN", symbol: "Nu.", name: "Bhutanese Ngultrum", country: "Bhutan" },
  { code: "MVR", symbol: "Rf", name: "Maldivian Rufiyaa", country: "Maldives" },

  /* ---- East & Central Asia ---- */
  { code: "TWD", symbol: "NT$", name: "New Taiwan Dollar", country: "Taiwan" },
  { code: "MOP", symbol: "MOP$", name: "Macanese Pataca", country: "Macao" },
  { code: "MNT", symbol: "₮", name: "Mongolian Tögrög", country: "Mongolia" },
  { code: "KZT", symbol: "₸", name: "Kazakhstani Tenge", country: "Kazakhstan" },
  { code: "KGS", symbol: "сом", name: "Kyrgyzstani Som", country: "Kyrgyzstan" },
  { code: "TJS", symbol: "SM", name: "Tajikistani Somoni", country: "Tajikistan" },
  { code: "TMT", symbol: "T", name: "Turkmenistani Manat", country: "Turkmenistan" },
  { code: "UZS", symbol: "so'm", name: "Uzbekistani Som", country: "Uzbekistan" },
  { code: "MMK", symbol: "K", name: "Myanmar Kyat", country: "Myanmar" },
  { code: "KHR", symbol: "៛", name: "Cambodian Riel", country: "Cambodia" },
  { code: "LAK", symbol: "₭", name: "Lao Kip", country: "Laos" },
  { code: "BND", symbol: "B$", name: "Brunei Dollar", country: "Brunei" },

  /* ---- Africa ---- */
  { code: "MAD", symbol: "DH", name: "Moroccan Dirham", country: "Morocco" },
  { code: "TND", symbol: "DT", name: "Tunisian Dinar", country: "Tunisia" },
  { code: "DZD", symbol: "DA", name: "Algerian Dinar", country: "Algeria" },
  { code: "LYD", symbol: "LD", name: "Libyan Dinar", country: "Libya" },
  { code: "SDG", symbol: "LS", name: "Sudanese Pound", country: "Sudan" },
  { code: "XOF", symbol: "CFA", name: "West African CFA Franc", country: "UEMOA (8 states)" },
  { code: "XAF", symbol: "FCFA", name: "Central African CFA Franc", country: "CEMAC (6 states)" },
  { code: "CVE", symbol: "Esc", name: "Cape Verdean Escudo", country: "Cabo Verde" },
  { code: "GMD", symbol: "D", name: "Gambian Dalasi", country: "Gambia" },
  { code: "GNF", symbol: "FG", name: "Guinean Franc", country: "Guinea" },
  { code: "SLE", symbol: "Le", name: "Sierra Leonean Leone", country: "Sierra Leone" },
  { code: "LRD", symbol: "L$", name: "Liberian Dollar", country: "Liberia" },
  { code: "MRU", symbol: "UM", name: "Mauritanian Ouguiya", country: "Mauritania" },
  { code: "STN", symbol: "Db", name: "São Tomé Dobra", country: "São Tomé & Príncipe" },
  { code: "ETB", symbol: "Br", name: "Ethiopian Birr", country: "Ethiopia" },
  { code: "TZS", symbol: "TSh", name: "Tanzanian Shilling", country: "Tanzania" },
  { code: "UGX", symbol: "USh", name: "Ugandan Shilling", country: "Uganda" },
  { code: "RWF", symbol: "RF", name: "Rwandan Franc", country: "Rwanda" },
  { code: "BIF", symbol: "FBu", name: "Burundian Franc", country: "Burundi" },
  { code: "CDF", symbol: "FC", name: "Congolese Franc", country: "DR Congo" },
  { code: "MGA", symbol: "Ar", name: "Malagasy Ariary", country: "Madagascar" },
  { code: "MUR", symbol: "₨", name: "Mauritian Rupee", country: "Mauritius" },
  { code: "SCR", symbol: "₨", name: "Seychellois Rupee", country: "Seychelles" },
  { code: "DJF", symbol: "Fdj", name: "Djiboutian Franc", country: "Djibouti" },
  { code: "ERN", symbol: "Nfk", name: "Eritrean Nakfa", country: "Eritrea" },
  { code: "SOS", symbol: "Sh", name: "Somali Shilling", country: "Somalia" },
  { code: "AOA", symbol: "Kz", name: "Angolan Kwanza", country: "Angola" },
  { code: "ZMW", symbol: "ZK", name: "Zambian Kwacha", country: "Zambia" },
  { code: "MWK", symbol: "MK", name: "Malawian Kwacha", country: "Malawi" },
  { code: "MZN", symbol: "MT", name: "Mozambican Metical", country: "Mozambique" },
  { code: "BWP", symbol: "P", name: "Botswana Pula", country: "Botswana" },
  { code: "NAD", symbol: "N$", name: "Namibian Dollar", country: "Namibia" },
  { code: "SZL", symbol: "E", name: "Swazi Lilangeni", country: "Eswatini" },
  { code: "LSL", symbol: "L", name: "Lesotho Loti", country: "Lesotho" },

  /* ---- Americas ---- */
  { code: "DOP", symbol: "RD$", name: "Dominican Peso", country: "Dominican Republic" },
  { code: "JMD", symbol: "J$", name: "Jamaican Dollar", country: "Jamaica" },
  { code: "HTG", symbol: "G", name: "Haitian Gourde", country: "Haiti" },
  { code: "GTQ", symbol: "Q", name: "Guatemalan Quetzal", country: "Guatemala" },
  { code: "HNL", symbol: "L", name: "Honduran Lempira", country: "Honduras" },
  { code: "NIO", symbol: "C$", name: "Nicaraguan Córdoba", country: "Nicaragua" },
  { code: "CRC", symbol: "₡", name: "Costa Rican Colón", country: "Costa Rica" },
  { code: "PAB", symbol: "B/.", name: "Panamanian Balboa", country: "Panama" },
  { code: "BZD", symbol: "BZ$", name: "Belize Dollar", country: "Belize" },
  { code: "KYD", symbol: "CI$", name: "Cayman Islands Dollar", country: "Cayman Islands" },
  { code: "BSD", symbol: "B$", name: "Bahamian Dollar", country: "Bahamas" },
  { code: "BBD", symbol: "Bds$", name: "Barbadian Dollar", country: "Barbados" },
  { code: "TTD", symbol: "TT$", name: "Trinidad & Tobago Dollar", country: "Trinidad & Tobago" },
  { code: "XCD", symbol: "EC$", name: "East Caribbean Dollar", country: "Eastern Caribbean" },
  { code: "BMD", symbol: "BD$", name: "Bermudian Dollar", country: "Bermuda" },
  { code: "AWG", symbol: "ƒ", name: "Aruban Florin", country: "Aruba" },
  { code: "ANG", symbol: "ƒ", name: "Netherlands Antillean Guilder", country: "Curaçao & Sint Maarten" },
  { code: "GYD", symbol: "GY$", name: "Guyanese Dollar", country: "Guyana" },
  { code: "SRD", symbol: "SR$", name: "Surinamese Dollar", country: "Suriname" },
  { code: "VES", symbol: "Bs.S", name: "Venezuelan Bolívar", country: "Venezuela" },
  { code: "BOB", symbol: "Bs", name: "Bolivian Boliviano", country: "Bolivia" },
  { code: "PYG", symbol: "₲", name: "Paraguayan Guaraní", country: "Paraguay" },
  { code: "UYU", symbol: "$U", name: "Uruguayan Peso", country: "Uruguay" },
  { code: "PEN", symbol: "S/", name: "Peruvian Sol", country: "Peru" },

  /* ---- Pacific ---- */
  { code: "FJD", symbol: "FJ$", name: "Fijian Dollar", country: "Fiji" },
  { code: "PGK", symbol: "K", name: "Papua New Guinean Kina", country: "Papua New Guinea" },
  { code: "SBD", symbol: "SI$", name: "Solomon Islands Dollar", country: "Solomon Islands" },
  { code: "VUV", symbol: "VT", name: "Vanuatu Vatu", country: "Vanuatu" },
  { code: "WST", symbol: "WS$", name: "Samoan Tala", country: "Samoa" },
  { code: "TOP", symbol: "T$", name: "Tongan Paʻanga", country: "Tonga" },
  { code: "XPF", symbol: "F", name: "CFP Franc", country: "French Pacific Territories" },

  /* ---- digital & precious-metal assets (priced via CoinGecko / gold-api) ---- */
  { code: "BTC", symbol: "₿", name: "Bitcoin", country: "Crypto Asset" },
  { code: "ETH", symbol: "Ξ", name: "Ethereum", country: "Crypto Asset" },
  { code: "XAU", symbol: "Au", name: "Gold · Troy Ounce", country: "Precious Metal" },
  { code: "XAG", symbol: "Ag", name: "Silver · Troy Ounce", country: "Precious Metal" },
];

/** Codes that are assets, not sovereign fiat (affects flags & sourcing). */
export const ASSET_CODES = new Set(["BTC", "ETH", "XAU", "XAG"]);

/** Quick-access chips rendered above the conversion card. */
export const QUICK_CODES = ["USD", "EUR", "GBP", "JPY", "NGN"];

const byCode = new Map(CURRENCIES.map((c) => [c.code, c]));

export function meta(code: string): Currency {
  return byCode.get(code) ?? { code, symbol: "¤", name: code, country: "—" };
}

/** High-precision units — crypto needs 8 dp, metals 4 dp. */
export const HIGH_DECIMAL: Record<string, number> = { BTC: 8, ETH: 8, XAU: 4, XAG: 4 };

/** Currencies conventionally quoted with 0 decimals. */
export const ZERO_DECIMAL = new Set([
  "JPY", "KRW", "VND", "IDR", "CLP", "COP", "ISK",
  "XOF", "XAF", "LAK", "MNT", "UGX", "BIF", "CDF", "RWF", "DJF", "GNF",
  "KHR", "VUV", "PYG", "IQD", "IRR", "LBP", "SYP", "HUF",
]);

/**
 * Bundled reference rates (USD base, indicative). Used to fill gaps so every
 * listed currency always resolves — live API values always take precedence,
 * and they power the app entirely when offline with no cached payload.
 */
export const FALLBACK_RATES: Record<string, number> = {
  USD: 1, EUR: 0.921, GBP: 0.789, JPY: 155.4, NGN: 1532.0, CNY: 7.24, INR: 84.2,
  CAD: 1.39, AUD: 1.53, CHF: 0.884, SEK: 10.62, NOK: 10.94, DKK: 6.87, NZD: 1.68,
  SGD: 1.34, HKD: 7.81, KRW: 1389.0, MXN: 18.42, BRL: 5.46, ZAR: 18.24, AED: 3.67,
  SAR: 3.75, QAR: 3.64, TRY: 36.5, RUB: 92.4, PLN: 3.96, THB: 34.2, IDR: 16255.0,
  PHP: 57.9, MYR: 4.42, VND: 25450.0, EGP: 49.3, KES: 129.2, GHS: 15.4, ARS: 1065.0,
  CLP: 950.0, COP: 4150.0, ISK: 138.4,
  /* Europe */
  CZK: 23.3, HUF: 366.0, RON: 4.58, BGN: 1.8, RSD: 107.9, BAM: 1.8, MKD: 56.6,
  ALL: 92.5, MDL: 17.7, UAH: 41.3, BYN: 3.27, GEL: 2.72, AMD: 386.0, AZN: 1.7,
  GIP: 0.789, FKP: 0.789, SHP: 0.789,
  /* Middle East */
  ILS: 3.6, KWD: 0.307, BHD: 0.376, OMR: 0.385, JOD: 0.709, LBP: 89500.0,
  IQD: 1310.0, IRR: 42000.0, SYP: 12900.0, YER: 250.3, AFN: 68.5,
  /* South Asia */
  PKR: 278.4, BDT: 118.5, LKR: 300.5, NPR: 134.3, BTN: 84.2, MVR: 15.4,
  /* East & Central Asia */
  TWD: 32.2, MOP: 8.04, MNT: 3400.0, KZT: 505.5, KGS: 87.4, TJS: 10.9, TMT: 3.5,
  UZS: 12650.0, MMK: 2100.0, KHR: 4015.0, LAK: 21700.0, BND: 1.34,
  /* Africa */
  MAD: 9.95, TND: 3.11, DZD: 134.6, LYD: 4.83, SDG: 600.5, XOF: 604.0, XAF: 604.0,
  CVE: 99.5, GMD: 70.5, GNF: 8650.0, SLE: 22.5, LRD: 180.4, MRU: 40.1, STN: 22.6,
  ETB: 122.0, TZS: 2510.0, UGX: 3705.0, RWF: 1380.0, BIF: 2940.0, CDF: 2850.0,
  MGA: 4630.0, MUR: 46.2, SCR: 14.8, DJF: 177.7, ERN: 15.0, SOS: 571.5,
  AOA: 915.0, ZMW: 27.0, MWK: 1740.0, MZN: 63.8, BWP: 13.7, NAD: 18.2,
  SZL: 18.2, LSL: 18.2,
  /* Americas */
  DOP: 60.9, JMD: 157.3, HTG: 130.9, GTQ: 7.73, HNL: 26.2, NIO: 36.8, CRC: 510.5,
  PAB: 1.0, BZD: 2.0, KYD: 0.83, BSD: 1.0, BBD: 2.0, TTD: 6.79, XCD: 2.7,
  BMD: 1.0, AWG: 1.79, ANG: 1.79, GYD: 209.0, SRD: 35.1, VES: 40.0, BOB: 6.91,
  PYG: 7350.0, UYU: 40.1, PEN: 3.73,
  /* Pacific */
  FJD: 2.24, PGK: 4.05, SBD: 8.33, VUV: 120.3, WST: 2.75, TOP: 2.36, XPF: 119.3,
  /* Assets — units per 1 USD (reference values, live prices take precedence) */
  BTC: 0.0000103, ETH: 0.000278, XAU: 0.000377, XAG: 0.0317,
};
