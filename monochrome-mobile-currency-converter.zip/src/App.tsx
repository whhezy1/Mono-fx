import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { type AlertPrefs } from "./components/AlertsPanel";
import AuthScreen from "./components/AuthScreen";
import BasketScreen, { BASKET_TARGETS } from "./components/BasketScreen";
import CurrencySheet, { type SheetSide } from "./components/CurrencySheet";
import FeeSimulator from "./components/FeeSimulator";
import FolderSheet, { type FolderSheetState } from "./components/FolderSheet";
import HistoryScreen from "./components/HistoryScreen";
import InstallSheet from "./components/InstallSheet";
import Keypad from "./components/Keypad";
import PinLock from "./components/PinLock";
import ProfileScreen from "./components/ProfileScreen";
import ReceiptModal from "./components/ReceiptModal";
import SettingsScreen from "./components/SettingsScreen";
import Sidebar, { type View } from "./components/Sidebar";
import Snapshot from "./components/Snapshot";
import StatusBar from "./components/StatusBar";
import Ticker from "./components/Ticker";
import Toast, { type ToastData } from "./components/Toast";
import TrendChart from "./components/TrendChart";
import { type WatchPair } from "./components/WatchlistPanel";
import { hashPassword, initialsOf, ukey, useAuth } from "./lib/auth";
import {
  DEFAULT_SETTINGS,
  FONT_ZOOM,
  loadSettings,
  saveSettings,
  type UserSettings,
} from "./lib/settings";
import { BUILD } from "./lib/version";
import { useAssetRates } from "./hooks/useAssetRates";
import { useHistory } from "./hooks/useHistory";
import { useInstallPrompt } from "./hooks/useInstallPrompt";
import { useKeyboard } from "./hooks/useKeyboard";
import { useRates, type RateStatus } from "./hooks/useRates";
import { useTheme } from "./hooks/useTheme";
import { useAlerts, type RateAlert } from "./hooks/useAlerts";
import { CURRENCIES, QUICK_CODES, meta } from "./lib/currencies";
import { loadFolders, saveFolders, type ExpenseFolder } from "./lib/folders";
import { nativeImpact } from "./lib/native";
import { buildCsv, downloadText, loadEntries, saveEntries, type ConversionEntry } from "./lib/ledger";
import {
  amountOf,
  configureFormatting,
  crossRate,
  evalExpression,
  EXPR_OPS,
  fmtClock,
  formatInput,
  formatRate,
  formatValue,
  isValidRaw,
} from "./lib/money";
import { cn } from "./utils/cn";

/* ------------------------------- tiny icons ------------------------------- */

const SwapIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M8 5v14M8 5 5 8m3-3 3 3" />
    <path d="M16 19V5m0 14 3-3m-3 3-3-3" />
  </svg>
);

const RefreshIcon = ({ spinning }: { spinning: boolean }) => (
  <svg className={cn("h-4 w-4 transition-transform", spinning && "animate-spin")} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M21 12a9 9 0 1 1-2.9-6.6" />
    <path d="M21 3v6h-6" />
  </svg>
);

const ChevronDown = () => (
  <svg className="h-3 w-3 text-zinc-500" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="m2.5 4.5 3.5 3.5 3.5-3.5" />
  </svg>
);

/* ------------------------------ sub-pieces -------------------------------- */

function CurrencyButton({ code, onClick }: { code: string; onClick: () => void }) {
  const m = meta(code);
  return (
    <button
      onClick={onClick}
      aria-label={`Change ${code}`}
      className="group flex items-center gap-2 rounded-full border border-line bg-black py-1.5 pr-3 pl-1.5 transition-all duration-150 active:scale-95 active:border-zinc-400"
    >
      <span className="flex h-7 w-7 items-center justify-center overflow-hidden rounded-full bg-white font-display text-[9px] font-bold text-black">
        {m.symbol}
      </span>
      <span className="font-display text-sm font-semibold tracking-wide">{code}</span>
      <ChevronDown />
    </button>
  );
}

function SyncBanner({ status, lastUpdated }: { status: RateStatus; lastUpdated: number | null }) {
  const off = -new Date().getTimezoneOffset() / 60;
  const text =
    status === "live" && lastUpdated
      ? `LIVE RATES · SYNCED ${fmtClock(lastUpdated)}`
      : status === "cached" && lastUpdated
        ? `SERVER UNREACHABLE · CACHED ${fmtClock(lastUpdated)}`
        : status === "offline" && lastUpdated
          ? `OFFLINE · LAST UPDATED ${fmtClock(lastUpdated)}`
          : status === "fallback"
            ? "REFERENCE RATES · NOT LIVE DATA"
            : "CONTACTING RATE SERVER…";

  const dot =
    status === "live"
      ? "bg-white animate-pulse-dot"
      : status === "boot"
        ? "bg-zinc-500 animate-blink"
        : "border border-zinc-400 bg-transparent";

  return (
    <div className="flex items-center justify-between rounded-full border border-line bg-panel px-3.5 py-2">
      <span className="flex items-center gap-2">
        <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />
        <span
          key={`${status}-${lastUpdated ?? 0}`}
          className="animate-tick font-mono text-[9px] font-medium tracking-[0.18em] text-zinc-400"
        >
          {text}
        </span>
      </span>
      <span className="font-mono text-[9px] tracking-[0.18em] text-zinc-600">
        UTC{off >= 0 ? "+" : ""}
        {off}
      </span>
    </div>
  );
}

/* ------------------------------ persistence ------------------------------- */

const KNOWN_CODES = new Set(CURRENCIES.map((c) => c.code));
const isCode = (v: unknown): v is string => typeof v === "string" && KNOWN_CODES.has(v);

function loadJSON<T>(key: string, fallback: T): T {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) ?? "");
    if (parsed != null) return parsed as T;
  } catch { /* first run */ }
  return fallback;
}

const DEFAULT_FAVS = ["EUR", "GBP", "JPY"];
const DEFAULT_PAIRS: WatchPair[] = [
  { id: "p_usdeur", from: "USD", to: "EUR" },
  { id: "p_gbpngn", from: "GBP", to: "NGN" },
];

function loadFavs(key: string): string[] {
  const f = loadJSON<unknown>(key, DEFAULT_FAVS);
  if (!Array.isArray(f)) return DEFAULT_FAVS;
  const clean = [...new Set(f.filter(isCode))];
  return clean.length ? clean : DEFAULT_FAVS;
}

function loadPairs(key: string): WatchPair[] {
  const p = loadJSON<unknown>(key, DEFAULT_PAIRS);
  if (!Array.isArray(p)) return DEFAULT_PAIRS;
  const clean = p.filter(
    (x): x is WatchPair =>
      !!x && typeof x === "object" && typeof (x as WatchPair).id === "string" &&
      isCode((x as WatchPair).from) && isCode((x as WatchPair).to)
  );
  return clean.length ? clean : DEFAULT_PAIRS;
}

/* ---------------------------------- app ----------------------------------- */

export default function App() {
  const { user, signIn, signUp, signOut, demo, guest, reset, update, destroy } = useAuth();
  const [theme, toggleTheme] = useTheme();
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const patchSettings = (patch: Partial<UserSettings>) =>
    setSettings((s) => ({ ...s, ...patch }));

  // Build marker — makes stale-cache problems instantly diagnosable.
  useEffect(() => {
    console.info(`◐ MONOFX · build ${BUILD} · local-first mock auth`);
  }, []);

  // Regional preferences apply live to every formatter in the app.
  useEffect(() => {
    configureFormatting({
      locale: settings.numberFormat === "comma" ? "en-US" : "de-DE",
      precision: settings.precision,
    });
  }, [settings.numberFormat, settings.precision]);

  // Reduce-motion accessibility preference.
  useEffect(() => {
    document.documentElement.dataset.motion = settings.reduceMotion ? "reduced" : "full";
  }, [settings.reduceMotion]);

  // Passcode session resets when the account changes / signs out.
  useEffect(() => {
    if (!user) unlockedRef.current = false;
  }, [user]);

  const [from, setFrom] = useState("USD");
  const [to, setTo] = useState("EUR");
  const [raw, setRaw] = useState("100");
  const [view, setView] = useState<View>("home");
  const [sheet, setSheet] = useState<SheetSide | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [flip, setFlip] = useState(0);
  const [inverted, setInverted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState<ToastData | null>(null);
  const [receiptEntry, setReceiptEntry] = useState<ConversionEntry | null>(null);
  const [favorites, setFavorites] = useState<string[]>(DEFAULT_FAVS);
  const [pairs, setPairs] = useState<WatchPair[]>(DEFAULT_PAIRS);
  const [entries, setEntries] = useState<ConversionEntry[]>([]);
  const [defaultBase, setDefaultBase] = useState("USD");
  const [basketCodes, setBasketCodes] = useState<string[]>(BASKET_TARGETS);
  const [alertPrefs, setAlertPrefs] = useState<AlertPrefs>({ inApp: true, push: true });
  const [feePct, setFeePct] = useState(0);
  const [feeIsCustom, setFeeIsCustom] = useState(false);
  const [feeCustom, setFeeCustom] = useState("");
  const [folders, setFolders] = useState<ExpenseFolder[]>([]);
  const [folderSheet, setFolderSheet] = useState<FolderSheetState>(null);
  /** Keypad dock: collapsed state survives reloads. */
  const [padOpen, setPadOpen] = useState(() => {
    try {
      return localStorage.getItem("monofx:padopen") !== "0";
    } catch {
      return true;
    }
  });

  /* ------------------------- PWA install & updates ------------------------ */

  const install = useInstallPrompt();
  const [iosGuide, setIosGuide] = useState(false);
  const [swUpdate, setSwUpdate] = useState(false);

  const handleInstall = async () => {
    const res = await install.promptInstall();
    if (res === "ios-guide") setIosGuide(true);
    else if (res === "prompted") showToast("INSTALL PROMPT SHOWN");
    else showToast("OPEN IN CHROME OR SAFARI TO INSTALL");
  };

  const applySwUpdate = () => {
    try {
      void navigator.serviceWorker?.getRegistration().then((reg) => {
        reg?.waiting?.postMessage({ type: "SKIP_WAITING" });
      });
    } catch { /* no worker */ }
    // fallback if controllerchange never fires
    window.setTimeout(() => window.location.reload(), 2500);
  };

  useEffect(() => {
    const onUpdate = () => setSwUpdate(true);
    const onController = () => window.location.reload();
    window.addEventListener("monofx-sw-update", onUpdate);
    navigator.serviceWorker?.addEventListener("controllerchange", onController);
    return () => {
      window.removeEventListener("monofx-sw-update", onUpdate);
      navigator.serviceWorker?.removeEventListener("controllerchange", onController);
    };
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem("monofx:padopen", padOpen ? "1" : "0");
    } catch { /* non-fatal */ }
  }, [padOpen]);

  const toastTimer = useRef<number | null>(null);
  /** Only genuine user actions arm the history logger — prevents restored
   * prefs at sign-in from being re-logged as a fresh conversion. */
  const touched = useRef(false);

  /* ------------------------------ passcode lock --------------------------- */

  const unlockedRef = useRef(false);
  const [pinState, setPinState] = useState<
    { mode: "unlock"; after: () => void } | { mode: "setup" } | null
  >(null);

  const requirePin = (fn: () => void) => {
    if (!settings.passcodeOn || unlockedRef.current) {
      fn();
      return;
    }
    setPinState({ mode: "unlock", after: fn });
  };

  const handlePasscodeToggle = () => {
    if (settings.passcodeOn) {
      // disabling requires proving you can unlock first
      requirePin(() => {
        patchSettings({ passcodeOn: false, passcodeHash: null });
        showToast("PASSCODE LOCK DISABLED");
      });
    } else {
      setPinState({ mode: "setup" });
    }
  };

  /* data-saver mode pauses every automatic fetch; manual refresh still works */
  const { rates: fiatRates, status, lastUpdated, refreshing, refresh } = useRates(
    !settings.dataSaver
  );
  const assets = useAssetRates(!settings.dataSaver);

  /** Fiat + crypto + metals merged into one USD-based rate map. */
  const rates = useMemo(() => {
    const assetRates: Record<string, number> = {};
    for (const [code, usd] of Object.entries(assets.prices)) {
      if (usd > 0) assetRates[code] = Number((1 / usd).toFixed(12));
    }
    return { ...fiatRates, ...assetRates };
  }, [fiatRates, assets.prices]);

  const rate = useMemo(() => crossRate(rates, from, to), [rates, from, to]);
  const history = useHistory(from, to, rate);

  const amount = amountOf(raw);

  /** Manual / street-rate override wins over the live cross rate. */
  const pairKey = `${from}/${to}`;
  const manualNum = Number(settings.manualRates[pairKey]);
  const usingManual = settings.manualRate && Number.isFinite(manualNum) && manualNum > 0;
  const effRate = settings.manualRate ? (usingManual ? manualNum : null) : rate;

  const converted = effRate != null ? amount * effRate : null;
  const convertedStr = converted != null ? formatValue(converted, to) : "—";

  /** Effective bank/card markup (preset or custom, clamped 0–50%). */
  const effFee = feeIsCustom ? Math.min(50, Math.max(0, Number(feeCustom) || 0)) : feePct;
  const afterFee = converted != null ? converted * (1 - effFee / 100) : null;

  /* --------------------------- alerts (per user) --------------------------- */

  const handleAlertTrigger = (a: RateAlert, cur: number) => {
    const msg = `ALERT · ${a.from}/${a.to} ${a.dir === "above" ? "≥" : "≤"} ${formatRate(a.target)} — NOW ${formatRate(cur)}`;
    if (alertPrefs.inApp) showToast(msg);
    try {
      if (alertPrefs.push && "Notification" in window && Notification.permission === "granted") {
        new Notification("MONO FX — RATE ALERT", {
          body: `${a.from}/${a.to} ${a.dir === "above" ? "reached" : "fell to"} ${formatRate(a.target)} · now ${formatRate(cur)}`,
        });
      }
    } catch { /* unsupported */ }
  };

  const { alerts, add: addAlert, remove: removeAlert, clearAll: clearAlerts } = useAlerts(
    user?.id ?? "",
    rates,
    handleAlertTrigger
  );

  /* ---------------------- per-account data lifecycle ---------------------- */

  useEffect(() => {
    if (!user) return;
    setFavorites(loadFavs(ukey(user.id, "favs")));
    setPairs(loadPairs(ukey(user.id, "pairs")));
    setEntries(loadEntries(ukey(user.id, "history")));
    const p = loadJSON<Partial<{ from: string; to: string; raw: string; defaultBase: string }>>(
      ukey(user.id, "prefs"),
      {}
    );
    if (isCode(p.defaultBase)) setDefaultBase(p.defaultBase);
    if (isCode(p.from)) setFrom(p.from);
    else if (isCode(p.defaultBase)) setFrom(p.defaultBase);
    if (isCode(p.to)) setTo(p.to);
    if (isValidRaw(p.raw)) setRaw(p.raw);
    const basket = loadJSON<unknown>(ukey(user.id, "basket"), BASKET_TARGETS);
    setBasketCodes(
      Array.isArray(basket) && basket.length
        ? basket.filter((c): c is string => isCode(c))
        : BASKET_TARGETS
    );
    const ap = loadJSON<Partial<AlertPrefs>>(ukey(user.id, "alertprefs"), {});
    setAlertPrefs({ inApp: ap.inApp !== false, push: ap.push !== false });
    setFolders(loadFolders(ukey(user.id, "folders")));
    const fee = loadJSON<Partial<{ feePct: number; feeIsCustom: boolean; feeCustom: string }>>(
      ukey(user.id, "fee"),
      {}
    );
    setFeePct(typeof fee.feePct === "number" && fee.feePct >= 0 ? fee.feePct : 0);
    setFeeIsCustom(!!fee.feeIsCustom);
    setFeeCustom(typeof fee.feeCustom === "string" ? fee.feeCustom : "");
    setSettings(loadSettings(ukey(user.id, "settings")));
    unlockedRef.current = false;
    setView("home");
    setSidebarOpen(false);
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!user) return;
    try {
      localStorage.setItem(ukey(user.id, "prefs"), JSON.stringify({ from, to, raw, defaultBase }));
      localStorage.setItem(ukey(user.id, "favs"), JSON.stringify(favorites));
      localStorage.setItem(ukey(user.id, "pairs"), JSON.stringify(pairs));
      localStorage.setItem(ukey(user.id, "basket"), JSON.stringify(basketCodes));
      localStorage.setItem(ukey(user.id, "alertprefs"), JSON.stringify(alertPrefs));
      saveFolders(ukey(user.id, "folders"), folders);
      localStorage.setItem(
        ukey(user.id, "fee"),
        JSON.stringify({ feePct, feeIsCustom, feeCustom })
      );
      saveSettings(ukey(user.id, "settings"), settings);
    } catch { /* non-fatal */ }
  }, [user, from, to, raw, favorites, pairs, defaultBase, basketCodes, alertPrefs, folders, feePct, feeIsCustom, feeCustom, settings]);

  useEffect(() => {
    if (!user) return;
    saveEntries(ukey(user.id, "history"), entries);
  }, [user, entries]);

  /* auto-log finished conversions (debounced while typing) */
  useEffect(() => {
    if (!user) return;
    if (!touched.current) return; // no user action yet (e.g. sign-in restore)
    if (amount <= 0 || effRate == null) return;
    touched.current = false; // consumed — next user input re-arms
    const t = window.setTimeout(() => {
      setEntries((prev) => {
        const last = prev[0];
        if (last && last.raw === raw && last.from === from && last.to === to) return prev;
        return [
          {
            id: Date.now().toString(36),
            ts: Date.now(),
            raw,
            from,
            to,
            rate: effRate,
            result: amount * effRate,
            ...(effFee > 0 ? { feePct: effFee } : {}),
          },
          ...prev,
        ].slice(0, 100);
      });
    }, 1500);
    return () => window.clearTimeout(t);
  }, [user, raw, from, to, rate, amount]);

  /* ------------------------------- feedback ------------------------------- */

  const showToast = (msg: string) => {
    setToast({ id: Date.now(), msg });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  };

  const doRefresh = async () => {
    if (refreshing) return;
    const ok = await refresh();
    void assets.refresh(); // manual sync works even in data-saver mode
    showToast(
      ok
        ? `LIVE RATES SYNCED · ${fmtClock(Date.now())}`
        : navigator.onLine
          ? "SYNC FAILED · CACHED RATES IN USE"
          : "OFFLINE · LAST SYNCED RATES IN USE"
    );
  };

  /** Haptic vibration + subtle click, gated by the Keypad Feedback setting.
   * Native Capacitor haptics take priority over navigator.vibrate. */
  const audioRef = useRef<AudioContext | null>(null);
  const vibrate = (ms: number) => {
    if (!settings.feedback) return;
    if (nativeImpact()) return; // real device haptic inside the native shell
    try {
      navigator.vibrate?.(ms);
    } catch { /* unsupported */ }
    try {
      const AC =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AC) {
        audioRef.current ??= new AC();
        const ctx = audioRef.current;
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = "square";
        o.frequency.value = 2100;
        g.gain.value = 0.015;
        o.connect(g);
        g.connect(ctx.destination);
        o.start();
        o.stop(ctx.currentTime + 0.035);
      }
    } catch { /* audio unavailable */ }
  };

  /* ------------------------------- handlers ------------------------------- */

  const swap = () => {
    setFrom(to);
    setTo(from);
    setFlip((f) => f + 1);
    setInverted(false);
    touched.current = true;
    vibrate(10);
  };

  const handleChip = (code: string) => {
    if (code === from || code === to) {
      swap();
      return;
    }
    setTo(from);
    setFrom(code);
    vibrate(8);
  };

  /** Keypad entry — digits, decimal, inline expression operators, =, %, del. */
  const handlePress = (key: string) => {
    vibrate(6);
    if (key !== "AC") touched.current = true;
    setRaw((r) => {
      if (key === "AC") return "0";
      if (key === "del") {
        const next = r.length <= 1 ? "0" : r.slice(0, -1);
        return next === "" ? "0" : next;
      }
      if (key === "%") {
        // percent applies to the number currently being typed
        const m = r.match(/(\d*\.?\d+)$/);
        if (!m) return r;
        const v = Number(m[1]) / 100;
        return `${r.slice(0, r.length - m[1].length)}${Number(v.toFixed(8))}`;
      }
      if (EXPR_OPS.includes(key)) {
        if (r === "0") return `0${key}`;
        if (EXPR_OPS.includes(r.slice(-1))) return r.slice(0, -1) + key; // swap operator
        return r + key;
      }
      if (key === "=") {
        const v = evalExpression(r);
        return v == null ? r : String(Number(v.toFixed(8)));
      }
      if (key === ".") {
        const last = r.split(/[+−×÷]/).pop() ?? "";
        return last.includes(".") ? r : `${r}.`;
      }
      // digit — cap each segment at 12 digits
      const last = r.split(/[+−×÷]/).pop() ?? "";
      if (last.replace(".", "").length >= 12) return r;
      if (r === "0") return key;
      return r + key;
    });
  };

  /** Voice input — "250 usd to eur" or just a number. */
  const handleVoice = (text: string) => {
    const t = text.toLowerCase();
    const num = t.replace(/,/g, "").match(/\d+(\.\d+)?/);
    const heard: string[] = [];
    for (const c of CURRENCIES) {
      if (heard.length >= 2) break;
      if (new RegExp(`\\b${c.code.toLowerCase()}\\b`).test(t)) heard.push(c.code);
    }
    if (num) setRaw(num[0]);
    if (heard[0]) setFrom(heard[0]);
    if (heard[1] && heard[1] !== heard[0]) setTo(heard[1]);
    if (num || heard.length) touched.current = true;
    showToast(
      num || heard.length ? `HEARD · “${text.toUpperCase()}”` : "COULD NOT CATCH AN AMOUNT"
    );
  };

  /* --------------------------- expense folders --------------------------- */

  const spendOf = (f: ExpenseFolder): number =>
    entries
      .filter((e) => f.entryIds.includes(e.id))
      .reduce((sum, e) => {
        if (e.to === f.currency) return sum + e.result;
        const r = crossRate(rates, e.to, f.currency);
        return r ? sum + e.result * r : sum;
      }, 0);

  const folderIdOfEntry = (entryId: string) =>
    folders.find((f) => f.entryIds.includes(entryId))?.id ?? null;

  const folderNameOf = (entryId: string) =>
    folders.find((f) => f.entryIds.includes(entryId))?.name ?? null;

  const createFolder = (name: string, budget: number) => {
    setFolders((prev) =>
      [
        {
          id: `f_${Date.now().toString(36)}`,
          name,
          currency: to,
          budget,
          entryIds: [],
          createdAt: Date.now(),
        },
        ...prev,
      ].slice(0, 20)
    );
    showToast(`FOLDER “${name.toUpperCase()}” CREATED`);
  };

  const deleteFolder = (id: string) => {
    setFolders((prev) => prev.filter((f) => f.id !== id));
    showToast("FOLDER DELETED");
  };

  const assignFolder = (folderId: string | null) => {
    if (!folderSheet || folderSheet.mode !== "assign") return;
    const entryId = folderSheet.entryId;
    setFolders((prev) =>
      prev.map((f) => {
        const had = f.entryIds.includes(entryId);
        if (folderId && f.id === folderId) {
          return had ? f : { ...f, entryIds: [...f.entryIds, entryId] };
        }
        return had ? { ...f, entryIds: f.entryIds.filter((i) => i !== entryId) } : f;
      })
    );
    setFolderSheet(null);
    showToast(folderId ? "MOVED TO FOLDER" : "REMOVED FROM FOLDER");
  };

  const handleSheetSelect = (code: string) => {
    touched.current = true;
    if (sheet === "from") {
      if (code === to) setTo(from);
      setFrom(code);
    } else if (sheet === "to") {
      if (code === from) setFrom(to);
      setTo(code);
    } else if (sheet === "base") {
      setDefaultBase(code);
      setFrom(code);
      showToast(`DEFAULT BASE SET TO ${code}`);
    }
    setSheet(null);
  };

  const toggleFavorite = (code: string) => {
    // keep the updater pure (StrictMode double-invokes updaters)
    const pinned = favorites.includes(code);
    setFavorites((f) => (f.includes(code) ? f.filter((c) => c !== code) : [...f, code]));
    showToast(pinned ? `UNPINNED ${code}` : `PINNED ${code} TO TOP`);
    vibrate(8);
  };

  const handleCopy = async () => {
    if (converted == null) return;
    try {
      await navigator.clipboard.writeText(`${convertedStr} ${to}`);
    } catch { /* clipboard unavailable */ }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  };

  const exportCsv = () => {
    if (!entries.length) {
      showToast("NOTHING TO EXPORT YET");
      return;
    }
    downloadText(
      `monofx-history-${new Date().toISOString().slice(0, 10)}.csv`,
      buildCsv(entries),
      "text/csv"
    );
    showToast("CSV DOWNLOADED");
  };

  /** Full account export — settings included, passcode hash redacted. */
  const downloadJson = () => {
    if (!user) return;
    const payload = {
      exportedAt: new Date().toISOString(),
      account: { id: user.id, name: user.name, email: user.email },
      settings: { ...settings, passcodeHash: settings.passcodeHash ? "[redacted]" : null },
      favorites,
      watchlist: pairs,
      folders,
      alerts,
      history: entries,
    };
    downloadText(
      `monofx-data-${new Date().toISOString().slice(0, 10)}.json`,
      JSON.stringify(payload, null, 2),
      "application/json"
    );
    showToast("DATA DOWNLOADED · JSON");
  };

  /* ----------------------------- speech readout --------------------------- */

  const speechArmed = useRef(false);
  useEffect(() => {
    if (!user || !settings.speakResults) return;
    if (!speechArmed.current) {
      speechArmed.current = true; // skip the restored value at sign-in
      return;
    }
    if (converted == null || converted <= 0) return;
    const t = window.setTimeout(() => {
      try {
        window.speechSynthesis?.cancel();
        const u = new SpeechSynthesisUtterance(`${convertedStr} ${meta(to).name}`);
        u.rate = 1.05;
        window.speechSynthesis?.speak(u);
      } catch { /* unsupported */ }
    }, 1000);
    return () => window.clearTimeout(t);
  }, [convertedStr, to, user, settings.speakResults, converted]);

  const speakSample = () => {
    try {
      if (!("speechSynthesis" in window)) {
        showToast("SPEECH UNSUPPORTED IN THIS BROWSER");
        return;
      }
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(
        new SpeechSynthesisUtterance("Mono eff ex. One thousand two hundred fifty euros.")
      );
    } catch {
      showToast("SPEECH UNSUPPORTED IN THIS BROWSER");
    }
  };

  const handleAddAlert = (target: number, dir: "above" | "below"): string | null => {
    try {
      if (
        alertPrefs.push &&
        "Notification" in window &&
        Notification.permission === "default" &&
        alerts.length === 0
      ) {
        void Notification.requestPermission();
      }
    } catch { /* unsupported */ }
    return addAlert(from, to, target, dir);
  };

  const handleAlertPrefs = (p: AlertPrefs) => {
    setAlertPrefs(p);
    try {
      if (p.push && "Notification" in window && Notification.permission === "default") {
        void Notification.requestPermission();
      }
    } catch { /* unsupported */ }
  };

  const handleCalcSend = (v: string) => {
    const num = Math.min(Math.abs(Number(v) || 0), 999999999999);
    // clamp: String() of tiny values yields "1e-9", which the pad can't render
    const clean = num <= 0 ? "0" : num < 0.000001 ? "0.000001" : String(Number(num.toFixed(8)));
    setRaw(clean);
    touched.current = true;
    setView("home");
    setSidebarOpen(false);
    showToast("AMOUNT SENT TO CONVERTER");
  };

  const makeLiveEntry = (): ConversionEntry | null =>
    effRate == null || converted == null || amount <= 0
      ? null
      : {
          id: Date.now().toString(36),
          ts: Date.now(),
          raw,
          from,
          to,
          rate: effRate,
          result: converted,
          ...(effFee > 0 ? { feePct: effFee } : {}),
        };

  const copyBasketSummary = async () => {
    const lines = [
      `◐ MONO FX BASKET — ${formatInput(raw)} ${from} BUYS`,
      ...basketCodes.map((code) => {
        const r = crossRate(rates, from, code);
        const v = r != null ? amount * r : null;
        return `  ${code.padEnd(5)} ${v != null ? formatValue(v, code) : "—"} ${code}`;
      }),
      "RATES BY OPEN-ER-API / COINGECKO · INDICATIVE ONLY",
    ];
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      showToast("BASKET SUMMARY COPIED");
    } catch {
      showToast("CLIPBOARD UNAVAILABLE");
    }
  };

  /* physical keyboard — only while actually converting */
  const litKey = useKeyboard({
    disabled:
      !user ||
      (view !== "home" && view !== "basket") ||
      sheet !== null ||
      sidebarOpen ||
      receiptEntry !== null ||
      pinState !== null ||
      folderSheet !== null,
    onDigit: (d) => handlePress(d),
    onDot: () => handlePress("."),
    onBackspace: () => handlePress("del"),
    onClear: () => handlePress("AC"),
    onSwap: swap,
    onOperator: (op) => handlePress(op),
    onEquals: () => handlePress("="),
    onPercent: () => handlePress("%"),
    onTogglePad: () => setPadOpen((v) => !v),
  });

  /* adaptive type scale */
  const fromLen = raw.replace(".", "").length;
  const amountSize = fromLen > 10 ? "text-[26px]" : fromLen > 7 ? "text-4xl" : "text-[44px]";
  const resultSize =
    convertedStr.length > 14 ? "text-2xl" : convertedStr.length > 9 ? "text-3xl" : "text-4xl";

  const padVisible = !!user && (view === "home" || view === "basket");
  const padPadding = padVisible
    ? padOpen
      ? "pb-[292px] sm:pb-[326px]"
      : "pb-14" // collapsed dock: only the grab handle occupies space
    : "pb-16";

  return (
    <div className="relative min-h-dvh bg-black text-white">
      {/* ambient desktop backdrop */}
      <div className="bg-blueprint pointer-events-none fixed inset-0 opacity-0 transition-opacity duration-700 sm:opacity-100" />
      <div className="bg-vignette pointer-events-none fixed inset-0" />

      <div className="relative z-10 mx-auto w-full max-w-md">
        {/* device side buttons (desktop frame only) */}
        <div className="absolute top-32 -left-[3px] hidden h-10 w-[3px] rounded-l-md bg-zinc-700 sm:block" />
        <div className="absolute top-44 -left-[3px] hidden h-10 w-[3px] rounded-l-md bg-zinc-700 sm:block" />
        <div className="absolute top-36 -right-[3px] hidden h-16 w-[3px] rounded-r-md bg-zinc-700 sm:block" />

        {/* phone shell — zoomed by the Text Size accessibility setting.
            safe-top keeps content clear of the notch on real devices. */}
        <div
          className="safe-top shadow-shell relative mx-auto flex h-dvh w-full flex-col overflow-hidden border-x border-line bg-black sm:my-8 sm:h-[calc(100dvh-4rem)] sm:rounded-[2.75rem] sm:border"
          style={{ zoom: FONT_ZOOM[settings.fontScale] } as CSSProperties}
        >
          <StatusBar />

          {/* app bar */}
          {user && (
            <header className="flex items-center justify-between px-5 pt-1 pb-3">
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => setSidebarOpen(true)}
                  aria-label="Open menu"
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-zinc-300 transition-all duration-150 active:scale-90 active:bg-white active:text-black"
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" aria-hidden>
                    <path d="M2 4h12M2 8h8M2 12h12" />
                  </svg>
                </button>
                {/* half-moon mark */}
                <svg width="26" height="26" viewBox="0 0 24 24" aria-hidden>
                  <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.6" />
                  <path d="M12 2a10 10 0 0 1 0 20Z" fill="currentColor" />
                </svg>
                <div>
                  <h1 className="font-display text-[17px] leading-none font-bold tracking-tight">
                    MONO<span className="text-zinc-500">FX</span>
                  </h1>
                  <p className="mt-1 font-mono text-[7px] tracking-[0.35em] text-zinc-500">
                    {user.name.toUpperCase().split(" ")[0]}’S CONSOLE
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setView("settings")}
                  aria-label="Profile and settings"
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-black font-display text-[11px] font-bold transition-all duration-150 active:scale-90 active:bg-white active:text-black"
                >
                  {initialsOf(user.name)}
                </button>
                <button
                  onClick={toggleTheme}
                  aria-label="Toggle theme"
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-lg transition-all duration-150 active:scale-90 active:bg-white active:text-black"
                >
                  {theme === "dark" ? "◐" : "◑"}
                </button>
                <button
                  onClick={() => void doRefresh()}
                  aria-label="Refresh rates"
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full border transition-all duration-150 active:scale-90",
                    refreshing
                      ? "border-zinc-400 text-white"
                      : "border-line text-zinc-300 active:bg-white active:text-black"
                  )}
                >
                  <RefreshIcon spinning={refreshing} />
                </button>
              </div>
            </header>
          )}

          {/* toast */}
          <Toast toast={toast} />

          {/* service-worker update banner */}
          {swUpdate && (
            <button
              onClick={applySwUpdate}
              className="animate-toast absolute top-[4.6rem] left-1/2 z-40 flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-[0_10px_36px_rgba(0,0,0,0.85)]"
            >
              <span className="h-1.5 w-1.5 shrink-0 animate-pulse-dot rounded-full bg-black" />
              <span className="font-mono text-[10px] font-bold tracking-[0.18em] whitespace-nowrap text-black">
                UPDATE AVAILABLE — TAP TO RELOAD
              </span>
            </button>
          )}

          {/* content */}
          {!user ? (
            <AuthScreen
              onSignIn={signIn}
              onSignUp={signUp}
              onDemo={async () => {
                await demo();
                showToast("SIGNED IN AS DEMO TRADER");
              }}
              onGuest={() => {
                guest();
                showToast("BROWSING AS GUEST — DATA STAYS ON THIS DEVICE");
              }}
              onReset={() => {
                reset();
                showToast("LOCAL ACCOUNTS ERASED — START FRESH");
              }}
            />
          ) : (
            <main
              className={cn(
                "no-scrollbar relative flex-1 overflow-y-auto",
                padPadding
              )}
            >
              {view === "home" && (
                <>
                  <div className="animate-fade px-4">
                    <SyncBanner status={status} lastUpdated={lastUpdated} />
                  </div>

                  <div className="mt-3">
                    <Ticker
                      rates={rates}
                      onSelect={(f, t) => {
                        setFrom(f);
                        setTo(t);
                        touched.current = true;
                      }}
                    />
                  </div>

                  {/* mode switch: 1-to-1 converter ↔ multi-convert board */}
                  <div className="mt-3 animate-tick px-4" style={{ animationDelay: "30ms" }}>
                    <div className="grid grid-cols-2 gap-1 rounded-full border border-line bg-panel p-1">
                      <span className="flex items-center justify-center gap-1.5 rounded-full bg-white py-2 font-mono text-[9px] font-bold tracking-[0.2em] text-black">
                        ⇄ 1-TO-1 CONVERT
                      </span>
                      <button
                        onClick={() => setView("basket")}
                        className="flex items-center justify-center gap-1.5 rounded-full py-2 font-mono text-[9px] font-bold tracking-[0.2em] text-zinc-500 transition-all duration-200 active:scale-[0.97] active:bg-white active:text-black"
                      >
                        ▦ MULTI BOARD
                      </button>
                    </div>
                  </div>

                  {/* quick-select chips */}
                  <div className="mt-3 animate-tick px-4" style={{ animationDelay: "40ms" }}>
                    <div className="mb-2 flex items-center justify-between">
                      <span className="font-mono text-[9px] tracking-[0.3em] text-zinc-600">
                        QUICK PAIRS
                      </span>
                      <span className="font-mono text-[8px] tracking-[0.2em] text-zinc-700">
                        ■ SENDS&ensp;□ RECEIVES
                      </span>
                    </div>
                    <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4">
                      {QUICK_CODES.map((code) => {
                        const isFrom = code === from;
                        const isTo = code === to;
                        return (
                          <button
                            key={code}
                            onClick={() => handleChip(code)}
                            className={cn(
                              "shrink-0 rounded-full border px-3.5 py-1.5 font-mono text-[11px] font-medium tracking-wider transition-all duration-150 active:scale-90",
                              isFrom
                                ? "border-white bg-white text-black"
                                : isTo
                                  ? "border-white text-white"
                                  : "border-line text-zinc-400"
                            )}
                          >
                            {code}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* conversion card */}
                  <section
                    className="mt-3 animate-tick rounded-[1.75rem] border border-line bg-panel px-5 pt-5 pb-5"
                    style={{ animationDelay: "90ms" }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">
                        AMOUNT · SENDING
                      </span>
                      <CurrencyButton code={from} onClick={() => setSheet("from")} />
                    </div>
                    <div className="mt-1.5 flex items-center overflow-hidden">
                      <span
                        className={cn(
                          "truncate font-display font-semibold tracking-tight tabular-nums",
                          amountSize
                        )}
                      >
                        {formatInput(raw)}
                      </span>
                      <span className="animate-caret ml-1 h-9 w-[3px] shrink-0 rounded-full bg-white" />
                    </div>
                    <p className="mt-1 truncate font-mono text-[9px] tracking-[0.2em] text-zinc-600">
                      {meta(from).name.toUpperCase()} · {meta(from).country.toUpperCase()}
                    </p>

                    {/* swap divider */}
                    <div className="mt-4 mb-4 flex items-center">
                      <div className="h-px flex-1 bg-line" />
                      <button
                        onClick={swap}
                        aria-label="Swap currencies"
                        className="group mx-3 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white text-black shadow-[0_0_0_6px_var(--panel)] transition-transform duration-500"
                        style={{
                          transform: `rotate(${flip * 180}deg)`,
                          transitionTimingFunction: "cubic-bezier(0.34, 1.3, 0.5, 1)",
                        }}
                      >
                        <span className="transition-transform duration-150 group-active:scale-75">
                          <SwapIcon />
                        </span>
                      </button>
                      <div className="h-px flex-1 bg-line" />
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[9px] tracking-[0.3em] text-zinc-500">
                        CONVERTED · RECEIVING
                      </span>
                      <CurrencyButton code={to} onClick={() => setSheet("to")} />
                    </div>
                    <div className="mt-1.5 flex items-baseline overflow-hidden">
                      <span
                        key={`${to}-${convertedStr}-${lastUpdated ?? 0}`}
                        className={cn(
                          "animate-tick truncate font-display font-semibold tracking-tight text-white tabular-nums",
                          resultSize
                        )}
                      >
                        {convertedStr}
                      </span>
                      <span className="ml-2 shrink-0 font-mono text-[10px] tracking-widest text-zinc-500">
                        {to}
                      </span>
                    </div>

                    <div className="mt-3 flex items-center justify-between gap-2 border-t border-line pt-3">
                      <button
                        onClick={() => setInverted((v) => !v)}
                        disabled={effRate == null}
                        className="font-mono text-[10px] tracking-wider text-zinc-400 transition-colors tabular-nums active:text-white disabled:opacity-40"
                      >
                        {usingManual && effRate != null ? (
                          <>
                            1 {from} = {formatRate(effRate)} {to}
                            <span className="ml-1.5 rounded-sm bg-white px-1 py-px text-[7px] font-bold text-black">
                              MANUAL
                            </span>
                          </>
                        ) : settings.manualRate ? (
                          "MANUAL MODE · SET RATE IN ⚙ SETTINGS"
                        ) : (
                          effRate != null &&
                          (inverted
                            ? `1 ${to} = ${formatRate(1 / effRate)} ${from}`
                            : `1 ${from} = ${formatRate(effRate)} ${to}`)
                        )}
                        <span className="ml-1.5 text-zinc-600">⇄</span>
                      </button>
                      <button
                        onClick={() => void handleCopy()}
                        disabled={converted == null}
                        className={cn(
                          "shrink-0 rounded-full border px-3 py-1 font-mono text-[9px] font-medium tracking-[0.2em] transition-all duration-150 active:scale-90",
                          copied
                            ? "border-white bg-white text-black"
                            : "border-line text-zinc-300 active:border-zinc-400"
                        )}
                      >
                        {copied ? "COPIED ✓" : "COPY"}
                      </button>
                    </div>

                    {/* bank / card markup simulator */}
                    <FeeSimulator
                      feePct={feePct}
                      isCustom={feeIsCustom}
                      custom={feeCustom}
                      onPreset={(p) => {
                        setFeeIsCustom(false);
                        setFeePct(p);
                      }}
                      onCustom={(s) => {
                        setFeeIsCustom(true);
                        setFeeCustom(s);
                      }}
                    />

                    {/* fee impact row */}
                    <div className="mt-2 flex items-center justify-between gap-3 rounded-xl border border-line bg-black px-3.5 py-2.5">
                      {effFee > 0 && converted != null ? (
                        <>
                          <span className="font-mono text-[9px] tracking-[0.12em] text-zinc-400 tabular-nums">
                            FEE {effFee}% · −{formatValue(converted - (afterFee ?? 0), to)} {to}
                          </span>
                          <span className="shrink-0 font-mono text-[10px] font-bold tracking-wider text-white tabular-nums">
                            YOU GET {formatValue(afterFee ?? 0, to)}
                          </span>
                        </>
                      ) : (
                        <span className="font-mono text-[9px] tracking-[0.12em] text-zinc-500">
                          MID-MARKET RATE — NO BANK MARKUP APPLIED
                        </span>
                      )}
                    </div>

                    {/* receipt trigger */}
                    <button
                      onClick={() => {
                        const e = makeLiveEntry();
                        if (e) setReceiptEntry(e);
                        else showToast("ENTER AN AMOUNT FIRST");
                      }}
                      className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-zinc-600 py-3 font-mono text-[9px] font-bold tracking-[0.3em] text-zinc-300 transition-all duration-150 active:scale-[0.98] active:border-solid active:bg-white active:text-black"
                    >
                      🧾 GENERATE RECEIPT
                    </button>
                  </section>

                  {/* global snapshot */}
                  <div className="mt-3 animate-tick" style={{ animationDelay: "140ms" }}>
                    <Snapshot
                      raw={raw}
                      from={from}
                      to={to}
                      rates={rates}
                      onSelect={(code) => {
                        setTo(code);
                        touched.current = true;
                      }}
                      hidden={settings.hideAmounts}
                    />
                  </div>

                  {/* 7-day trend */}
                  <div className="mt-3 animate-tick" style={{ animationDelay: "190ms" }}>
                    <TrendChart {...history} from={from} to={to} />
                  </div>
                </>
              )}

              {view === "basket" && (
                <div className="mt-2">
                  <BasketScreen
                    raw={raw}
                    from={from}
                    rates={rates}
                    codes={basketCodes}
                    onToggle={(c) =>
                      setBasketCodes((prev) =>
                        prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]
                      )
                    }
                    onSelect={(c) => {
                      setTo(c);
                      touched.current = true;
                      setView("home");
                      showToast(`TARGET SET TO ${c}`);
                    }}
                    onCopySummary={() => void copyBasketSummary()}
                    onBack={() => setView("home")}
                    assets={{ live: assets.live, time: assets.time }}
                    hidden={settings.hideAmounts}
                  />
                </div>
              )}

              {view === "history" && (
                <div className="mt-2">
                  <HistoryScreen
                    entries={entries}
                    onRestore={(e) => {
                      setFrom(e.from);
                      setTo(e.to);
                      setRaw(e.raw);
                      touched.current = true;
                      setView("home");
                      showToast("CONVERSION RESTORED TO PAD");
                    }}
                    onRemove={(id) => setEntries((prev) => prev.filter((e) => e.id !== id))}
                    onClearAll={() => {
                      setEntries([]);
                      showToast("HISTORY CLEARED");
                    }}
                    onExport={exportCsv}
                    onReceipt={(e) => setReceiptEntry(e)}
                    folderNameOf={folderNameOf}
                    onAssignFolder={(id) =>
                      requirePin(() => setFolderSheet({ mode: "assign", entryId: id }))
                    }
                    hidden={settings.hideAmounts}
                  />
                </div>
              )}

              {view === "settings" && (
                <div className="mt-2">
                  <SettingsScreen
                    user={user}
                    settings={settings}
                    onSettings={patchSettings}
                    from={from}
                    to={to}
                    liveRate={rate}
                    defaultBase={defaultBase}
                    onUpdateAccount={(n, e) => update({ name: n, email: e })}
                    onChangeBase={() => setSheet("base")}
                    onTogglePasscode={handlePasscodeToggle}
                    onSpeakTest={speakSample}
                    onClearRateCache={() => {
                      try {
                        localStorage.removeItem("monofx:rates:v1");
                        localStorage.removeItem("monofx:assets:v1");
                        Object.keys(localStorage)
                          .filter((k) => k.startsWith("monofx:hist:"))
                          .forEach((k) => localStorage.removeItem(k));
                      } catch { /* non-fatal */ }
                      showToast("OFFLINE RATE CACHE CLEARED");
                    }}
                    onDeleteHistory={() => {
                      setEntries([]);
                      setFolders((prev) => prev.map((f) => ({ ...f, entryIds: [] })));
                      showToast("CONVERSION HISTORY DELETED");
                    }}
                    onDownloadCsv={exportCsv}
                    onDownloadJson={downloadJson}
                    onSignOut={() => {
                      signOut();
                      setView("home");
                    }}
                    onDeleteAccount={() => {
                      destroy();
                      setView("home");
                      showToast("ACCOUNT DELETED");
                    }}
                    historyCount={entries.length}
                    canInstall={install.canInstall}
                    onInstall={() => void handleInstall()}
                  />
                </div>
              )}

              {view === "profile" && (
                <div className="mt-2">
                  <ProfileScreen
                    user={user}
                    theme={theme}
                    onToggleTheme={toggleTheme}
                    favorites={favorites}
                    defaultBase={defaultBase}
                    onChangeBase={() => setSheet("base")}
                    stats={{
                      pairs: pairs.length,
                      alerts: alerts.length,
                      conversions: entries.length,
                    }}
                    onClearData={() => {
                      setEntries([]);
                      setPairs([]);
                      setFolders([]);
                      clearAlerts();
                      showToast("ACCOUNT DATA ERASED");
                    }}
                    onSignOut={() => {
                      signOut();
                      setView("home");
                      setSidebarOpen(false);
                    }}
                    onOpenSettings={() => setView("settings")}
                  />
                </div>
              )}

              {/* colophon */}
              <footer className="mt-6 px-6 pb-4 text-center">
                <div className="mx-auto mb-3 h-px w-16 bg-line" />
                <p className="font-mono text-[8px] leading-relaxed tracking-[0.25em] text-zinc-600">
                  RATES · OPEN-ER-API / ECB / COINGECKO / GOLD-API
                  <br />
                  KEYBOARD · 0-9 TYPE · ⌫ DEL · ESC CLEAR · S SWAP · K PAD
                  <br />
                  © 2026 MONO FX · MIT LICENSE · BUILD {BUILD}
                  <br />
                  STRICTLY BLACK &amp; WHITE
                </p>
              </footer>
            </main>
          )}

          {/* keypad (converter view only) */}
          {padVisible && (
            <Keypad
              onPress={handlePress}
              onClear={() => handlePress("AC")}
              litKey={litKey}
              onVoiceResult={handleVoice}
              onVoiceUnsupported={() => showToast("VOICE INPUT UNSUPPORTED IN THIS BROWSER")}
              collapsed={!padOpen}
              onToggle={() => setPadOpen((v) => !v)}
            />
          )}
          {user && !padVisible && (
            <div className="absolute inset-x-0 bottom-0 z-30 flex justify-center border-t border-line bg-black py-3">
              <div className="h-1 w-28 rounded-full bg-zinc-700" />
            </div>
          )}

          {/* sidebar drawer */}
          {user && (
            <Sidebar
              open={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
              user={user}
              view={view}
              onNav={(v) => {
                setSidebarOpen(false);
                if (v === "history") requirePin(() => setView("history"));
                else setView(v);
              }}
              theme={theme}
              onToggleTheme={toggleTheme}
              pairs={pairs}
              rates={rates}
              onPinCurrent={() => {
                // keep the updater pure (StrictMode double-invokes updaters)
                if (pairs.some((p) => p.from === from && p.to === to)) {
                  showToast("PAIR ALREADY PINNED");
                  return;
                }
                setPairs((prev) =>
                  [{ id: `p_${Date.now().toString(36)}`, from, to }, ...prev].slice(0, 12)
                );
                showToast(`PINNED ${from}/${to} TO WATCHLIST`);
              }}
              onLoadPair={(f, t) => {
                setFrom(f);
                setTo(t);
                setView("home");
                setSidebarOpen(false);
                showToast(`LOADED ${f}/${t}`);
              }}
              onRemovePair={(id) => setPairs((prev) => prev.filter((p) => p.id !== id))}
              folders={folders}
              spendOf={spendOf}
              onManageFolders={() => requirePin(() => setFolderSheet({ mode: "manage" }))}
              alerts={alerts}
              from={from}
              to={to}
              alertPrefs={alertPrefs}
              onAlertPrefs={handleAlertPrefs}
              onAddAlert={handleAddAlert}
              onRemoveAlert={removeAlert}
              onSendCalc={handleCalcSend}
              converted={converted}
              currency={to}
              onExportCsv={exportCsv}
              historyCount={entries.length}
              onSignOut={() => {
                signOut();
                setSidebarOpen(false);
                setView("home");
                showToast("SIGNED OUT");
              }}
              canInstall={install.canInstall}
              onInstall={() => void handleInstall()}
            />
          )}

          {/* expense folder sheet */}
          {user && (
            <FolderSheet
              state={folderSheet}
              folders={folders}
              defaultCurrency={to}
              spendOf={spendOf}
              folderIdOfEntry={folderIdOfEntry}
              onCreate={createFolder}
              onDelete={deleteFolder}
              onAssign={assignFolder}
              onClose={() => setFolderSheet(null)}
            />
          )}

          {/* currency sheet */}
          <CurrencySheet
            side={sheet}
            from={from}
            to={to}
            base={defaultBase}
            rates={rates}
            favorites={favorites}
            onSelect={handleSheetSelect}
            onToggleFavorite={toggleFavorite}
            onClose={() => setSheet(null)}
          />

          {/* receipt modal */}
          {receiptEntry && (
            <ReceiptModal
              entry={receiptEntry}
              user={user}
              onClose={() => setReceiptEntry(null)}
              onToast={showToast}
              hidden={settings.hideAmounts}
            />
          )}

          {/* iOS "Add to Home Screen" guide */}
          <InstallSheet open={iosGuide} onClose={() => setIosGuide(false)} />

          {/* passcode lock overlay */}
          {pinState && (
            <PinLock
              mode={pinState.mode}
              expectedHash={settings.passcodeHash}
              onUnlocked={() => {
                const after = pinState.mode === "unlock" ? pinState.after : null;
                unlockedRef.current = true;
                setPinState(null);
                showToast("UNLOCKED");
                after?.();
              }}
              onSetupComplete={(pin) => {
                patchSettings({ passcodeOn: true, passcodeHash: hashPassword(pin) });
                unlockedRef.current = true;
                setPinState(null);
                showToast("PASSCODE ENABLED");
              }}
              onClose={() => setPinState(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
}

