# ◐ MONO FX — Currency Converter

A strictly black-and-white, native-feeling currency console built as a mobile-first web app.
React 19 · TypeScript · Vite · Tailwind CSS 4 — no UI kit, every pixel hand-rolled.

![theme](https://img.shields.io/badge/theme-dual%20monochrome-black) ![build](https://img.shields.io/badge/build-single%20file%20~370kB-white)

## Features

- **Live rates, offline-ready** — USD-based rates from [open.er-api.com](https://open.er-api.com), cached to localStorage, with `LIVE / CACHED / OFFLINE / REFERENCE` status states that never dead-end the UI.
- **149 currencies + assets** — full ISO-4217 universe plus **BTC, ETH, Gold (XAU), Silver (XAG)** via CoinGecko & gold-api.com, with 8-dp crypto precision and scientific notation for sub-dust rates.
- **Native keypad** — custom touch pad with blinking caret, adaptive type scale, haptics, and full **desktop keyboard entry** (`0-9` type · `.` decimal · `⌫` delete · `Esc` clear · `S`/`Enter` swap) with the on-screen key lighting up.
- **Dual monochrome themes** — pure black (#000/#09090b/#fff) ↔ crisp paper (#fff/#f4f4f5/#000), swapped at runtime through a CSS-variable palette, persisted to localStorage.
- **Basket multi-convert** — one amount across ten targets (fiat + crypto + metals) with include/exclude toggles and copyable summaries.
- **7-day trend chart** — scrubbable SVG line with crosshair tooltip, HIGH/LOW/AVG stats; live ECB series via Frankfurter where covered, deterministic labelled estimates elsewhere.
- **Accounts (mock local auth)** — sign in / create account with pure-JS SHA-256 password hashing (secure-context independent, legacy-hash migration), **guest mode**, per-user data, demo account included.
- **Bank/card fee simulator** — 0% mid-market / 1.5% / 3% / 5% / custom markup pills with the exact fee delta and "YOU GET" net amount, stamped onto logged entries and receipts.
- **Expression keypad + voice** — iOS-style pad with inline `+ − × ÷ % =` (proper precedence, live-grouped display) and a Web Speech API mic: say *"250 usd to eur"*.
- **Trip & expense folders** — group saved conversions into named folders with optional budgets and monochrome progress bars; assign from any history entry.
- **Installable PWA** — `manifest.json` (standalone, portrait, maskable icons), in-app **Install App** card (Chromium `beforeinstallprompt` + iOS "Add to Home Screen" guide sheet), and a service worker with cache-first static assets, network-first rate APIs with offline fallback, and an "Update Available — Tap to Reload" banner.
- **Native-ready (Capacitor 8)** — `capacitor.config.ts` + `@capacitor/{haptics,share,status-bar}` auto-used inside the native shell with web fallbacks; safe-area insets; see `NATIVE-BUILD.md` for the exact Android Studio / Xcode commands.
- **History ledger** — every conversion auto-logged with frozen rate + result; searchable, restorable, deletable, **CSV export**.
- **Rate alerts** — above/below triggers evaluated on each sync, with in-app toast and optional browser push notifications.
- **Sidebar utilities** — watchlist pairs, alerts, classic calculator + **travel tip splitter**, export, theme toggle.
- **Receipts** — shareable conversion receipts with mono flags, deterministic barcode, ref & timestamp: **Web Share API, WhatsApp, Telegram, X, Facebook, Reddit, Email, SMS**, copy, .txt download, print — plus copy-then-open chips for Snapchat, Instagram and LinkedIn (no share-link APIs exist for those).

## Quick start

```bash
npm install
npm run dev        # develop on http://localhost:5173
npm run build      # production build → dist/index.html (self-contained)
npm run preview    # serve the production build on http://localhost:4173
```

> Demo account: `demo@monofx.app` / `demo1234` — or create your own.
> Accounts are mock-local: everything stays in your browser's localStorage.

## Project structure

```
src/
├── App.tsx                  # shell, state orchestration, views
├── lib/                     # pure domain logic (tested headlessly)
│   ├── auth.ts              #   mock auth + SHA-256 (FIPS-verified)
│   ├── currencies.ts        #   149-currency universe + fallback rates
│   ├── money.ts             #   safe float math, locale formatting
│   ├── ledger.ts            #   history storage, receipts, CSV, share URLs
│   ├── flags.ts / version.ts
├── hooks/                   # useRates · useAssetRates · useHistory ·
│                            # useAlerts · useKeyboard · useTheme
└── components/              # StatusBar · Keypad · Ticker · TrendChart ·
                             # CurrencySheet · Sidebar · BasketScreen ·
                             # HistoryScreen · ProfileScreen · AuthScreen ·
                             # ReceiptModal · Calculator · …
```

## Deploying to GitHub Pages

The production build is a **single self-contained `index.html`** (~370 kB, all JS/CSS
inlined), so Pages hosting is trivial and works from any sub-path with zero config.

### Option A — GitHub Actions (recommended, already wired up)

1. Create a repo and push this project:
   ```bash
   git init && git add -A
   git commit -m "MONO FX v2.1"
   git branch -M main
   git remote add origin https://github.com/<you>/monofx.git
   git push -u origin main
   ```
2. In the repo: **Settings → Pages → Build and deployment → Source → “GitHub Actions”**.
3. Done — every push to `main` runs `.github/workflows/deploy.yml` (npm ci → build → upload `dist` → deploy).
4. Your site goes live at `https://<you>.github.io/monofx/`.

### Option B — manual publish

```bash
npm run build
npx gh-pages -d dist     # publishes dist/ to the gh-pages branch
```
Then set **Settings → Pages → Source → “Deploy from a branch” → `gh-pages` / `/ (root)`**.

### Notes

- Live rates, crypto prices, and history all run client-side — Pages (static hosting) is fully sufficient; no server needed.
- `crypto.subtle`-free auth hashing means sign-in works identically on `https://`, `localhost`, and plain-`http` origins.
- For a custom domain, add the domain in Pages settings and a `CNAME` — nothing else changes.

## License

MIT — © 2026 MONO FX. Rates are indicative, sourced from open.er-api.com, ECB (via
Frankfurter), CoinGecko, and gold-api.com. Not financial advice.
